# AURA Typography Handbook
## Complete Type System Reference v1.0

---

## 1. TYPOGRAPHY FUNDAMENTALS

### 1.1 Type Anatomy

```
┌─────────────────────────────────────────┐
│  Ascender Height (b, d, h, k, l)        │
│     ┌──┐                                │
│     │  │  ← Cap Height (A, B, C)        │
│  ┌──┤  ├──┐                             │
│  │  │  │  │  ← x-Height (a, e, o, x)    │
│  │  └──┘  │                             │
│  │    │    │                             │
│  │    │    │  ← Baseline                 │
│  │    │    │                             │
│  └──┬─┴──┬─┘  ← Descender Depth (g, j, p)│
│     │     │                              │
│     └─────┘                              │
│                                          │
│  ┌─────────┐                             │
│  │    │    │  ← Stem (vertical stroke)   │
│  │    │    │                             │
│  └────┴────┘                             │
│                                          │
│  ┌──┐  ┌──┐                             │
│  │  │  │  │  ← Serif (foot)             │
│  └──┘  └──┘                             │
│                                          │
│  ┌──┐                                   │
│  │  │  ← Counter (enclosed space)       │
│  └──┘                                   │
│                                          │
│  ┌────────────┐                          │
│  │    ────    │  ← Crossbar (A, H, e)  │
│  └────────────┘                          │
│                                          │
│  ┌──┐                                    │
│  │  │  ← Terminal (end of stroke)       │
│  └──┘                                    │
└─────────────────────────────────────────┘
```

### 1.2 Type Classification

```yaml
type_classification:
  serif:
    old_style:
      characteristics: ["Diagonal stress", "Low contrast", "Bracketed serifs", "Small x-height"]
      examples: ["Garamond", "Jenson", "Palatino", "Crimson Text"]
      use: ["Books", "Long-form reading", "Classic brands"]

    transitional:
      characteristics: ["Vertical stress transition", "Medium contrast", "Wedge serifs", "Medium x-height"]
      examples: ["Times New Roman", "Baskerville", "Georgia"]
      use: ["Newspapers", "General body text", "Traditional"]

    modern:
      characteristics: ["Vertical stress", "High contrast", "Hairline serifs", "Large x-height"]
      examples: ["Bodoni", "Didot", "Walbaum", "Farnham"]
      use: ["Fashion", "Luxury", "Editorial headlines", "Magazines"]

    slab:
      characteristics: ["Heavy serifs", "Low contrast", "Mechanical", "Uniform stroke"]
      examples: ["Rockwell", "Clarendon", "Memphis", "Courier"]
      use: ["Posters", "Display", "Tech (retro)", "Typewriter aesthetic"]

    glyphic:
      characteristics: ["Flared terminals", "No true serifs", "Carved look"]
      examples: ["Trajan", "Copperplate", "Albertus"]
      use: ["Luxury", "Formal", "Certificates", "Movie titles"]

  sans_serif:
    grotesque:
      characteristics: ["Monotone weight", "Closed apertures", "Minimal contrast", "Neutral"]
      examples: ["Franklin Gothic", "News Gothic", "Akzidenz-Grotesk"]
      use: ["Newspapers", "Signage", "Traditional corporate"]

    neo_grotesque:
      characteristics: ["Neutral", "Uniform", "Large x-height", "Closed apertures"]
      examples: ["Helvetica", "Arial", "Univers", "Inter"]
      use: ["UI", "General purpose", "Corporate", "International"]

    humanist:
      characteristics: ["Open apertures", "Some stroke contrast", "Organic", "Calligraphic influence"]
      examples: ["Gill Sans", "Frutiger", "Myriad", "Open Sans", "Source Sans Pro"]
      use: ["Signage", "UI", "Brands wanting warmth", "Wayfinding"]

    geometric:
      characteristics: ["Circular O", "Geometric construction", "Minimal contrast", "Modern"]
      examples: ["Futura", "Avenir", "Montserrat", "Century Gothic", "Proxima Nova"]
      use: ["Tech", "Startups", "Modern brands", "Headlines"]

    square:
      characteristics: ["Square curves", "Uniform weight", "Mechanical", "Tech"]
      examples: ["Eurostile", "Bank Gothic", "Microgramma"]
      use: ["Tech", "Sci-fi", "Industrial", "Display"]

  script:
    formal:
      characteristics: ["Connected letters", "Calligraphic", "Elegant", "Formal"]
      examples: ["Zapfino", "Bickham Script", "Edwardian Script"]
      use: ["Weddings", "Formal invitations", "Luxury"]

    casual:
      characteristics: ["Loosely connected", "Informal", "Handwritten", "Friendly"]
      examples: ["Brush Script", "Kaufmann", "Pacifico", "Dancing Script"]
      use: ["Friendly brands", "Food", "Children's", "Social media"]

    handwriting:
      characteristics: ["Disconnected", "Natural", "Personal", "Authentic"]
      examples: ["Comic Sans", "Kristen", "Permanent Marker", "Caveat"]
      use: ["Informal", "Children's", "Personal blogs", "Notes"]

  display:
    characteristics: ["Highly stylized", "Extreme weights", "Decorative", "Not for body"]
    examples: ["Bebas Neue", "Impact", "Lobster", "Playfair Display"]
    use: ["Headlines", "Posters", "Logos", "One-off statements"]

  monospace:
    characteristics: ["Fixed width", "Code-like", "Technical", "Retro"]
    examples: ["Courier", "Consolas", "JetBrains Mono", "Fira Code", "Roboto Mono"]
    use: ["Code", "Data", "Terminal", "Typewriter aesthetic", "Tables"]

  blackletter:
    characteristics: ["Dense", "Ornate", "Historical", "Gothic"]
    examples: ["Old English", "Fraktur", "Schwabacher"]
    use: ["Tattoos", "Metal music", "Historical", "Gothic themes"]
```

### 1.3 Type Metrics

```yaml
type_metrics:
  point_size:
    definition: "1 point = 1/72 inch = 0.3528mm"
    digital: "1px at 72 DPI = 1pt"

  pica:
    definition: "1 pica = 12 points"
    use: "Traditional print measurement"

  em:
    definition: "Width of capital M in current font/size"
    use: "Relative spacing, CSS"

  en:
    definition: "Half of em"
    use: "Dash width, spacing"

  x_height:
    definition: "Height of lowercase x"
    significance: "Perceived size, readability"

  cap_height:
    definition: "Height of capital letters"
    significance: "Visual alignment, logo design"

  ascender:
    definition: "Height above x-height (b, d, h)"

  descender:
    definition: "Depth below baseline (g, j, p, q, y)"

  leading:
    definition: "Vertical space between baselines"
    traditional: "Lead strips between lines of type"

  tracking:
    definition: "Uniform spacing across entire text block"
    also_known_as: "Letter-spacing"

  kerning:
    definition: "Spacing between specific letter pairs"
    pairs: ["AV", "To", "Tr", "Wa", "Ly", "P.", "L'"]

  measure:
    definition: "Line length in characters"
    optimal: "45-75 characters per line"
    maximum: "90 characters"

  font_weight:
    scale: [100, 200, 300, 400, 500, 600, 700, 800, 900]
    names: ["Thin", "Extra Light", "Light", "Regular", "Medium", "Semi Bold", "Bold", "Extra Bold", "Black"]

  font_width:
    scale: ["Ultra Condensed", "Extra Condensed", "Condensed", "Semi Condensed", "Normal", "Semi Expanded", "Expanded", "Extra Expanded", "Ultra Expanded"]
```

---

## 2. TYPOGRAPHIC SYSTEMS

### 2.1 Modular Scale

```yaml
modular_scales:
  minor_second:
    ratio: 1.067
    progression: [10, 10.7, 11.4, 12.2, 13.0, 13.9, 14.8, 15.8, 16.9, 18.0, 19.2, 20.5, 21.9, 23.3, 24.9, 26.6, 28.3, 30.2, 32.2, 34.4]
    use: "Subtle hierarchy, dense UI"

  major_second:
    ratio: 1.125
    progression: [10, 11.3, 12.7, 14.3, 16.0, 18.0, 20.3, 22.8, 25.6, 28.8, 32.4, 36.5, 41.0, 46.1, 51.9, 58.4, 65.7, 73.9, 83.2, 93.6]
    use: "Standard UI, web content"

  minor_third:
    ratio: 1.200
    progression: [10, 12.0, 14.4, 17.3, 20.7, 24.9, 29.9, 35.8, 43.0, 51.6, 61.9, 74.3, 89.2, 107.0, 128.4, 154.1, 185.0, 222.0, 266.3, 319.6]
    use: "Clear hierarchy, editorial"

  major_third:
    ratio: 1.250
    progression: [10, 12.5, 15.6, 19.5, 24.4, 30.5, 38.1, 47.7, 59.6, 74.5, 93.1, 116.4, 145.5, 181.9, 227.4, 284.2, 355.3, 444.1, 555.1, 693.9]
    use: "Bold hierarchy, marketing"

  perfect_fourth:
    ratio: 1.333
    progression: [10, 13.3, 17.7, 23.7, 31.6, 42.1, 56.1, 74.8, 99.7, 132.9, 177.2, 236.2, 315.0, 419.9, 559.8, 746.5, 995.3, 1327.1, 1769.5, 2359.3]
    use: "Dramatic hierarchy, display"

  augmented_fourth:
    ratio: 1.414
    progression: [10, 14.1, 20.0, 28.3, 40.0, 56.6, 80.0, 113.1, 160.0, 226.3, 320.0, 452.5, 640.0, 905.1, 1280.0, 1810.2, 2560.0, 3620.3, 5120.0, 7240.7]
    use: "Classical proportion, editorial"

  perfect_fifth:
    ratio: 1.500
    progression: [10, 15.0, 22.5, 33.8, 50.6, 75.9, 113.9, 170.9, 256.3, 384.4, 576.7, 865.0, 1297.5, 1946.2, 2919.3, 4379.0, 6568.5, 9852.7, 14779.1, 22168.7]
    use: "Strong hierarchy, posters"

  golden_ratio:
    ratio: 1.618
    progression: [10, 16.2, 26.2, 42.3, 68.4, 110.7, 179.1, 289.8, 468.9, 758.7, 1227.6, 1986.3, 3213.9, 5200.1, 8413.8, 13613.5, 22027.1, 35639.8, 57649.2, 93276.5]
    use: "Harmonious, nature-inspired"

  major_sixth:
    ratio: 1.667
    progression: [10, 16.7, 27.8, 46.3, 77.2, 128.7, 214.5, 357.5, 595.9, 993.2, 1655.3, 2759.5, 4600.1, 7668.4, 12783.9, 21310.9, 35518.2, 59215.4, 98712.3, 164553.8]
    use: "Very dramatic, display only"

  minor_seventh:
    ratio: 1.778
    progression: [10, 17.8, 31.6, 56.2, 99.9, 177.6, 315.8, 561.5, 998.3, 1775.0, 3156.0, 5611.7, 9977.6, 17740.2, 31542.1, 56081.8, 99713.5, 177290.6, 315222.7, 560665.9]
    use: "Extreme contrast, headlines"

  octave:
    ratio: 2.000
    progression: [10, 20, 40, 80, 160, 320, 640, 1280, 2560, 5120, 10240, 20480, 40960, 81920, 163840, 327680, 655360, 1310720, 2621440, 5242880]
    use: "Maximum contrast, special cases"
```

### 2.2 Type Scale System (8-Step)

```yaml
type_scale_8_step:
  base: 16px
  ratio: 1.250 (Major Third)

  scale:
    - name: "Display"
      size: "61.04px"
      line_height: "1.1"
      letter_spacing: "-0.02em"
      weight: 700
      use: "Hero headlines, massive statements"

    - name: "H1"
      size: "48.83px"
      line_height: "1.15"
      letter_spacing: "-0.02em"
      weight: 700
      use: "Page titles, major sections"

    - name: "H2"
      size: "39.06px"
      line_height: "1.2"
      letter_spacing: "-0.01em"
      weight: 600
      use: "Section headings, major subsections"

    - name: "H3"
      size: "31.25px"
      line_height: "1.25"
      letter_spacing: "-0.01em"
      weight: 600
      use: "Subsection headings, card titles"

    - name: "H4"
      size: "25.00px"
      line_height: "1.3"
      letter_spacing: "0"
      weight: 600
      use: "Component headings, feature titles"

    - name: "H5"
      size: "20.00px"
      line_height: "1.35"
      letter_spacing: "0"
      weight: 500
      use: "Minor headings, list titles"

    - name: "H6"
      size: "16.00px"
      line_height: "1.4"
      letter_spacing: "0.01em"
      weight: 500
      use: "Labels, captions, overlines"

    - name: "Body"
      size: "16.00px"
      line_height: "1.6"
      letter_spacing: "0"
      weight: 400
      use: "Paragraphs, general body text"

    - name: "Body Large"
      size: "20.00px"
      line_height: "1.5"
      letter_spacing: "0"
      weight: 400
      use: "Lead paragraphs, introductions"

    - name: "Body Small"
      size: "12.80px"
      line_height: "1.5"
      letter_spacing: "0.01em"
      weight: 400
      use: "Secondary text, metadata"

    - name: "Caption"
      size: "10.24px"
      line_height: "1.4"
      letter_spacing: "0.02em"
      weight: 400
      use: "Image captions, footnotes, timestamps"

    - name: "Overline"
      size: "10.24px"
      line_height: "1.4"
      letter_spacing: "0.1em"
      weight: 500
      text_transform: "uppercase"
      use: "Category labels, eyebrow text"
```

### 2.3 Fluid Typography

```css
/* Fluid type scale using clamp() */
:root {
  --font-size-fluid-display: clamp(2.5rem, 5vw + 1rem, 4rem);
  --font-size-fluid-h1: clamp(2rem, 4vw + 0.5rem, 3rem);
  --font-size-fluid-h2: clamp(1.5rem, 3vw + 0.5rem, 2.25rem);
  --font-size-fluid-h3: clamp(1.25rem, 2vw + 0.5rem, 1.75rem);
  --font-size-fluid-body: clamp(1rem, 1vw + 0.5rem, 1.125rem);
}
```

### 2.4 Responsive Typography

```yaml
responsive_typography:
  mobile:
    base: 16px
    scale_ratio: 1.125
    max_width: "100%"
    measure: "35-50 characters"
    line_height: 1.6

  tablet:
    base: 17px
    scale_ratio: 1.200
    max_width: "90%"
    measure: "45-65 characters"
    line_height: 1.55

  desktop:
    base: 18px
    scale_ratio: 1.250
    max_width: "1200px"
    measure: "55-75 characters"
    line_height: 1.5

  wide:
    base: 20px
    scale_ratio: 1.250
    max_width: "1400px"
    measure: "65-75 characters"
    line_height: 1.45
```

---

## 3. FONT PAIRING SYSTEM

### 3.1 Pairing Rules

```yaml
font_pairing_rules:
  - rule: "Contrast in classification"
    description: "Pair serif with sans-serif for maximum contrast"
    examples: ["Playfair Display + Inter", "Merriweather + Roboto", "Crimson Text + Source Sans Pro"]

  - rule: "Similar x-height"
    description: "When pairing, ensure similar x-heights for visual harmony"
    examples: ["Montserrat + Merriweather (both high x-height)"]

  - rule: "Weight contrast"
    description: "Pair light with bold, or regular with semi-bold"
    examples: ["Lato Light (body) + Lato Bold (headings)", "Inter Regular + Inter Extra Bold"]

  - rule: "Mood matching"
    description: "Ensure fonts share similar personality"
    examples: ["Friendly sans + Friendly serif", "Formal sans + Formal serif"]

  - rule: "Maximum 2-3 fonts"
    description: "Use one font family with multiple weights, or max 2-3 distinct families"

  - rule: "Superfamily advantage"
    description: "Superfamilies (same family with serif and sans) guarantee harmony"
    examples: ["Roboto + Roboto Slab", "Source Sans Pro + Source Serif Pro", "PT Sans + PT Serif"]

  - rule: "Avoid similar classifications"
    description: "Don't pair two similar sans-serifs or two similar serifs"
    bad_examples: ["Helvetica + Arial", "Times + Georgia"]

  - rule: "Consider loading performance"
    description: "Each font family adds HTTP requests and FOUT/FOIT risk"
    recommendation: "Use variable fonts when possible"
```

### 3.2 Curated Pairings

```yaml
curated_pairings:
  - name: "Modern Editorial"
    heading: "Playfair Display (700)"
    body: "Inter (400, 500)"
    accent: "JetBrains Mono (400)"
    mood: "Sophisticated, editorial, trustworthy"
    use: ["Magazines", "Blogs", "Luxury brands", "News"]

  - name: "Tech Startup"
    heading: "Montserrat (700, 800)"
    body: "Open Sans (400, 600)"
    accent: "Fira Code (400)"
    mood: "Modern, approachable, innovative"
    use: ["SaaS", "Startups", "Tech blogs", "Apps"]

  - name: "Corporate Professional"
    heading: "Source Sans Pro (600, 700)"
    body: "Source Sans Pro (400)"
    accent: "Source Code Pro (400)"
    mood: "Clean, professional, neutral"
    use: ["Enterprise", "B2B", "Documentation", "Dashboards"]

  - name: "Creative Agency"
    heading: "Bebas Neue (400)"
    body: "Lato (300, 400)"
    accent: "Space Mono (400)"
    mood: "Bold, creative, distinctive"
    use: ["Agencies", "Portfolios", "Fashion", "Events"]

  - name: "Friendly Consumer"
    heading: "Poppins (600, 700)"
    body: "Nunito (400, 600)"
    accent: "Inconsolata (400)"
    mood: "Warm, friendly, approachable"
    use: ["E-commerce", "Education", "Health", "Food"]

  - name: "Premium Luxury"
    heading: "Cormorant Garamond (300, 400)"
    body: "Montserrat (300, 400)"
    accent: "Cinzel (400)"
    mood: "Elegant, refined, exclusive"
    use: ["Fashion", "Jewelry", "Hotels", "Fine dining"]

  - name: "Retro Modern"
    heading: "Space Grotesk (700)"
    body: "Work Sans (400, 500)"
    accent: "IBM Plex Mono (400)"
    mood: "Nostalgic, techy, distinctive"
    use: ["Tech", "Gaming", "Creative tools", "Podcasts"]

  - name: "Academic Scholar"
    heading: "Merriweather (700)"
    body: "Merriweather (400)"
    accent: "Source Code Pro (400)"
    mood: "Traditional, scholarly, readable"
    use: ["Universities", "Research", "Publishing", "Libraries"]

  - name: "Minimal Swiss"
    heading: "Helvetica Neue (700)"
    body: "Helvetica Neue (400)"
    accent: "Courier New (400)"
    mood: "Clean, neutral, timeless"
    use: ["Architecture", "Design studios", "Galleries", "Minimal brands"]

  - name: "Handcrafted Artisan"
    heading: "Caveat (700)"
    body: "Lora (400, 600)"
    accent: "Special Elite (400)"
    mood: "Personal, authentic, handmade"
    use: ["Food blogs", "Craft brands", "Wedding", "Personal brands"]
```

---

## 4. OPEN TYPE FEATURES

### 4.1 Feature Reference

```yaml
opentype_features:
  - feature: "liga"
    name: "Standard Ligatures"
    description: "Replaces certain letter combinations with single glyphs"
    examples: ["fi → ﬁ", "fl → ﬂ", "ff → ﬀ", "ffi → ﬃ", "ffl → ﬄ"]
    use: "Always on for body text"

  - feature: "dlig"
    name: "Discretionary Ligatures"
    description: "Decorative ligatures for special occasions"
    examples: ["ct → ﬅ", "st → ﬆ", "sp → ﬂ"]
    use: "Headlines, display, special occasions"

  - feature: "calt"
    name: "Contextual Alternates"
    description: "Glyph variants based on surrounding characters"
    examples: ["Different 'r' after 'o' vs 'n'"]
    use: "Script fonts, calligraphic fonts"

  - feature: "swsh"
    name: "Swashes"
    description: "Decorative flourishes on letters"
    examples: ["Extended ascenders/descenders", "Ornamental terminals"]
    use: "Display, headlines, invitations"

  - feature: "salt"
    name: "Stylistic Alternates"
    description: "Alternative glyph designs"
    examples: ["Single-story 'a' vs double-story", "Different 'g' forms"]
    use: "Branding, when specific glyph preferred"

  - feature: "ss01" - "ss20"
    name: "Stylistic Sets"
    description: "Predefined sets of alternate glyphs"
    examples: ["ss01: rounded forms", "ss02: straight terminals"]
    use: "Fine-tuning brand typography"

  - feature: "tnum"
    name: "Tabular Figures"
    description: "Monospaced numbers for alignment"
    examples: ["Tables, financial data, code"]
    use: "Data, tables, spreadsheets"

  - feature: "pnum"
    name: "Proportional Figures"
    description: "Numbers with varying widths for text"
    examples: ["Body text, headlines"]
    use: "General text, when not in tables"

  - feature: "lnum"
    name: "Lining Figures"
    description: "Numbers that sit on baseline (modern)"
    examples: ["1234567890"]
    use: "Modern design, UI, headlines"

  - feature: "onum"
    name: "Oldstyle Figures"
    description: "Numbers with varying heights (traditional)"
    examples: ["1234567890" with descenders/ascenders]
    use: "Books, traditional design, body text"

  - feature: "frac"
    name: "Fractions"
    description: "Proper fraction glyphs"
    examples: ["1/2 → ½", "3/4 → ¾", "5/8 → ⅝"]
    use: "Recipes, measurements, math"

  - feature: "ordn"
    name: "Ordinals"
    description: "Superscript letters for ordinals"
    examples: ["1st → 1ˢᵗ", "2nd → 2ⁿᵈ", "3rd → 3ʳᵈ"]
    use: "Dates, rankings, competitions"

  - feature: "smcp"
    name: "Small Caps"
    description: "Small capital letters for lowercase"
    examples: ["small caps → SMALL CAPS"]
    use: "Acronyms, abbreviations, elegant text"

  - feature: "c2sc"
    name: "Capitals to Small Caps"
    description: "Convert capitals to small caps"
    examples: ["NASA → ɴᴀsᴀ"]
    use: "All-caps text with small caps"

  - feature: "kern"
    name: "Kerning"
    description: "Adjust spacing between specific pairs"
    use: "Always on"

  - feature: "case"
    name: "Case-Sensitive Forms"
    description: "Glyphs adjusted for all-caps context"
    examples: ["Punctuation raised for all-caps", "Math symbols adjusted"]
    use: "All-caps headlines, buttons"
```

---

## 5. TYPOGRAPHY IN CODE

### 5.1 CSS Typography System

```css
/* Complete CSS Typography System */

:root {
  /* Font Families */
  --font-sans: 'Inter', system-ui, -apple-system, sans-serif;
  --font-serif: 'Merriweather', Georgia, serif;
  --font-mono: 'JetBrains Mono', 'Fira Code', monospace;

  /* Font Sizes (Major Third Scale, base 16px) */
  --text-xs: 0.64rem;   /* 10.24px */
  --text-sm: 0.8rem;    /* 12.8px */
  --text-base: 1rem;    /* 16px */
  --text-lg: 1.25rem;   /* 20px */
  --text-xl: 1.563rem;  /* 25px */
  --text-2xl: 1.953rem; /* 31.25px */
  --text-3xl: 2.441rem; /* 39.06px */
  --text-4xl: 3.052rem; /* 48.83px */
  --text-5xl: 3.815rem; /* 61.04px */
  --text-6xl: 4.768rem; /* 76.29px */

  /* Line Heights */
  --leading-none: 1;
  --leading-tight: 1.25;
  --leading-snug: 1.375;
  --leading-normal: 1.5;
  --leading-relaxed: 1.625;
  --leading-loose: 2;

  /* Letter Spacing */
  --tracking-tighter: -0.05em;
  --tracking-tight: -0.025em;
  --tracking-normal: 0;
  --tracking-wide: 0.025em;
  --tracking-wider: 0.05em;
  --tracking-widest: 0.1em;

  /* Font Weights */
  --font-thin: 100;
  --font-extralight: 200;
  --font-light: 300;
  --font-normal: 400;
  --font-medium: 500;
  --font-semibold: 600;
  --font-bold: 700;
  --font-extrabold: 800;
  --font-black: 900;
}

/* Typography Classes */
.text-display {
  font-size: var(--text-5xl);
  line-height: var(--leading-tight);
  letter-spacing: var(--tracking-tight);
  font-weight: var(--font-bold);
}

.text-h1 {
  font-size: var(--text-4xl);
  line-height: var(--leading-tight);
  letter-spacing: var(--tracking-tight);
  font-weight: var(--font-bold);
}

.text-h2 {
  font-size: var(--text-3xl);
  line-height: var(--leading-snug);
  letter-spacing: var(--tracking-tight);
  font-weight: var(--font-semibold);
}

.text-h3 {
  font-size: var(--text-2xl);
  line-height: var(--leading-snug);
  letter-spacing: var(--tracking-normal);
  font-weight: var(--font-semibold);
}

.text-h4 {
  font-size: var(--text-xl);
  line-height: var(--leading-normal);
  letter-spacing: var(--tracking-normal);
  font-weight: var(--font-semibold);
}

.text-body {
  font-size: var(--text-base);
  line-height: var(--leading-relaxed);
  letter-spacing: var(--tracking-normal);
  font-weight: var(--font-normal);
  max-width: 65ch;
}

.text-body-large {
  font-size: var(--text-lg);
  line-height: var(--leading-normal);
  letter-spacing: var(--tracking-normal);
  font-weight: var(--font-normal);
  max-width: 65ch;
}

.text-small {
  font-size: var(--text-sm);
  line-height: var(--leading-normal);
  letter-spacing: var(--tracking-wide);
  font-weight: var(--font-normal);
}

.text-caption {
  font-size: var(--text-xs);
  line-height: var(--leading-normal);
  letter-spacing: var(--tracking-wider);
  font-weight: var(--font-normal);
}

.text-overline {
  font-size: var(--text-xs);
  line-height: var(--leading-normal);
  letter-spacing: var(--tracking-widest);
  font-weight: var(--font-medium);
  text-transform: uppercase;
}

/* Responsive Typography */
@media (min-width: 768px) {
  :root {
    --text-base: 1.0625rem; /* 17px */
  }
}

@media (min-width: 1024px) {
  :root {
    --text-base: 1.125rem; /* 18px */
  }
}

@media (min-width: 1280px) {
  :root {
    --text-base: 1.25rem; /* 20px */
  }
}
```

### 5.2 Web Font Loading Strategy

```html
<!-- Critical Font Loading -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<!-- Variable Font (single file, multiple weights) -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

<!-- Font Display Strategy -->
<style>
  @font-face {
    font-family: 'Inter';
    src: url('/fonts/Inter-Variable.woff2') format('woff2');
    font-weight: 100 900;
    font-display: swap; /* Show fallback immediately, swap when loaded */
  }

  /* Fallback font stack with size-adjust for minimal FOUT */
  @font-face {
    font-family: 'Inter Fallback';
    src: local('Arial');
    size-adjust: 107%;
    ascent-override: 90%;
    descent-override: 20%;
  }
</style>

<script>
  // Preload critical fonts
  const fontPreload = document.createElement('link');
  fontPreload.rel = 'preload';
  fontPreload.as = 'font';
  fontPreload.href = '/fonts/Inter-Variable.woff2';
  fontPreload.type = 'font/woff2';
  fontPreload.crossOrigin = 'anonymous';
  document.head.appendChild(fontPreload);
</script>
```

---

## 6. TYPOGRAPHY CHECKLIST

```yaml
typography_checklist:
  readability:
    - "Body text size: 16px minimum (18px+ preferred)"
    - "Line height: 1.5-1.7 for body, 1.1-1.3 for display"
    - "Measure: 45-75 characters per line"
    - "Paragraph spacing: 1.5x line height or more"
    - "Contrast ratio: 4.5:1 minimum for body text"
    - "Font weight: 400 minimum for body, 300 only for large text"
    - "Letter spacing: 0 for body, -0.02em for display, +0.05em for uppercase"

  hierarchy:
    - "Clear size difference between levels (min 1.25x ratio)"
    - "Weight difference between levels (min 100 weight units)"
    - "Consistent spacing rhythm (8px grid)"
    - "Maximum 6 heading levels"
    - "Visual weight decreases with each level"

  accessibility:
    - "Scalable to 200% without breaking layout"
    - "Respects user font preferences (prefers-reduced-motion)"
    - "Screen reader compatible (semantic HTML)"
    - "Color not sole means of conveying information"
    - "Links underlined or clearly distinguishable"

  performance:
    - "Variable fonts preferred over multiple files"
    - "Font subsetting for used characters"
    - "Woff2 format (30% smaller than woff)"
    - "Font-display: swap for non-critical"
    - "Preload only critical fonts (2-3 max)"
    - "Lazy load below-fold fonts"

  brand:
    - "Consistent font families across all touchpoints"
    - "Licensed for all use cases (web, app, print)"
    - "Supports all required languages and scripts"
    - "OpenType features utilized where appropriate"
    - "Fallback fonts specified with similar metrics"
```

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: Typography Handbook*
