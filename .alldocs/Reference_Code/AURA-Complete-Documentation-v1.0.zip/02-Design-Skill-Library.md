# AURA Design Skill Library
## Complete AI Skill Specifications v1.0

---

## SKILL ARCHITECTURE

Each skill is a self-contained, composable AI capability with:
- **Intent Parser:** Natural language → structured design operations
- **Knowledge Base:** Domain-specific design rules and best practices
- **Execution Engine:** Programmatic design generation and manipulation
- **Validation Layer:** QA checks and self-correction
- **Feedback Loop:** Learning from user corrections and preferences

```
Skill
├── Metadata
│   ├── id, name, version, category
│   ├── dependencies (other skills required)
│   ├── input_schema (JSON Schema)
│   └── output_schema (JSON Schema)
├── Intent Parser (LLM + structured generation)
│   ├── Examples (few-shot prompts)
│   ├── Constraints (business rules)
│   └── Fallback (clarification questions)
├── Knowledge Base (RAG + vector DB)
│   ├── Design Rules (hard constraints)
│   ├── Best Practices (soft guidelines)
│   ├── Examples (reference designs)
│   └── Anti-patterns (what to avoid)
├── Execution Engine
│   ├── Template Selector
│   ├── Layout Generator
│   ├── Content Generator
│   ├── Asset Selector
│   └── Composition Engine
└── Validation Layer
    ├── Technical Checks (resolution, format, bleed)
    ├── Design Checks (hierarchy, balance, contrast)
    ├── Brand Checks (colors, fonts, voice)
    └── Accessibility Checks (WCAG, readability)
```

---

## 1. TYPOGRAPHY SKILL

### 1.1 Purpose
Generate, analyze, and optimize typographic systems for any design context.

### 1.2 Capabilities

| Capability | Description | Input | Output |
|-----------|-------------|-------|--------|
| Font Pairing | Match complementary typefaces | Mood, industry, hierarchy | Primary + Secondary + Accent fonts |
| Scale Generation | Create modular type scale | Base size, ratio (1.25/1.414/1.618) | 8-12 size tokens |
| Layout Optimization | Adjust tracking, leading, measure | Text content, container width | Optimized text block |
| Kerning Analysis | Identify and fix kerning issues | Text string, font | Kerning pairs + values |
| Hierarchy Design | Establish visual hierarchy | Content outline, importance levels | Styled text blocks |
| Responsive Typography | Scale type across breakpoints | Base scale, breakpoints | Per-breakpoint scales |
| Web Font Loading | Optimize font loading strategy | Font list, weights | CSS + preload strategy |
| Variable Font Config | Set variable font axes | Font, design intent | Axis values + CSS |
| Text Animation | Generate CSS/JS text animations | Animation type, duration | Animation code |
| Brand Typography | Create brand type system | Brand personality, industry | Type system + guidelines |

### 1.3 Design Rules

```yaml
rules:
  - rule: "Maximum line length for body text"
    value: "45-75 characters (ideal: 66)"
    priority: high

  - rule: "Line height by text size"
    formula: "lineHeight = fontSize * (1.4 + 0.1 * log(fontSize/16))"
    rationale: "Larger text needs tighter line height"

  - rule: "Minimum contrast for text"
    standard: "WCAG 2.1 AA"
    normal_text: "4.5:1"
    large_text: "3:1"

  - rule: "Font pairing mood mapping"
    mappings:
      "modern + trustworthy": ["Inter", "Source Serif Pro"]
      "playful + creative": ["Poppins", "Space Grotesk"]
      "luxury + elegant": ["Cormorant Garamond", "Montserrat"]
      "technical + precise": ["JetBrains Mono", "Roboto"]
      "friendly + approachable": ["Nunito", "Merriweather"]

  - rule: "Modular scale ratios"
    ratios:
      minor_second: 1.067
      major_second: 1.125
      minor_third: 1.200
      major_third: 1.250
      perfect_fourth: 1.333
      augmented_fourth: 1.414
      perfect_fifth: 1.500
      golden_ratio: 1.618

  - rule: "Tracking adjustments"
    uppercase: "+0.05em to +0.1em"
    small_caps: "+0.02em"
    body: "0 (font default)"
    display: "-0.02em to -0.05em"

  - rule: "Font loading performance"
    max_fonts: 3
    max_weights: 4
    preload_critical: true
    font_display: "swap"
```

### 1.4 Execution Examples

```json
{
  "skill": "typography",
  "action": "generate_scale",
  "input": {
    "base_size": 16,
    "ratio": 1.250,
    "scale_name": "Major Third",
    "levels": ["display-1", "display-2", "h1", "h2", "h3", "body", "small", "caption"]
  },
  "output": {
    "tokens": {
      "display-1": { "size": "61.04px", "lineHeight": "1.1", "weight": 700, "letterSpacing": "-0.02em" },
      "display-2": { "size": "48.83px", "lineHeight": "1.15", "weight": 700, "letterSpacing": "-0.02em" },
      "h1": { "size": "39.06px", "lineHeight": "1.2", "weight": 600, "letterSpacing": "-0.01em" },
      "h2": { "size": "31.25px", "lineHeight": "1.25", "weight": 600, "letterSpacing": "-0.01em" },
      "h3": { "size": "25.00px", "lineHeight": "1.3", "weight": 600, "letterSpacing": "0" },
      "body": { "size": "16.00px", "lineHeight": "1.6", "weight": 400, "letterSpacing": "0" },
      "small": { "size": "12.80px", "lineHeight": "1.5", "weight": 400, "letterSpacing": "0.01em" },
      "caption": { "size": "10.24px", "lineHeight": "1.4", "weight": 400, "letterSpacing": "0.02em" }
    }
  }
}
```

---

## 2. BRAND DESIGN SKILL

### 2.1 Purpose
Create, analyze, and maintain comprehensive brand identity systems.

### 2.2 Capabilities

| Capability | Description | Input | Output |
|-----------|-------------|-------|--------|
| Brand Strategy | Define brand positioning | Business info, audience, competitors | Brand strategy doc |
| Visual Identity | Create logo, colors, typography | Brand strategy | Brand guidelines |
| Brand Voice | Define tone, vocabulary, messaging | Brand personality | Voice guidelines |
| Asset Generation | Generate brand assets | Brand guidelines, specs | Logo variants, patterns |
| Brand Compliance | Check design against brand | Design, brand kit | Compliance report |
| Rebrand | Update existing brand | Current brand, new strategy | Updated guidelines |
| Brand System | Create design token system | Brand guidelines | JSON/CSS tokens |
| Brand Templates | Generate branded templates | Brand kit, template types | Template library |

### 2.3 Design Rules

```yaml
rules:
  - rule: "Logo minimum clear space"
    formula: "clearSpace = logoHeight * 0.25"
    priority: critical

  - rule: "Logo minimum size"
    print: "20mm width"
    digital: "120px width"

  - rule: "Color usage ratios"
    primary: "60%"
    secondary: "30%"
    accent: "10%"

  - rule: "Brand color accessibility"
    primary_on_white: "WCAG AA (4.5:1)"
    primary_on_dark: "WCAG AA (4.5:1)"

  - rule: "Logo misuse prevention"
    forbidden:
      - "Stretch or distort"
      - "Change colors (except approved variants)"
      - "Add effects (shadows, glows, outlines)"
      - "Place on busy backgrounds"
      - "Rotate or tilt"

  - rule: "Brand consistency check"
    checks:
      - "Primary color within 3% of brand value"
      - "Fonts from approved family list"
      - "Logo usage follows guidelines"
      - "Spacing follows 8px grid"
```

---

## 3. LOGO DESIGN SKILL

### 3.1 Purpose
Generate, refine, and export logo designs with full technical specifications.

### 3.2 Capabilities

| Capability | Description | Input | Output |
|-----------|-------------|-------|--------|
| Concept Generation | Generate logo concepts | Brand name, industry, style | 6-12 concepts |
| Style Analysis | Recommend logo style | Brand personality, industry | Style recommendation |
| Vector Refinement | Clean up and optimize paths | Concept sketch | Production-ready SVG |
| Color Variants | Generate color variations | Logo, brand palette | Full color set |
| Responsive Logo | Create adaptive logo system | Logo, breakpoints | Logo variants per size |
| Animation | Create logo animation | Logo, animation style | Lottie / CSS / SVG anim |
| Export Package | Generate all export formats | Logo | PNG, SVG, EPS, PDF, favicon |
| Trademark Check | Preliminary similarity check | Logo concept | Similarity report |

### 3.3 Logo Types & Best Practices

```yaml
logo_types:
  wordmark:
    description: "Text-only logo"
    best_for: ["Strong name recognition", "Premium brands", "Fashion"]
    examples: ["Google", "Coca-Cola", "Disney"]

  lettermark:
    description: "Initials or acronym"
    best_for: ["Long names", "Tech companies", "Government"]
    examples: ["IBM", "HBO", "NASA"]

  pictorial:
    description: "Recognizable image/icon"
    best_for: ["Global brands", "App icons", "Consumer goods"]
    examples: ["Apple", "Twitter", "Shell"]

  abstract:
    description: "Abstract geometric form"
    best_for: ["Tech startups", "Innovation", "Diverse services"]
    examples: ["Nike", "Pepsi", "Adidas"]

  mascot:
    description: "Character or figure"
    best_for: ["Family brands", "Sports", "Food"]
    examples: ["KFC", "MailChimp", "Pringles"]

  combination:
    description: "Text + symbol combined"
    best_for: ["New brands", "Versatility", "Recognition building"]
    examples: ["Burger King", "Doritos", "Lacoste"]

  emblem:
    description: "Text inside symbol/shape"
    best_for: ["Traditional", "Schools", "Organizations"]
    examples: ["Harvard", "Starbucks", "NFL"]

  dynamic:
    description: "Adaptable, changing form"
    best_for: ["Creative agencies", "Media", "Tech"]
    examples: ["MTV", "AOL", "City of Melbourne"]
```

---

## 4. LAYOUT DESIGN SKILL

### 4.1 Purpose
Generate intelligent, responsive, and aesthetically pleasing layouts for any design context.

### 4.2 Capabilities

| Capability | Description | Input | Output |
|-----------|-------------|-------|--------|
| Grid Generation | Create layout grids | Content, dimensions, style | Grid system |
| Composition | Arrange elements aesthetically | Elements, canvas, rules | Composed layout |
| Responsive Layout | Adapt layout to breakpoints | Base layout, breakpoints | Responsive system |
| Auto Layout | Generate flex/grid layouts | Content, constraints | CSS/JSON layout |
| Magazine Layout | Editorial-style layouts | Content, images, style | Page layout |
| Dashboard Layout | Data visualization layouts | Widgets, data types | Dashboard grid |
| Landing Page | Marketing page layouts | Sections, goals | Page wireframe |
| Print Layout | Book/magazine page layouts | Content, format, margins | Print-ready layout |

### 4.3 Composition Rules

```yaml
composition_rules:
  - rule: "Rule of Thirds"
    description: "Divide canvas into 3x3 grid, place focal points at intersections"
    priority: high

  - rule: "Golden Ratio"
    formula: "phi = 1.618"
    applications:
      - "Canvas division: 61.8% / 38.2%"
      - "Spiral placement for focal points"
      - "Typography scale ratios"

  - rule: "Visual Hierarchy"
    techniques:
      - "Size: Larger elements attract more attention"
      - "Weight: Bold text draws eye first"
      - "Color: High contrast colors stand out"
      - "Position: Top-left (LTR) is entry point"
      - "Whitespace: Isolation increases importance"

  - rule: "Alignment"
    types:
      - "Edge alignment: Creates order and structure"
      - "Center alignment: Creates formal, balanced feel"
      - "Baseline alignment: Essential for text blocks"
      - "Optical alignment: Adjust for visual weight"

  - rule: "Proximity"
    description: "Related elements should be closer together than unrelated elements"
    spacing_ratio: "Related: 8-16px, Unrelated: 32-64px"

  - rule: "Balance"
    types:
      - "Symmetrical: Formal, stable, conservative"
      - "Asymmetrical: Dynamic, interesting, modern"
      - "Radial: Focus on center, energetic"
      - "Mosaic: Complex, artistic, eclectic"

  - rule: "F-Pattern (Web)"
    description: "Users scan web pages in F-shape: top horizontal, then down left side"
    application: "Place important content along F-path"

  - rule: "Z-Pattern (Web)"
    description: "Users scan in Z-shape: top-left → top-right → diagonal → bottom-left → bottom-right"
    application: "Place CTA at bottom-right after Z-path"
```

---

## 5. SOCIAL MEDIA DESIGN SKILL

### 5.1 Purpose
Generate optimized designs for all social media platforms with platform-specific best practices.

### 5.2 Platform Specifications

```yaml
platforms:
  instagram:
    post: { width: 1080, height: 1080, aspect: "1:1", safe_zone: "all" }
    story: { width: 1080, height: 1920, aspect: "9:16", safe_zone: "center 1080x1420" }
    reel: { width: 1080, height: 1920, aspect: "9:16", safe_zone: "center 1080x1420" }
    carousel: { width: 1080, height: 1080, aspect: "1:1", max_slides: 10 }

  facebook:
    post: { width: 1200, height: 630, aspect: "1.91:1" }
    cover: { width: 820, height: 312, aspect: "2.63:1", safe_zone: "center 640x240" }
    story: { width: 1080, height: 1920, aspect: "9:16" }
    ad: { width: 1200, height: 628, aspect: "1.91:1" }

  twitter:
    post: { width: 1200, height: 675, aspect: "16:9" }
    header: { width: 1500, height: 500, aspect: "3:1", safe_zone: "center 1200x400" }
    card: { width: 800, height: 418, aspect: "1.91:1" }

  linkedin:
    post: { width: 1200, height: 627, aspect: "1.91:1" }
    cover: { width: 1584, height: 396, aspect: "4:1", safe_zone: "center 1200x300" }
    article: { width: 1200, height: 644, aspect: "1.86:1" }

  tiktok:
    video: { width: 1080, height: 1920, aspect: "9:16", safe_zone: "center 1080x1500" }
    profile: { width: 200, height: 200, aspect: "1:1" }

  youtube:
    thumbnail: { width: 1280, height: 720, aspect: "16:9" }
    banner: { width: 2560, height: 1440, aspect: "16:9", safe_zone: "center 1546x423" }

  pinterest:
    pin: { width: 1000, height: 1500, aspect: "2:3" }
    idea_pin: { width: 1080, height: 1920, aspect: "9:16" }
```

### 5.3 Design Rules

```yaml
social_media_rules:
  - rule: "Text overlay limit"
    facebook: "<20% of image area for ads"
    general: "Keep text minimal, use caption"

  - rule: "Brand placement"
    logo: "Top-left or bottom-right, 8-10% of width"
    watermark: "Subtle, 10-15% opacity"

  - rule: "Safe zones"
    description: "Keep critical content within safe zones to avoid cropping"
    instagram_story: "108px top/bottom padding"
    youtube_banner: "Safe zone is 1546x423 centered"

  - rule: "Thumbnail psychology"
    principles:
      - "Faces attract attention (eye contact preferred)"
      - "High contrast and saturation"
      - "Clear, large text (3-5 words max)"
      - "Emotional expressions increase CTR"
      - "Consistent branding across series"

  - rule: "Carousel design"
    principles:
      - "First slide must hook in 1 second"
      - "Each slide should be self-contained"
      - "Use consistent visual language"
      - "End with CTA on last slide"
      - "Number slides (1/5, 2/5, etc.)"
```

---

## 6. PRESENTATION DESIGN SKILL

### 6.1 Purpose
Create professional, engaging presentation decks with narrative structure and visual consistency.

### 6.2 Slide Types & Templates

```yaml
slide_types:
  title:
    purpose: "Opening slide, establish topic"
    elements: ["Title", "Subtitle", "Presenter", "Date"]
    layout: "Centered or left-aligned, generous whitespace"

  agenda:
    purpose: "Preview what will be covered"
    elements: ["Section list", "Timeline", "Progress indicator"]
    layout: "Clean list or visual timeline"

  content:
    purpose: "Main information delivery"
    elements: ["Heading", "Body text", "Supporting visual"]
    layout: "50/50 text-visual or full-width with overlay"

  data:
    purpose: "Present statistics and charts"
    elements: ["Chart", "Key insight", "Context"]
    layout: "Chart dominant with annotation"

  quote:
    purpose: "Emphasize key statement"
    elements: ["Quote text", "Attribution", "Background visual"]
    layout: "Large text centered, minimal other elements"

  comparison:
    purpose: "Compare two or more items"
    elements: ["Items", "Comparison criteria", "Visual indicators"]
    layout: "Side-by-side columns or table"

  process:
    purpose: "Show sequence or workflow"
    elements: ["Steps", "Arrows/connectors", "Descriptions"]
    layout: "Horizontal flow, vertical stack, or circular"

  closing:
    purpose: "Call to action, summary, contact"
    elements: ["Summary", "CTA", "Contact info", "Q&A prompt"]
    layout: "Clean, memorable, actionable"
```

### 6.3 Design Rules

```yaml
presentation_rules:
  - rule: "6x6 Rule"
    description: "Max 6 bullet points, max 6 words per bullet"
    rationale: "Cognitive load management"

  - rule: "Font size hierarchy"
    title: "44-60pt"
    subtitle: "28-36pt"
    body: "18-24pt"
    caption: "14-16pt"

  - rule: "Slide count"
    guideline: "1 minute per slide (average)"
    pitch_deck: "10-15 slides"
    training: "1 slide per 2-3 minutes"

  - rule: "Visual consistency"
    requirements:
      - "Same fonts throughout"
      - "Same color palette (3-5 colors)"
      - "Same layout grid"
      - "Consistent image style"
      - "Logo on every slide (subtle)"

  - rule: "Data visualization"
    principles:
      - "Choose right chart type for data"
      - "Max 3-4 data series per chart"
      - "Label directly, avoid legends when possible"
      - "Use color intentionally (highlight key data)"
      - "Start y-axis at 0 for bar charts"
```

---

## 7. POSTER DESIGN SKILL

### 7.1 Purpose
Create impactful, readable posters for print and digital display.

### 7.2 Poster Types

```yaml
poster_types:
  event:
    purpose: "Promote an event"
    key_info: ["Event name", "Date", "Time", "Location", "Ticket info"]
    hierarchy: "Name > Date > Visual > Details"

  informational:
    purpose: "Educate or inform"
    key_info: ["Title", "Body content", "Visuals", "Sources"]
    hierarchy: "Title > Visuals > Body > Sources"

  promotional:
    purpose: "Sell a product or service"
    key_info: ["Product", "Benefit", "Price", "CTA", "Brand"]
    hierarchy: "Product/Visual > Benefit > CTA > Price"

  academic:
    purpose: "Present research findings"
    key_info: ["Title", "Abstract", "Methods", "Results", "Conclusion"]
    hierarchy: "Title > Results > Conclusion > Methods"

  political:
    purpose: "Advocate or campaign"
    key_info: ["Message", "Candidate/Issue", "Call to action"]
    hierarchy: "Message > Visual > Call to action"
```

### 7.3 Design Rules

```yaml
poster_rules:
  - rule: "3-second rule"
    description: "Viewer should understand main message in 3 seconds from 2 meters away"

  - rule: "Reading distance"
    minimum_text_size: "24pt at 100% scale for 2m viewing"
    title: "72pt+"
    subtitle: "48pt+"
    body: "24pt+"
    caption: "18pt+"

  - rule: "Visual hierarchy for posters"
    order:
      - "1. Focal image or headline (largest)"
      - "2. Supporting information (medium)"
      - "3. Details (smallest)"
      - "4. Brand/logo (consistent placement)"

  - rule: "Print specifications"
    resolution: "300 DPI minimum"
    color_mode: "CMYK"
    bleed: "3mm"
    safe_zone: "5mm from trim"

  - rule: "Digital poster specs"
    resolution: "72-150 DPI"
    color_mode: "sRGB"
    formats: ["PNG", "JPEG", "PDF"]
```

---

## 8. MARKETING DESIGN SKILL

### 8.1 Purpose
Create conversion-optimized marketing materials across all channels.

### 8.2 Marketing Funnel Design Mapping

```yaml
funnel_stages:
  awareness:
    materials: ["Social ads", "Display banners", "Video ads"]
    design_focus: "Attention-grabbing, brand recognition"
    metrics: ["Impressions", "CTR", "Brand recall"]

  interest:
    materials: ["Landing pages", "Ebooks", "Infographics"]
    design_focus: "Informative, trustworthy, visually engaging"
    metrics: ["Time on page", "Bounce rate", "Content downloads"]

  consideration:
    materials: ["Comparison sheets", "Case studies", "Webinars"]
    design_focus: "Professional, data-driven, credible"
    metrics: ["Pages per session", "Return visits", "Email signups"]

  conversion:
    materials: ["Sales pages", "Checkout flows", "Email campaigns"]
    design_focus: "Clear CTA, trust signals, urgency"
    metrics: ["Conversion rate", "AOV", "Cart abandonment"]

  retention:
    materials: ["Newsletters", "Loyalty cards", "App UI"]
    design_focus: "Personalized, valuable, consistent"
    metrics: ["Open rate", "Retention rate", "NPS"]
```

### 8.3 CTA Design Rules

```yaml
cta_rules:
  - rule: "Button contrast"
    requirement: "CTA button must have 3:1 contrast with background"

  - rule: "Button size"
    minimum: "44x44px touch target"
    optimal: "120-200px width, 44-56px height"

  - rule: "Button text"
    principles:
      - "Use action verbs (Get, Start, Download, Join)"
      - "Create urgency (Limited, Now, Today)"
      - "Be specific (Get Free Guide vs Click Here)"
      - "Keep to 2-4 words"

  - rule: "Button placement"
    principles:
      - "Above the fold for primary CTA"
      - "Repeated after value demonstration"
      - "Isolated from other actions"
      - "Follows natural reading flow"
```

---

## 9. UI DESIGN SKILL

### 9.1 Purpose
Design intuitive, accessible, and aesthetically pleasing user interfaces.

### 9.2 Component System

```yaml
component_categories:
  navigation:
    components: ["Navbar", "Sidebar", "Tabs", "Breadcrumbs", "Pagination"]
    principles: ["Clear hierarchy", "Consistent placement", "Active state indication"]

  input:
    components: ["Text field", "Dropdown", "Checkbox", "Radio", "Toggle", "Slider"]
    principles: ["Clear labels", "Error states", "Focus states", "Accessible"]

  feedback:
    components: ["Alert", "Toast", "Modal", "Progress", "Skeleton"]
    principles: ["Clear messaging", "Actionable", "Non-blocking when possible"]

  data_display:
    components: ["Table", "Card", "List", "Chart", "Calendar"]
    principles: ["Scannable", "Sortable/filterable", "Responsive"]

  action:
    components: ["Button", "Icon button", "FAB", "Menu"]
    principles: ["Clear affordance", "Consistent style", "Loading states"]
```

### 9.3 Design Rules

```yaml
ui_rules:
  - rule: "8px Grid System"
    base_unit: 8px
    spacing_scale: [8, 16, 24, 32, 48, 64, 96, 128]

  - rule: "Touch targets"
    minimum: "44x44px"
    optimal: "48x48px"
    spacing: "8px minimum between targets"

  - rule: "Color usage in UI"
    primary: "CTAs, active states, key actions"
    secondary: "Supporting actions, less emphasis"
    success: "Positive feedback, completion"
    warning: "Caution, needs attention"
    error: "Errors, destructive actions"
    info: "Neutral information, tips"

  - rule: "Form design"
    principles:
      - "Label above input (not placeholder)"
      - "Group related fields"
      - "Show progress for multi-step"
      - "Validate inline, not on submit"
      - "Use autocomplete attributes"

  - rule: "Loading states"
    principles:
      - "Never show blank screen"
      - "Use skeleton screens for content"
      - "Show progress for known duration"
      - "Provide cancel option for long operations"
```

---

## 10. INFOGRAPHIC DESIGN SKILL

### 10.1 Purpose
Transform complex data and information into visually compelling, easily digestible graphics.

### 10.2 Infographic Types

```yaml
infographic_types:
  statistical:
    purpose: "Show data and numbers"
    charts: ["Bar", "Line", "Pie", "Donut", "Area", "Scatter"]
    best_for: ["Reports", "Surveys", "Analytics"]

  timeline:
    purpose: "Show chronological sequence"
    layouts: ["Horizontal", "Vertical", "Spiral", "Roadmap"]
    best_for: ["History", "Project plans", "Biographies"]

  process:
    purpose: "Show steps or workflow"
    layouts: ["Linear", "Circular", "Branching", "Swimlane"]
    best_for: ["How-to", "Manufacturing", "User flows"]

  comparison:
    purpose: "Compare two or more items"
    layouts: ["Side-by-side", "Venn diagram", "Table", "Matrix"]
    best_for: ["Product comparison", "Pros/cons", "Features"]

  hierarchical:
    purpose: "Show relationships and structure"
    layouts: ["Tree", "Pyramid", "Org chart", "Mind map"]
    best_for: ["Organization", "Classification", "Decision trees"]

  location:
    purpose: "Show geographic data"
    elements: ["Map", "Heatmap", "Route", "Regional data"]
    best_for: ["Demographics", "Travel", "Real estate"]

  list:
    purpose: "Organize information in list form"
    styles: ["Numbered", "Icon-based", "Illustrated", "Timeline-list"]
    best_for: ["Tips", "Features", "Rankings"]
```

### 10.3 Data Visualization Rules

```yaml
data_viz_rules:
  - rule: "Chart selection"
    guidelines:
      - "Comparison: Bar chart (categorical), Line chart (trend)"
      - "Composition: Pie chart (simple), Stacked bar (complex)"
      - "Distribution: Histogram, Box plot, Violin plot"
      - "Relationship: Scatter plot, Bubble chart, Heatmap"
      - "Geographic: Choropleth, Dot map, Flow map"

  - rule: "Color in data viz"
    principles:
      - "Use sequential for ordered data (light to dark)"
      - "Use diverging for data with midpoint"
      - "Use qualitative for categories"
      - "Max 7 colors in single chart"
      - "Consider colorblind accessibility"

  - rule: "Labeling"
    principles:
      - "Direct label when possible (avoid legends)"
      - "Use consistent number formatting"
      - "Show units and context"
      - "Title should tell the story"
      - "Annotate key insights"
```

---

## 11. PRINT DESIGN SKILL

### 11.1 Purpose
Create production-ready print materials with correct technical specifications.

### 11.2 Print Specifications

```yaml
print_specifications:
  business_card:
    standard_us: { width: "3.5in", height: "2in", bleed: "0.125in", safe: "0.125in" }
    standard_eu: { width: "85mm", height: "55mm", bleed: "3mm", safe: "3mm" }
    resolution: "300 DPI"
    color_mode: "CMYK"

  flyer:
    standard_us: { width: "8.5in", height: "11in", bleed: "0.125in" }
    standard_a4: { width: "210mm", height: "297mm", bleed: "3mm" }
    resolution: "300 DPI"
    color_mode: "CMYK"

  brochure:
    tri_fold: { width: "11in", height: "8.5in", panels: 3, fold: "letter" }
    bi_fold: { width: "17in", height: "11in", panels: 4, fold: "half" }
    resolution: "300 DPI"
    color_mode: "CMYK"

  poster:
    small: { width: "11in", height: "17in" }
    medium: { width: "18in", height: "24in" }
    large: { width: "24in", height: "36in" }
    resolution: "300 DPI"
    color_mode: "CMYK"

  banner:
    retractable: { width: "33in", height: "80in" }
    vinyl: { width: "48in", height: "96in" }
    resolution: "150 DPI"
    color_mode: "CMYK"

  book:
    paperback: { width: "6in", height: "9in", bleed: "0.125in" }
    hardcover: { width: "6.14in", height: "9.21in", bleed: "0.125in" }
    resolution: "300 DPI"
    color_mode: "CMYK"

  magazine:
    standard: { width: "8.5in", height: "11in", bleed: "0.125in" }
    resolution: "300 DPI"
    color_mode: "CMYK"
```

### 11.3 Technical Rules

```yaml
print_technical_rules:
  - rule: "Color mode"
    requirement: "CMYK for all print materials"
    rgb_conversion: "Use ICC profile ISO Coated v2 or GRACoL 2006"

  - rule: "Resolution"
    standard: "300 DPI at final size"
    large_format: "150 DPI minimum (viewed from distance)"
    bitmap: "600-1200 DPI"

  - rule: "Bleed"
    standard: "3mm (0.125in)"
    large_format: "5-10mm"

  - rule: "Safe zone"
    standard: "5mm from trim edge"
    text_safe: "10mm from trim edge"

  - rule: "Font embedding"
    requirement: "Subset embed all fonts"
    outline: "Alternative: convert to outlines (loses editability)"

  - rule: "Image formats"
    preferred: "TIFF (uncompressed or LZW)"
    acceptable: "High-quality JPEG (quality 10-12)"
    avoid: "PNG, GIF, low-quality JPEG"

  - rule: "Black text"
    requirement: "100% K (not rich black)"
    rich_black: "C60 M40 Y40 K100 (for large areas only)"

  - rule: "Total ink coverage"
    coated: "320% maximum"
    uncoated: "260% maximum"
    newsprint: "240% maximum"
```

---

## 12. PACKAGING DESIGN SKILL

### 12.1 Purpose
Design product packaging that is functional, compliant, and brand-aligned.

### 12.2 Packaging Types

```yaml
packaging_types:
  box:
    types: ["Folding carton", "Rigid box", "Corrugated", "Sleeve"]
    considerations: ["Dieline", "Glue flaps", "Tuck flaps", "Window cutouts"]

  bottle:
    types: ["Glass", "PET", "HDPE", "Aluminum"]
    considerations: ["Label dimensions", "Curvature", "Shrink sleeve"]

  bag:
    types: ["Stand-up pouch", "Flat pouch", "Gusseted bag", "Tote"]
    considerations: ["Sealing area", "Zipper placement", "Hang hole"]

  label:
    types: ["Pressure sensitive", "Shrink", "In-mold", "Wrap-around"]
    considerations: ["Adhesive area", "Release liner", "Die cut shape"]

  tube:
    types: ["Laminate", "Aluminum", "Plastic"]
    considerations: ["Shoulder design", "Cap fit", "Crimp area"]
```

### 12.3 Design Rules

```yaml
packaging_rules:
  - rule: "Dieline accuracy"
    requirement: "All dimensions must be exact to 0.1mm"
    bleed: "5mm on dieline"

  - rule: "Barcode placement"
    requirements:
      - "Quiet zone: 3mm minimum on all sides"
      - "Size: 80-200% of standard (26.26mm x 18.28mm at 100%)"
      - "Color: Dark on light (not reversed)"
      - "Avoid: Curved surfaces, transparent backgrounds"

  - rule: "Nutritional information"
    requirements:
      - "Follow FDA/EU regulations for format"
      - "Minimum font size: 1.2mm x-height"
      - "Must be legible and permanent"

  - rule: "Sustainability indicators"
    common: ["Recycling symbol", "Material code", "Compostable mark"]
    placement: "Visible, not obstructed"
```

---

## 13. PHOTO MANIPULATION SKILL

### 13.1 Purpose
Advanced photo editing, compositing, and creative manipulation with AI assistance.

### 13.2 Capabilities

| Capability | Description | Technique |
|-----------|-------------|-----------|
| Background Replacement | Change photo background | Segmentation + generative fill |
| Object Removal | Remove unwanted objects | Inpainting + content-aware |
| Color Grading | Apply cinematic color looks | LUT + curves + selective color |
| Skin Retouching | Professional skin smoothing | Frequency separation + AI |
| Composite | Merge multiple photos | Masking + blending + matching |
| Perspective Correction | Fix architectural perspective | Vanishing point + warp |
| HDR Merge | Combine exposure brackets | Tone mapping + alignment |
| Panorama | Stitch multiple photos | Feature matching + blending |
| Focus Stacking | Extended depth of field | Alignment + masking + blending |
| Sky Replacement | Replace sky with AI | Segmentation + generative |

### 13.3 Frequency Separation

```
Algorithm:
1. Create two copies of image
2. Low Frequency (Blur):
   - Gaussian blur: radius = 20-40px
   - Contains color and tone
3. High Frequency (Detail):
   - Original - Low Frequency
   - Contains texture and detail
4. Retouch:
   - Skin tone: edit on Low Frequency layer
   - Pores/texture: edit on High Frequency layer
5. Merge: Low + High = Final
```

---

## 14. PHOTO RETOUCH SKILL

### 14.1 Purpose
Professional portrait and product photo retouching with natural results.

### 14.2 Retouching Workflow

```yaml
retouching_workflow:
  1_cleanup:
    tools: ["Spot healing", "Clone stamp", "Patch tool"]
    targets: ["Blemishes", "Dust", "Stray hairs", "Wrinkles (subtle)"]

  2_skin:
    techniques: ["Frequency separation", "Dodge and burn", "Color correction"]
    targets: ["Uneven tone", "Shadows", "Highlights", "Redness"]

  3_eyes:
    techniques: ["Sharpening", "Whitening", "Iris enhancement", "Catch light"]
    targets: ["Sclera", "Iris", "Pupil", "Eyelashes"]

  4_teeth:
    techniques: ["Selective desaturation", "Lightening"]
    targets: ["Yellow tones", "Shadows between teeth"]

  5_hair:
    techniques: ["Smoothing", "Volume enhancement", "Stray removal"]
    targets: ["Frizz", "Flyaways", "Dullness"]

  6_color:
    techniques: ["Color grading", "Selective color", "Split toning"]
    targets: ["Skin tone", "Background", "Clothing"]

  7_sharpening:
    techniques: ["High pass", "Smart sharpen", "Output sharpening"]
    targets: ["Eyes", "Hair", "Clothing texture"]
```

---

## 15. COLOR GRADING SKILL

### 15.1 Purpose
Apply professional color grading to photos and videos with cinematic looks.

### 15.2 Grading Techniques

```yaml
color_grading_techniques:
  - name: "Teal and Orange"
    description: "Push shadows toward teal, highlights toward orange"
    use_case: "Cinematic, blockbuster look"
    tools: ["Split toning", "Color balance", "Selective color"]

  - name: " bleach bypass"
    description: "High contrast, desaturated, silver retention look"
    use_case: "Dramatic, gritty, war films"
    tools: ["Curves", "Saturation reduction", "Contrast boost"]

  - name: "Day for Night"
    description: "Convert daylight footage to night look"
    use_case: "Budget filmmaking, VFX"
    tools: ["Color balance (blue)", "Contrast", "Desaturation", "Vignette"]

  - name: "Vintage / Film"
    description: "Warm tones, faded blacks, film grain"
    use_case: "Nostalgic, romantic, lifestyle"
    tools: ["Lift blacks", "Warm highlights", "Grain overlay", "Vignette"]

  - name: "High Key"
    description: "Bright, low contrast, minimal shadows"
    use_case: "Beauty, fashion, clean aesthetic"
    tools: ["Lift shadows", "Reduce contrast", "Bright exposure"]

  - name: "Low Key"
    description: "Dark, high contrast, dramatic shadows"
    use_case: "Drama, horror, noir"
    tools: ["Crush shadows", "Boost contrast", "Selective lighting"]

  - name: "Cross Processing"
    description: "Process in wrong chemistry for color shift"
    use_case: "Experimental, editorial, artistic"
    tools: ["Curves (RGB channels)", "Color balance", "Hue shift"]

  - name: "Monochrome"
    description: "Black and white with tonal control"
    use_case: "Timeless, dramatic, documentary"
    tools: ["B&W conversion", "Color filter simulation", "Dodge and burn"]
```

---

## 16. IMAGE ENHANCEMENT SKILL

### 16.1 Purpose
Automatically improve image quality using AI and traditional techniques.

### 16.2 Enhancement Pipeline

```yaml
enhancement_pipeline:
  1_analysis:
    checks: ["Exposure", "White balance", "Sharpness", "Noise", "Composition"]

  2_correction:
    exposure: ["Histogram equalization", "Shadow/highlight recovery", "HDR tone mapping"]
    white_balance: ["Auto WB", "Gray point", "Temperature/tint"]

  3_restoration:
    denoise: ["AI denoise", "NLM", "Wavelet", "Median"]
    sharpen: ["AI sharpen", "Unsharp mask", "Deconvolution"]
    upscale: ["AI super-resolution", "Bicubic", "Lanczos"]

  4_enhancement:
    color: ["Vibrance", "Saturation", "Color balance"]
    tone: ["Curves", "Levels", "Clarity", "Dehaze"]

  5_final:
    crop: ["Auto-crop", "Aspect ratio", "Composition fix"]
    output: ["Format optimization", "Metadata", "Color profile"]
```

---

## 17. VISUAL HIERARCHY SKILL

### 17.1 Purpose
Analyze and optimize visual hierarchy in any design for maximum impact and readability.

### 17.2 Hierarchy Factors

```yaml
hierarchy_factors:
  - factor: "Size"
    principle: "Larger elements attract more attention"
    application: "Headlines > Subheads > Body > Captions"

  - factor: "Color"
    principle: "High contrast and saturation draw attention"
    application: "CTAs in brand color, warnings in red"

  - factor: "Contrast"
    principle: "Elements that contrast with surroundings stand out"
    application: "Dark text on light background, colored buttons on neutral"

  - factor: "Alignment"
    principle: "Breaking alignment creates emphasis"
    application: "Pull quote offset from body text"

  - factor: "Repetition"
    principle: "Repeated elements create pattern; breaking it creates emphasis"
    application: "One element in different color in a row"

  - factor: "Proximity"
    principle: "Grouped elements are perceived as related"
    application: "Form labels close to inputs"

  - factor: "Whitespace"
    principle: "Isolation increases importance"
    application: "Hero element with generous padding"

  - factor: "Texture"
    principle: "Complex textures attract more than flat areas"
    application: "Illustrated background behind plain text"

  - factor: "Direction"
    principle: "Lines and arrows guide eye movement"
    application: "Diagonal composition leading to CTA"

  - factor: "Movement"
    principle: "Motion (in digital) captures attention"
    application: "Animated CTA button, video backgrounds"
```

---

## 18. COMPOSITION SKILL

### 18.1 Purpose
Apply classical and modern composition principles to create balanced, engaging designs.

### 18.2 Composition Systems

```yaml
composition_systems:
  - name: "Rule of Thirds"
    grid: "3x3"
    focal_points: "Intersection points"
    use_case: "Photography, general design"

  - name: "Golden Ratio"
    ratio: "1:1.618"
    spiral: "Fibonacci spiral"
    use_case: "Nature-inspired, organic layouts"

  - name: "Golden Triangle"
    method: "Diagonal line + perpendiculars"
    use_case: "Dynamic, diagonal compositions"

  - name: "Dynamic Symmetry"
    root_rectangles: ["√1", "√2", "√3", "√4", "√5", "φ"]
    use_case: "Classical art, editorial"

  - name: "Diagonal Method"
    principle: "Important elements on diagonals"
    use_case: "Square formats, portraits"

  - name: "Center Composition"
    principle: "Focal point in center"
    use_case: "Symmetrical subjects, icons, portraits"

  - name: "Frame within Frame"
    principle: "Use natural or created frames"
    use_case: "Photography, storytelling"

  - name: "Leading Lines"
    principle: "Lines guide eye to focal point"
    use_case: "Architecture, landscape, editorial"

  - name: "Symmetry"
    types: ["Reflection", "Rotational", "Translational", "Bilateral"]
    use_case: "Formal, balanced, architectural"

  - name: "Asymmetry"
    principle: "Unequal visual weight balanced by interest"
    use_case: "Modern, dynamic, editorial"
```

---

## 19. ART DIRECTION SKILL

### 19.1 Purpose
Establish the visual language, mood, and creative direction for design projects.

### 19.2 Art Direction Framework

```yaml
art_direction_framework:
  1_research:
    activities:
      - "Audience analysis (demographics, psychographics)"
      - "Competitor visual audit"
      - "Cultural trend analysis"
      - "Platform behavior study"
      - "Mood board creation"

  2_concept:
    outputs:
      - "Creative brief"
      - "Mood board (visual references)"
      - "Color palette rationale"
      - "Typography rationale"
      - "Photography style guide"
      - "Illustration style guide"

  3_execution:
    activities:
      - "Style guide creation"
      - "Template design"
      - "Asset creation/selection"
      - "Prototype development"

  4_evaluation:
    criteria:
      - "Brand alignment"
      - "Audience resonance"
      - "Platform appropriateness"
      - "Technical feasibility"
      - "Differentiation from competitors"
```

---

## 20. CREATIVE DIRECTION SKILL

### 20.1 Purpose
Oversee the creative vision across campaigns, products, and brand touchpoints.

### 20.2 Creative Direction Process

```yaml
creative_direction_process:
  1_discovery:
    inputs: ["Business objectives", "Brand strategy", "Market research", "User insights"]
    outputs: ["Creative brief", "Problem statement", "Success metrics"]

  2_strategy:
    activities:
      - "Define creative territories"
      - "Develop key messaging"
      - "Establish tone of voice"
      - "Set visual direction"
      - "Create experience principles"

  3_concept:
    activities:
      - "Brainstorm concepts"
      - "Develop visual narratives"
      - "Create concept boards"
      - "Prototype key experiences"
      - "Test with audience"

  4_production:
    activities:
      - "Resource planning"
      - "Timeline management"
      - "Quality assurance"
      - "Stakeholder reviews"
      - "Iteration cycles"

  5_launch:
    activities:
      - "Final asset delivery"
      - "Performance monitoring"
      - "Feedback collection"
      - "Post-launch optimization"
      - "Case study documentation"
```

---

## 21. DESIGN QA SKILL

### 21.1 Purpose
Automated and manual quality assurance for all design outputs.

### 21.2 QA Checklist

```yaml
qa_checklist:
  technical:
    - "Resolution correct for output medium"
    - "Color mode correct (RGB for digital, CMYK for print)"
    - "Bleed and safe zones correct"
    - "Fonts embedded or outlined"
    - "File format appropriate"
    - "File size optimized"
    - "Metadata included"

  design:
    - "Visual hierarchy clear"
    - "Alignment consistent"
    - "Spacing follows grid system"
    - "Color palette harmonious"
    - "Typography readable and appropriate"
    - "Images high quality and relevant"
    - "Composition balanced"
    - "Focal point clear"

  brand:
    - "Logo correct and clear"
    - "Brand colors accurate"
    - "Brand fonts used"
    - "Tone of voice consistent"
    - "Brand guidelines followed"

  content:
    - "Text free of errors (spelling, grammar)"
    - "Information accurate and current"
    - "Contact information correct"
    - "Legal requirements met (disclaimers, copyrights)"
    - "CTA clear and actionable"

  accessibility:
    - "Color contrast meets WCAG standards"
    - "Text size readable (minimum 16px body)"
    - "Color not sole means of conveying information"
    - "Alt text for images (digital)"
    - "Keyboard navigable (digital UI)"

  platform:
    - "Dimensions correct for platform"
    - "Safe zones respected"
    - "File size within limits"
    - "Format supported by platform"
    - "Text within platform limits"
```

---

## 22. ACCESSIBILITY SKILL

### 22.1 Purpose
Ensure all designs meet accessibility standards for inclusive use.

### 22.2 WCAG 2.1 Compliance

```yaml
wcag_compliance:
  perceivable:
    1.1_text_alternatives: "All non-text content has text alternative"
    1.2_time_based_media: "Captions, transcripts, audio descriptions"
    1.3_adaptable: "Content can be presented in different ways"
    1.4_distinguishable: "Content easy to see and hear"

  operable:
    2.1_keyboard_accessible: "All functionality available from keyboard"
    2.2_enough_time: "Users have enough time to read/use content"
    2.3_seizures: "Content does not cause seizures"
    2.4_navigable: "Users can navigate and find content"
    2.5_input_modalities: "Input beyond keyboard supported"

  understandable:
    3.1_readable: "Text readable and understandable"
    3.2_predictable: "Interface behaves predictably"
    3.3_input_assistance: "Help users avoid and correct mistakes"

  robust:
    4.1_compatible: "Content works with assistive technologies"
```

### 22.3 Color Accessibility

```yaml
color_accessibility:
  - rule: "Never rely on color alone"
    requirement: "Use icons, patterns, labels, or text in addition to color"

  - rule: "Colorblind simulation"
    simulations: ["Deuteranopia", "Protanopia", "Tritanopia", "Achromatopsia"]
    requirement: "Design must be distinguishable in all simulations"

  - rule: "Focus indicators"
    requirement: "All interactive elements have visible focus state"
    specification: "2px solid outline with 3:1 contrast"

  - rule: "Text resizing"
    requirement: "Text must be resizable to 200% without loss of content"

  - rule: "Motion sensitivity"
    requirement: "Respect prefers-reduced-motion"
    animation_limits: "No flashing >3Hz, no auto-playing video without pause"
```

---

## 23. TEMPLATE CREATION SKILL

### 23.1 Purpose
Create reusable, intelligent templates that adapt to content and brand.

### 23.2 Template System

```yaml
template_system:
  structure:
    - "Template metadata (name, category, dimensions, version)"
    - "Design structure (layers, groups, elements)"
    - "Variable definitions (type, constraints, defaults)"
    - "Rules engine (conditional visibility, sizing)"
    - "Style references (tokens, brand kit)"
    - "Export presets (formats, resolutions, color modes)"

  variable_types:
    - "text: String with min/max length, formatting"
    - "image: Image with aspect ratio, resolution requirements"
    - "color: Color with palette constraints"
    - "number: Numeric with min/max/step"
    - "boolean: Toggle for conditional elements"
    - "select: Dropdown with predefined options"
    - "date: Date with format specification"
    - "list: Repeating group of elements"

  smart_features:
    - "Auto-fit: Text scales to fit container"
    - "Smart crop: Image cropped to focal point"
    - "Conditional: Show/hide based on variable values"
    - "Responsive: Layout adapts to content length"
    - "Brand sync: Auto-applies brand colors/fonts"
    - "AI fill: Generates content when missing"
```

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: Skill Library Specification*
