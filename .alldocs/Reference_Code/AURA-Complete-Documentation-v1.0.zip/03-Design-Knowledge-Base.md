# AURA Design Knowledge Base
## Comprehensive Design Reference v1.0

---

## 1. DESIGN PRINCIPLES

### 1.1 Universal Design Principles

| Principle | Definition | Application |
|-----------|-----------|-------------|
| **Balance** | Distribution of visual weight | Symmetrical (formal), Asymmetrical (dynamic), Radial (circular) |
| **Contrast** | Difference between elements | Light/dark, large/small, serif/sans, color temperature |
| **Emphasis** | Focal point creation | Size, color, isolation, placement, whitespace |
| **Movement** | Eye path through design | Lines, repetition, progression, gaze direction |
| **Pattern** | Repetition of elements | Consistent spacing, rhythm, texture |
| **Rhythm** | Organized movement | Regular, flowing, progressive, random |
| **Unity** | Cohesion of elements | Proximity, repetition, alignment, theme |
| **Variety** | Visual interest through difference | Color, shape, texture, size variation |
| **Proportion** | Size relationships | Golden ratio, rule of thirds, modular scale |
| **Whitespace** | Empty space as design element | Breathing room, focus, elegance, readability |

### 1.2 Gestalt Principles

| Principle | Description | Example |
|-----------|-------------|---------|
| **Figure-Ground** | Brain separates foreground from background | Logo positive/negative space |
| **Closure** | Brain fills in missing information | Dotted lines forming shape |
| **Proximity** | Near elements are grouped | Navigation menu items |
| **Similarity** | Similar elements are grouped | Same color buttons |
| **Continuity** | Eye follows smooth paths | Lines, curves, alignments |
| **Common Fate** | Moving together = grouped | Animated elements |
| **Symmetry** | Symmetrical elements perceived as unit | Balanced layouts |
| **Prägnanz** | Simplest form is perceived | Minimal logos |
| **Common Region** | Elements in same container grouped | Cards, panels, boxes |
| **Focal Point** | Standout element captures attention | Hero image, CTA button |

### 1.3 Cognitive Load Principles

```
Miller's Law: 7±2 items in working memory
→ Chunk information into groups of 5-9 items

Hick's Law: Decision time increases with options
→ Limit choices, use progressive disclosure

Fitts's Law: Target acquisition time = f(distance, size)
→ Make important targets larger and closer

Jakob's Law: Users spend 99% time on other sites
→ Follow platform conventions

Aesthetic-Usability Effect: Beautiful = perceived usable
→ Invest in visual polish

Von Restorff Effect: Unique items remembered better
→ Differentiate key actions

Zeigarnik Effect: Incomplete tasks remembered better
→ Use progress indicators

Law of Proximity: Related items should be close
→ Group form fields logically

Law of Similarity: Similar items perceived as related
→ Use consistent styling for related actions

Law of Uniform Connectedness: Connected items perceived as group
→ Use visual connectors for related content
```

---

## 2. PLATFORM DESIGN GUIDELINES

### 2.1 Web Design Standards

```yaml
web_standards:
  viewport:
    mobile: "320px - 767px"
    tablet: "768px - 1023px"
    desktop: "1024px - 1439px"
    wide: "1440px+"

  breakpoints:
    xs: "0px"
    sm: "640px"
    md: "768px"
    lg: "1024px"
    xl: "1280px"
    2xl: "1536px"

  container:
    max_width: "1280px (desktop), 100% (mobile)"
    padding: "16px (mobile), 24px (tablet), 32px (desktop)"

  grid:
    columns: 12
    gutter: "24px (desktop), 16px (tablet), 12px (mobile)"
    margin: "auto (centered)"

  touch_targets:
    minimum: "44x44px"
    recommended: "48x48px"
    spacing: "8px minimum"

  font_sizes:
    hero: "clamp(2.5rem, 5vw, 4rem)"
    h1: "clamp(2rem, 4vw, 3rem)"
    h2: "clamp(1.5rem, 3vw, 2.25rem)"
    h3: "clamp(1.25rem, 2vw, 1.75rem)"
    body: "clamp(1rem, 1.5vw, 1.125rem)"
    small: "0.875rem"
    caption: "0.75rem"

  line_heights:
    display: "1.1 - 1.2"
    headings: "1.2 - 1.3"
    body: "1.5 - 1.7"
    small: "1.4 - 1.5"
```

### 2.2 Mobile App Design Standards

```yaml
mobile_standards:
  ios:
    status_bar: "44px (notch), 20px (legacy)"
    navigation_bar: "44px"
    tab_bar: "49px"
    home_indicator: "34px"
    safe_area_top: "44px"
    safe_area_bottom: "34px"
    touch_target: "44x44pt"
    font_sizes:
      large_title: "34pt"
      title_1: "28pt"
      title_2: "22pt"
      title_3: "20pt"
      headline: "17pt"
      body: "17pt"
      callout: "16pt"
      subhead: "15pt"
      footnote: "13pt"
      caption_1: "12pt"
      caption_2: "11pt"

  android:
    status_bar: "24dp"
    app_bar: "56dp"
    navigation_bar: "48dp (bottom)"
    touch_target: "48x48dp"
    font_sizes:
      display_large: "57sp"
      display_medium: "45sp"
      display_small: "36sp"
      headline_large: "32sp"
      headline_medium: "28sp"
      headline_small: "24sp"
      title_large: "22sp"
      title_medium: "16sp"
      title_small: "14sp"
      body_large: "16sp"
      body_medium: "14sp"
      body_small: "12sp"
      label_large: "14sp"
      label_medium: "12sp"
      label_small: "11sp"
```

### 2.3 Email Design Standards

```yaml
email_standards:
  width: "600px (maximum)"
  padding: "20px"
  font_stack: "Arial, Helvetica, sans-serif"
  font_sizes:
    headline: "24-28px"
    subhead: "18-22px"
    body: "14-16px"
    caption: "12-14px"
  images:
    max_width: "600px"
    alt_text: "Required for all images"
    display: "block (prevents gaps)"
  buttons:
    min_height: "44px"
    border_radius: "4px"
    padding: "12px 24px"
  dark_mode:
    support: "Required"
    media_query: "@media (prefers-color-scheme: dark)"
```

---

## 3. INDUSTRY-SPECIFIC DESIGN GUIDELINES

### 3.1 E-commerce

```yaml
ecommerce_design:
  product_page:
    image_gallery: "Primary image above fold, thumbnails below"
    zoom: "Hover zoom on desktop, tap to zoom on mobile"
    price: "Large, prominent, near add-to-cart"
    cta: "Add to Cart primary, Buy Now secondary (if applicable)"
    reviews: "Star rating near price, full reviews below fold"
    specs: "Tabbed or accordion, below description"
    related: "Below product details, 4-6 items"

  listing_page:
    grid: "3-4 columns desktop, 2 tablet, 1-2 mobile"
    filter: "Sidebar (desktop), drawer (mobile)"
    sorting: "Top right, dropdown"
    pagination: "Infinite scroll or numbered"
    quick_view: "Modal on hover/click"

  checkout:
    steps: "3-4 max (Cart → Shipping → Payment → Confirmation)"
    progress: "Visual indicator at top"
    form: "Minimal fields, auto-fill, validation inline"
    trust: "Security badges, return policy, customer service"
    guest: "Allow guest checkout (reduce friction)"
```

### 3.2 SaaS / B2B

```yaml
saas_design:
  landing_page:
    hero: "Value proposition + primary CTA above fold"
    social_proof: "Logos, testimonials, stats below hero"
    features: "3-4 key features with icons"
    pricing: "Clear tiers, highlighted recommended"
    faq: "Accordion, addresses objections"
    cta_repeat: "Bottom CTA after value demonstration"

  dashboard:
    navigation: "Sidebar (desktop), bottom (mobile)"
    widgets: "Customizable grid, drag-and-drop"
    data_viz: "Charts with clear labels, tooltips"
    actions: "Primary actions prominent, secondary in menus"
    empty_states: "Helpful illustrations + next steps"
    onboarding: "Progressive, contextual tooltips"

  settings:
    organization: "Logical grouping, clear labels"
    danger_zone: "Separated, red, confirmation required"
    save: "Auto-save preferred, manual with clear feedback"
```

### 3.3 Healthcare

```yaml
healthcare_design:
  trust:
    colors: "Blues, greens, whites (calming, trustworthy)"
    imagery: "Diverse, real people, not stock"
    credentials: "Prominently display certifications"

  accessibility:
    wcag: "AAA compliance required"
    readability: "Large text, high contrast"
    forms: "Clear labels, error prevention"

  emergency:
    contact: "Phone number prominent, sticky"
    hours: "Clearly visible"
    location: "Map integration, directions"

  privacy:
    hipaa: "Clear privacy notices"
    forms: "Secure, encrypted indicators"
    consent: "Explicit opt-in for communications"
```

### 3.4 Finance / Fintech

```yaml
finance_design:
  trust:
    security: "SSL badges, encryption indicators"
    regulation: "Compliance badges (FCA, SEC, etc.)"
    transparency: "Clear fees, no hidden costs"

  data:
    charts: "Real-time, clear, customizable"
    numbers: "Large, formatted, color-coded (green/red)"
    history: "Filterable, exportable"

  actions:
    transfers: "Clear confirmation, recipient verification"
    investments: "Risk warnings, educational content"
    settings: "Security settings prominent"

  onboarding:
    kyc: "Step-by-step, progress indicator"
    verification: "Clear instructions, document upload"
    funding: "Multiple methods, clear fees"
```

### 3.5 Education / EdTech

```yaml
education_design:
  engagement:
    progress: "Visual progress bars, achievements"
    gamification: "Points, badges, leaderboards (optional)"
    interaction: "Quizzes, discussions, peer review"

  content:
    structure: "Modular, bite-sized lessons"
    media: "Video, audio, text, interactive"
    accessibility: "Captions, transcripts, alt text"

  assessment:
    feedback: "Immediate, constructive"
    retry: "Allow multiple attempts"
    analytics: "Progress tracking for students and teachers"

  community:
    forums: "Moderated, searchable"
    collaboration: "Group projects, shared workspaces"
    mentorship: "Matching, scheduling tools"
```

---

## 4. DESIGN TRENDS & EVOLUTIONS

### 4.1 Current Trends (2024-2026)

```yaml
trends_2024_2026:
  - name: "AI-Generated Aesthetics"
    description: "Designs that embrace or reference AI generation characteristics"
    characteristics: ["Surreal compositions", "Hyper-detailed textures", "Dreamlike lighting"]

  - name: "Neo-Brutalism"
    description: "Raw, unpolished, high-contrast designs"
    characteristics: ["Black borders", "System fonts", "High contrast colors", "Asymmetry"]

  - name: "Glassmorphism 2.0"
    description: "Refined glass-like interfaces with depth"
    characteristics: ["Subtle blur", "Layered depth", "Light refraction", "Minimal color"]

  - name: "3D & Depth"
    description: "Three-dimensional elements in 2D interfaces"
    characteristics: ["Isometric illustrations", "3D icons", "Parallax scrolling", "Depth shadows"]

  - name: "Motion & Micro-interactions"
    description: "Meaningful animation enhancing UX"
    characteristics: ["Scroll-triggered animations", "Hover states", "Loading sequences", "Page transitions"]

  - name: "Sustainable Design"
    description: "Eco-conscious design choices"
    characteristics: ["Dark mode default", "Minimal assets", "Efficient code", "Green hosting badges"]

  - name: "Inclusive Design"
    description: "Design for all abilities and backgrounds"
    characteristics: ["High contrast modes", "Screen reader optimization", "Cultural sensitivity", "Gender-neutral imagery"]

  - name: "Hyper-Personalization"
    description: "AI-driven personalized experiences"
    characteristics: ["Dynamic content", "Adaptive interfaces", "Predictive layouts", "Behavioral triggers"]
```

### 4.2 Historical Design Movements

```yaml
design_movements:
  - name: "Art Nouveau (1890-1910)"
    characteristics: ["Organic lines", "Floral motifs", "Decorative typography", "Asymmetry"]
    influence: "Ornate borders, decorative elements"

  - name: "Bauhaus (1919-1933)"
    characteristics: ["Form follows function", "Geometric shapes", "Primary colors", "Sans-serif typography"]
    influence: "Modern grid systems, functionalism"

  - name: "Swiss Style / International Typographic Style (1950s-70s)"
    characteristics: ["Grid systems", "Helvetica", "Objective photography", "Asymmetric layouts"]
    influence: "Grid-based web design, minimalism"

  - name: "Postmodernism (1970s-90s)"
    characteristics: ["Playful", "Ironic", "Eclectic", "Vibrant colors", "Mixed typography"]
    influence: "Bold branding, experimental layouts"

  - name: "Flat Design (2010s)"
    characteristics: ["No shadows", "No gradients", "Simple icons", "Bold colors"]
    influence: "iOS 7, Material Design, modern UI"

  - name: "Material Design (2014-present)"
    characteristics: ["Paper metaphor", "Elevation shadows", "Bold graphics", "Meaningful motion"]
    influence: "Android design, elevation system"
```

---

## 5. DESIGN PSYCHOLOGY

### 5.1 Color Psychology

```yaml
color_psychology:
  red:
    emotions: ["Excitement", "Urgency", "Passion", "Danger"]
    use_cases: ["CTAs", "Sales", "Food", "Warnings"]
    industries: ["Food", "Entertainment", "Retail", "Automotive"]

  blue:
    emotions: ["Trust", "Calm", "Professional", "Security"]
    use_cases: ["Corporate", "Finance", "Technology", "Healthcare"]
    industries: ["Banking", "Tech", "Insurance", "Medical"]

  green:
    emotions: ["Growth", "Health", "Nature", "Wealth"]
    use_cases: ["Eco-friendly", "Finance", "Wellness", "Organic"]
    industries: ["Agriculture", "Banking", "Health", "Environment"]

  yellow:
    emotions: ["Optimism", "Energy", "Warmth", "Caution"]
    use_cases: ["Children's products", "Food", "Warnings", "Happiness"]
    industries: ["Food", "Entertainment", "Education", "Transportation"]

  orange:
    emotions: ["Friendly", "Creative", "Enthusiastic", "Affordable"]
    use_cases: ["CTAs", "Youth brands", "Sports", "Food"]
    industries: ["E-commerce", "Sports", "Entertainment", "Food"]

  purple:
    emotions: ["Luxury", "Creativity", "Wisdom", "Spirituality"]
    use_cases: ["Beauty", "Premium products", "Creative services", "Wellness"]
    industries: ["Beauty", "Education", "Non-profit", "Luxury"]

  black:
    emotions: ["Sophistication", "Power", "Elegance", "Mystery"]
    use_cases: ["Luxury", "Fashion", "Technology", "Premium"]
    industries: ["Fashion", "Automotive", "Technology", "Luxury goods"]

  white:
    emotions: ["Purity", "Simplicity", "Cleanliness", "Space"]
    use_cases: ["Healthcare", "Minimalist brands", "Weddings", "Tech"]
    industries: ["Healthcare", "Technology", "Wedding", "Minimalist design"]
```

### 5.2 Typography Psychology

```yaml
typography_psychology:
  serif:
    perception: ["Traditional", "Trustworthy", "Established", "Readable (print)"]
    use_cases: ["Editorial", "Luxury", "Academic", "Legal"]
    examples: ["Times New Roman", "Georgia", "Playfair Display", "Merriweather"]

  sans_serif:
    perception: ["Modern", "Clean", "Friendly", "Readable (screen)"]
    use_cases: ["Tech", "Startups", "UI", "Contemporary brands"]
    examples: ["Helvetica", "Inter", "Roboto", "Open Sans"]

  script:
    perception: ["Elegant", "Personal", "Creative", "Feminine"]
    use_cases: ["Weddings", "Beauty", "Fashion", "Invitations"]
    examples: ["Great Vibes", "Pacifico", "Dancing Script"]

  display:
    perception: ["Bold", "Expressive", "Attention-grabbing", "Unique"]
    use_cases: ["Headlines", "Posters", "Branding", "Entertainment"]
    examples: ["Bebas Neue", "Impact", "Montserrat Black"]

  monospace:
    perception: ["Technical", "Precise", "Retro", "Code"]
    use_cases: ["Developer tools", "Tech brands", "Retro themes", "Data"]
    examples: ["Courier", "JetBrains Mono", "Fira Code"]

  geometric_sans:
    perception: ["Futuristic", "Minimal", "Architectural", "Cool"]
    use_cases: ["Tech", "Architecture", "Fashion", "Modern brands"]
    examples: ["Futura", "Montserrat", "Avenir", "Proxima Nova"]

  humanist_sans:
    perception: ["Friendly", "Approachable", "Warm", "Organic"]
    use_cases: ["Education", "Non-profit", "Consumer brands", "Health"]
    examples: ["Gill Sans", "Frutiger", "Myriad Pro", "Source Sans Pro"]
```

### 5.3 Shape Psychology

```yaml
shape_psychology:
  circle:
    meaning: ["Unity", "Community", "Wholeness", "Femininity"]
    use: ["Social buttons", "Profile pictures", "Badges", "Logos"]

  square:
    meaning: ["Stability", "Balance", "Reliability", "Professionalism"]
    use: ["Containers", "Buttons", "Icons", "Layouts"]

  triangle:
    meaning: ["Energy", "Direction", "Power", "Masculinity"]
    use: ["Arrows", "Play buttons", "Warnings", "Hierarchy"]

  rectangle:
    meaning: ["Structure", "Organization", "Formality", "Tradition"]
    use: ["Cards", "Modals", "Images", "Text blocks"]

  organic:
    meaning: ["Natural", "Friendly", "Approachable", "Creative"]
    use: ["Backgrounds", "Illustrations", "Decorative elements", "Blobs"]

  angular:
    meaning: ["Dynamic", "Aggressive", "Modern", "Edgy"]
    use: ["Gaming", "Sports", "Tech", "Action-oriented brands"]
```

---

## 6. DESIGN PATTERNS

### 6.1 UI Patterns

```yaml
ui_patterns:
  navigation:
    - name: "Horizontal Nav"
      use: "Top-level categories, 5-7 items"
      placement: "Header"

    - name: "Vertical Nav / Sidebar"
      use: "Many categories, nested items"
      placement: "Left side (desktop), Drawer (mobile)"

    - name: "Hamburger Menu"
      use: "Mobile, secondary navigation"
      placement: "Top-left or top-right"

    - name: "Breadcrumbs"
      use: "Deep hierarchies, wayfinding"
      placement: "Below header"

    - name: "Tabs"
      use: "Related content, same-level views"
      placement: "Below header or in content area"

    - name: "Pagination"
      use: "Large datasets, search results"
      placement: "Bottom of list"

    - name: "Infinite Scroll"
      use: "Social feeds, discovery"
      placement: "Auto-load on scroll"

    - name: "Mega Menu"
      use: "E-commerce, many subcategories"
      placement: "Hover on main nav item"

  input:
    - name: "Text Field"
      variants: ["Single-line", "Multi-line", "Password", "Search"]
      states: ["Default", "Focus", "Error", "Disabled", "Success"]

    - name: "Dropdown / Select"
      use: "Single choice from many options"
      max_items: "10-15 (use search above)"

    - name: "Checkbox"
      use: "Multiple selections, binary choices"
      group: "Related checkboxes grouped"

    - name: "Radio Button"
      use: "Mutually exclusive single choice"
      min_items: "2-5 (use dropdown for more)"

    - name: "Toggle Switch"
      use: "Binary on/off states"
      label: "Always label both states"

    - name: "Slider"
      use: "Range selection, numeric input"
      feedback: "Show current value"

    - name: "Date Picker"
      use: "Date selection"
      format: "Match locale conventions"

    - name: "File Upload"
      use: "File selection"
      feedback: "Progress, preview, size limit"

  feedback:
    - name: "Toast / Snackbar"
      duration: "3-5 seconds"
      placement: "Bottom (mobile), Top-right (desktop)"
      action: "Optional undo action"

    - name: "Modal / Dialog"
      use: "Critical decisions, forms"
      overlay: "Darken background"
      dismiss: "X button, overlay click, Escape key"

    - name: "Alert / Banner"
      use: "Important system messages"
      types: ["Info", "Success", "Warning", "Error"]
      persistence: "Until dismissed or action taken"

    - name: "Tooltip"
      use: "Icon explanations, truncated text"
      trigger: "Hover (desktop), Long-press (mobile)"
      delay: "300ms hover delay"

    - name: "Progress Indicator"
      types: ["Linear", "Circular", "Skeleton", "Stepper"]
      use: "Loading, multi-step processes"

    - name: "Badge"
      use: "Notifications, counts, status"
      placement: "Top-right of element"
      max: "99+ for large numbers"

    - name: "Empty State"
      use: "No data, first use"
      content: ["Illustration", "Explanation", "Next step CTA"]

    - name: "Loading State"
      use: "Data fetching"
      types: ["Spinner", "Skeleton", "Progress bar"]

  data_display:
    - name: "Table"
      use: "Structured data, comparisons"
      features: ["Sortable columns", "Pagination", "Search", "Filter"]

    - name: "Card"
      use: "Content blocks, products, articles"
      elements: ["Image", "Title", "Description", "Action"]

    - name: "List"
      use: "Simple data, settings"
      variants: ["Simple", "Detailed", "With icons", "With actions"]

    - name: "Chart"
      types: ["Bar", "Line", "Pie", "Area", "Scatter", "Heatmap"]
      use: "Data visualization, trends"

    - name: "Calendar"
      use: "Date-based data, scheduling"
      views: ["Month", "Week", "Day", "Agenda"]

    - name: "Timeline"
      use: "Chronological data, processes"
      orientation: ["Vertical", "Horizontal"]

    - name: "Accordion"
      use: "FAQ, settings, grouped content"
      behavior: "One open at a time or multiple"

    - name: "Carousel"
      use: "Image galleries, testimonials"
      indicators: "Dots or thumbnails"
      controls: "Arrows, swipe, auto-play"
```

### 6.2 Layout Patterns

```yaml
layout_patterns:
  - name: "Hero Section"
    structure: "Full-width, above fold, headline + subhead + CTA + visual"
    height: "100vh or 60-80vh"

  - name: "Feature Grid"
    structure: "3-4 columns of feature cards with icon + title + description"
    spacing: "24-32px between cards"

  - name: "Split Screen"
    structure: "50/50 or 60/40 split, text on one side, visual on other"
    use: "Storytelling, product showcases"

  - name: "Z-Pattern Layout"
    structure: "Top-left → Top-right → Diagonal → Bottom-left → Bottom-right"
    use: "Landing pages with clear CTA path"

  - name: "F-Pattern Layout"
    structure: "Horizontal scan top, then vertical down left side"
    use: "Content-heavy pages, articles"

  - name: "Card Grid"
    structure: "Responsive grid of equal-sized cards"
    columns: "4 (desktop), 2 (tablet), 1 (mobile)"

  - name: "Masonry"
    structure: "Pinterest-style, varying height items"
    use: "Image galleries, portfolios, discovery"

  - name: "Dashboard"
    structure: "Sidebar nav + widget grid + header"
    widgets: "Resizable, customizable, draggable"

  - name: "Magazine"
    structure: "Asymmetric grid, featured article + sidebar"
    use: "Editorial, content-heavy sites"

  - name: "Single Page"
    structure: "Vertical scroll sections with anchor nav"
    use: "Portfolios, product launches, events"
```

---

## 7. DESIGN TOKENS & SYSTEMS

### 7.1 Token Categories

```yaml
design_tokens:
  color:
    primitive:
      - "color.black: #000000"
      - "color.white: #FFFFFF"
      - "color.red.500: #EF4444"
      - "color.blue.500: #3B82F6"
      - "color.green.500: #10B981"
      - "color.yellow.500: #F59E0B"

    semantic:
      - "color.background.primary: {color.white}"
      - "color.background.secondary: {color.gray.50}"
      - "color.background.inverse: {color.gray.900}"
      - "color.text.primary: {color.gray.900}"
      - "color.text.secondary: {color.gray.500}"
      - "color.text.inverse: {color.white}"
      - "color.border.default: {color.gray.200}"
      - "color.border.focus: {color.blue.500}"
      - "color.action.primary: {color.blue.600}"
      - "color.action.primary.hover: {color.blue.700}"
      - "color.action.primary.active: {color.blue.800}"
      - "color.feedback.success: {color.green.500}"
      - "color.feedback.warning: {color.yellow.500}"
      - "color.feedback.error: {color.red.500}"
      - "color.feedback.info: {color.blue.500}"

    component:
      - "button.primary.background: {color.action.primary}"
      - "button.primary.text: {color.text.inverse}"
      - "button.primary.border: transparent"
      - "button.primary.hover.background: {color.action.primary.hover}"
      - "input.border: {color.border.default}"
      - "input.focus.border: {color.border.focus}"
      - "card.background: {color.background.primary}"
      - "card.border: {color.border.default}"
      - "card.shadow: 0 1px 3px rgba(0,0,0,0.1)"

  spacing:
    primitive:
      - "space.0: 0px"
      - "space.1: 4px"
      - "space.2: 8px"
      - "space.3: 12px"
      - "space.4: 16px"
      - "space.5: 24px"
      - "space.6: 32px"
      - "space.7: 48px"
      - "space.8: 64px"
      - "space.9: 96px"
      - "space.10: 128px"
      - "space.11: 192px"
      - "space.12: 256px"
      - "space.13: 384px"
      - "space.14: 512px"
      - "space.15: 640px"
      - "space.16: 768px"

    semantic:
      - "space.section.padding: {space.8}"
      - "space.container.padding: {space.6}"
      - "space.card.padding: {space.5}"
      - "space.input.padding: {space.3}"
      - "space.button.padding: {space.3} {space.5}"
      - "space.gap.small: {space.2}"
      - "space.gap.medium: {space.4}"
      - "space.gap.large: {space.6}"

  typography:
    primitive:
      - "font.family.sans: 'Inter', system-ui, sans-serif"
      - "font.family.serif: 'Merriweather', Georgia, serif"
      - "font.family.mono: 'JetBrains Mono', monospace"
      - "font.size.1: 12px"
      - "font.size.2: 14px"
      - "font.size.3: 16px"
      - "font.size.4: 18px"
      - "font.size.5: 20px"
      - "font.size.6: 24px"
      - "font.size.7: 30px"
      - "font.size.8: 36px"
      - "font.size.9: 48px"
      - "font.size.10: 60px"
      - "font.size.11: 72px"
      - "font.weight.light: 300"
      - "font.weight.regular: 400"
      - "font.weight.medium: 500"
      - "font.weight.semibold: 600"
      - "font.weight.bold: 700"
      - "font.lineHeight.tight: 1.25"
      - "font.lineHeight.snug: 1.375"
      - "font.lineHeight.normal: 1.5"
      - "font.lineHeight.relaxed: 1.625"
      - "font.lineHeight.loose: 2"
      - "font.letterSpacing.tighter: -0.05em"
      - "font.letterSpacing.tight: -0.025em"
      - "font.letterSpacing.normal: 0"
      - "font.letterSpacing.wide: 0.025em"
      - "font.letterSpacing.wider: 0.05em"
      - "font.letterSpacing.widest: 0.1em"

    semantic:
      - "font.heading.1: {font.size.9} / {font.weight.bold} / {font.lineHeight.tight} / {font.letterSpacing.tight}"
      - "font.heading.2: {font.size.8} / {font.weight.bold} / {font.lineHeight.tight} / {font.letterSpacing.tight}"
      - "font.heading.3: {font.size.7} / {font.weight.semibold} / {font.lineHeight.snug} / {font.letterSpacing.tight}"
      - "font.heading.4: {font.size.6} / {font.weight.semibold} / {font.lineHeight.snug} / {font.letterSpacing.normal}"
      - "font.body.large: {font.size.4} / {font.weight.regular} / {font.lineHeight.relaxed} / {font.letterSpacing.normal}"
      - "font.body: {font.size.3} / {font.weight.regular} / {font.lineHeight.normal} / {font.letterSpacing.normal}"
      - "font.body.small: {font.size.2} / {font.weight.regular} / {font.lineHeight.normal} / {font.letterSpacing.normal}"
      - "font.label: {font.size.2} / {font.weight.medium} / {font.lineHeight.normal} / {font.letterSpacing.wide}"
      - "font.caption: {font.size.1} / {font.weight.regular} / {font.lineHeight.normal} / {font.letterSpacing.normal}"

  border_radius:
    primitive:
      - "radius.none: 0px"
      - "radius.small: 4px"
      - "radius.medium: 8px"
      - "radius.large: 12px"
      - "radius.xl: 16px"
      - "radius.2xl: 24px"
      - "radius.3xl: 32px"
      - "radius.full: 9999px"

    semantic:
      - "radius.button: {radius.medium}"
      - "radius.card: {radius.large}"
      - "radius.input: {radius.small}"
      - "radius.badge: {radius.full}"
      - "radius.avatar: {radius.full}"

  shadow:
    primitive:
      - "shadow.1: 0 1px 2px rgba(0,0,0,0.05)"
      - "shadow.2: 0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06)"
      - "shadow.3: 0 4px 6px rgba(0,0,0,0.1), 0 2px 4px rgba(0,0,0,0.06)"
      - "shadow.4: 0 10px 15px rgba(0,0,0,0.1), 0 4px 6px rgba(0,0,0,0.05)"
      - "shadow.5: 0 20px 25px rgba(0,0,0,0.1), 0 10px 10px rgba(0,0,0,0.04)"
      - "shadow.6: 0 25px 50px rgba(0,0,0,0.25)"

    semantic:
      - "shadow.card: {shadow.2}"
      - "shadow.card.hover: {shadow.3}"
      - "shadow.modal: {shadow.5}"
      - "shadow.dropdown: {shadow.4}"
      - "shadow.fab: {shadow.3}"

  z_index:
    primitive:
      - "z.base: 0"
      - "z.dropdown: 1000"
      - "z.sticky: 1020"
      - "z.fixed: 1030"
      - "z.modalBackdrop: 1040"
      - "z.modal: 1050"
      - "z.popover: 1060"
      - "z.tooltip: 1070"
      - "z.toast: 1080"
      - "z.fullscreen: 9999"

  animation:
    primitive:
      - "duration.instant: 0ms"
      - "duration.fast: 100ms"
      - "duration.normal: 200ms"
      - "duration.slow: 300ms"
      - "duration.slower: 500ms"
      - "easing.linear: linear"
      - "easing.ease: ease"
      - "easing.easeIn: cubic-bezier(0.4, 0, 1, 1)"
      - "easing.easeOut: cubic-bezier(0, 0, 0.2, 1)"
      - "easing.easeInOut: cubic-bezier(0.4, 0, 0.2, 1)"
      - "easing.spring: cubic-bezier(0.34, 1.56, 0.64, 1)"

    semantic:
      - "animation.button.hover: {duration.fast} {easing.easeOut}"
      - "animation.modal.enter: {duration.slow} {easing.easeOut}"
      - "animation.modal.exit: {duration.fast} {easing.easeIn}"
      - "animation.page.transition: {duration.slow} {easing.easeInOut}"
      - "animation.loading.pulse: {duration.slow} {easing.easeInOut} infinite"
```

---

## 8. DESIGN ANTI-PATTERNS

```yaml
design_anti_patterns:
  - name: "Mystery Meat Navigation"
    description: "Navigation where destination is unclear until hover/click"
    solution: "Always show labels, use icons + text"

  - name: "Hamburger Menu on Desktop"
    description: "Hiding primary navigation behind hamburger on desktop"
    solution: "Show primary nav, use hamburger only for overflow"

  - name: "Infinite Scroll Without Alternative"
    description: "Forcing infinite scroll with no pagination option"
    solution: "Offer both infinite scroll and pagination"

  - name: "Autoplaying Video/Audio"
    description: "Media that plays without user consent"
    solution: "Muted autoplay only, require click for sound"

  - name: "Modal Over Modal"
    description: "Stacking multiple modal dialogs"
    solution: "Use inline expansion, side panels, or wizard"

  - name: "Form Fields as Placeholders"
    description: "Using placeholder text as labels"
    solution: "Always use separate labels above fields"

  - name: "Disabled Buttons Without Explanation"
    description: "Disabled submit with no indication why"
    solution: "Show inline validation, explain requirements"

  - name: "Too Many Font Weights/Sizes"
    description: "Using 8+ font sizes or 5+ font families"
    solution: "Limit to 3-4 sizes, 1-2 families"

  - name: "Low Contrast Text"
    description: "Text that fails WCAG contrast requirements"
    solution: "Minimum 4.5:1 for normal text, 3:1 for large"

  - name: "Breaking the Back Button"
    description: "Single-page apps that break browser back"
    solution: "Use history API, maintain URL state"

  - name: "No Empty States"
    description: "Blank screens when no data exists"
    solution: "Design helpful empty states with next steps"

  - name: "Overusing Modals"
    description: "Using modals for non-critical information"
    solution: "Use inline alerts, toasts, or expandable sections"

  - name: "Inconsistent Button Styles"
    description: "Multiple button styles for same action type"
    solution: "Define button hierarchy: primary, secondary, tertiary, danger"

  - name: "Tiny Click Targets"
    description: "Links or buttons smaller than 44px"
    solution: "Minimum 44x44px touch targets"

  - name: "Ignoring Reduced Motion"
    description: "Animations that ignore accessibility preferences"
    solution: "Respect prefers-reduced-motion media query"
```

---

## 9. DESIGN TOOL COMPARISONS

### 9.1 Feature Matrix

| Feature | Photoshop | Illustrator | Figma | Canva | Affinity Photo | Affinity Designer | Photopea | CorelDRAW | AURA |
|---------|-----------|-------------|-------|-------|---------------|-------------------|----------|-----------|------|
| Raster Editing | ★★★ | ★ | ★ | ★ | ★★★ | ★ | ★★★ | ★ | ★★★ |
| Vector Editing | ★ | ★★★ | ★★ | ★ | ★ | ★★★ | ★ | ★★★ | ★★★ |
| UI/UX Design | ★ | ★ | ★★★ | ★★ | ★ | ★ | ★ | ★ | ★★★ |
| Collaboration | ★★ | ★★ | ★★★ | ★★★ | ★ | ★ | ★★ | ★ | ★★★ |
| AI Features | ★★★ | ★★ | ★★ | ★★★ | ★★ | ★★ | ★★ | ★ | ★★★ |
| Print Design | ★★★ | ★★★ | ★★ | ★★ | ★★★ | ★★★ | ★★ | ★★★ | ★★★ |
| Web Export | ★★ | ★★ | ★★★ | ★★★ | ★★ | ★★ | ★★★ | ★★ | ★★★ |
| Animation | ★★ | ★ | ★★ | ★★★ | ★ | ★ | ★ | ★ | ★★★ |
| Code Generation | ★ | ★ | ★★★ | ★★ | ★ | ★ | ★ | ★ | ★★★ |
| API/Automation | ★★ | ★★ | ★★ | ★★ | ★ | ★ | ★★ | ★★ | ★★★ |
| Open Source | ★ | ★ | ★ | ★ | ★ | ★ | ★★ | ★ | ★★★ |
| Self-Hosted | ★ | ★ | ★ | ★ | ★ | ★ | ★★ | ★ | ★★★ |
| Real-time Sync | ★ | ★ | ★★★ | ★★★ | ★ | ★ | ★★ | ★ | ★★★ |
| Version Control | ★★ | ★★ | ★★★ | ★★ | ★ | ★ | ★ | ★ | ★★★ |
| Design Tokens | ★ | ★ | ★★★ | ★★ | ★ | ★ | ★ | ★ | ★★★ |
| Programmatic | ★★ | ★★ | ★★ | ★★ | ★ | ★ | ★★ | ★★ | ★★★ |

### 9.2 File Format Support

| Format | Photoshop | Illustrator | Figma | Canva | AURA |
|--------|-----------|-------------|-------|-------|------|
| PSD | R/W | R | R | - | R/W |
| AI | R | R/W | R | - | R/W |
| SVG | R | R/W | R/W | R/W | R/W |
| PDF | R/W | R/W | R/W | R/W | R/W |
| EPS | R | R/W | R | - | R/W |
| PNG | R/W | R/W | R/W | R/W | R/W |
| JPEG | R/W | R/W | R/W | R/W | R/W |
| TIFF | R/W | R | R | - | R/W |
| WEBP | R/W | - | R/W | R/W | R/W |
| AVIF | R/W | - | R/W | R/W | R/W |
| HEIC | R/W | - | R | - | R/W |
| RAW | R/W | - | - | - | R/W |
| FIG | - | - | R/W | - | R/W |
| CDR | - | - | - | - | R/W |
| CDR | - | - | - | - | R/W |
| JSON (Design) | - | - | R/W | - | R/W |
| HTML/CSS | - | - | W | W | W |
| React/Vue | - | - | W | - | W |
| MP4 | R/W | - | - | R/W | R/W |
| GIF | R/W | - | R/W | R/W | R/W |
| PPTX | - | - | - | R/W | R/W |

---

## 10. PERFORMANCE BUDGETS

```yaml
performance_budgets:
  web:
    first_contentful_paint: "1.8s"
    largest_contentful_paint: "2.5s"
    time_to_interactive: "3.8s"
    cumulative_layout_shift: "0.1"
    total_blocking_time: "200ms"

    page_weight:
      html: "50KB"
      css: "100KB"
      js: "300KB"
      images: "1MB"
      fonts: "100KB"
      total: "1.5MB"

    image_optimization:
      format: "WebP (with JPEG fallback)"
      responsive: "srcset with multiple sizes"
      lazy_loading: "Below-fold images"

  mobile_app:
    launch_time: "2s"
    apk_size: "15MB"
    memory_usage: "100MB"
    battery_impact: "Minimal background activity"

  design_editor:
    canvas_fps: "60fps"
    filter_latency: "<16ms"
    export_time_1080p: "<2s"
    export_time_4k: "<5s"
    ai_generation_1024: "<10s"
    document_load_50mb: "<3s"
```

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: Knowledge Base Reference*
