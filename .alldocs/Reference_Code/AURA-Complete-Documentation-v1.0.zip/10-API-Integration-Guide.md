# AURA API Integration Guide
## Complete REST, WebSocket, and SDK Reference v1.0

---

## 1. API ARCHITECTURE

### 1.1 Base URLs

```yaml
environments:
  production:
    rest: "https://api.aura.design/v1"
    websocket: "wss://realtime.aura.design/v1"
    cdn: "https://cdn.aura.design"
    graphql: "https://graphql.aura.design/v1"

  staging:
    rest: "https://api-staging.aura.design/v1"
    websocket: "wss://realtime-staging.aura.design/v1"
    cdn: "https://cdn-staging.aura.design"

  development:
    rest: "https://api-dev.aura.design/v1"
    websocket: "wss://realtime-dev.aura.design/v1"
    cdn: "https://cdn-dev.aura.design"
```

### 1.2 Authentication

```yaml
authentication:
  api_key:
    header: "X-API-Key"
    format: "Bearer {api_key}"
    scopes: ["read", "write", "admin"]
    rate_limits:
      free: "100 requests/minute"
      pro: "1000 requests/minute"
      enterprise: "10000 requests/minute"

  oauth2:
    authorization_url: "https://aura.design/oauth/authorize"
    token_url: "https://aura.design/oauth/token"
    scopes:
      - "design:read" - Read designs and assets
      - "design:write" - Create and modify designs
      - "design:delete" - Delete designs and assets
      - "template:read" - Read templates
      - "template:write" - Create and modify templates
      - "brand:read" - Read brand kits
      - "brand:write" - Modify brand kits
      - "user:read" - Read user profile
      - "team:read" - Read team information
      - "team:write" - Manage team members
      - "analytics:read" - Access analytics data
      - "webhook:write" - Manage webhooks

  jwt:
    header: "Authorization: Bearer {jwt_token}"
    expiry: "24 hours"
    refresh: "Refresh token valid for 30 days"

  webhook_signature:
    header: "X-Aura-Signature"
    algorithm: "HMAC-SHA256"
    verification: "Compare signature with HMAC-SHA256(payload, webhook_secret)"
```

---

## 2. REST API ENDPOINTS

### 2.1 Documents

```yaml
documents_endpoints:
  create_document:
    method: POST
    path: /documents
    description: "Create a new design document"
    request_body:
      name: { type: string, required: true, example: "Summer Campaign Poster" }
      width: { type: number, required: true, example: 1080 }
      height: { type: number, required: true, example: 1080 }
      unit: { type: string, enum: [px, mm, in, pt], default: px }
      color_space: { type: string, enum: [sRGB, DisplayP3, CMYK, ProPhoto], default: sRGB }
      dpi: { type: number, default: 72 }
      template_id: { type: string, required: false }
      brand_kit_id: { type: string, required: false }
      metadata: { type: object, required: false }

    response:
      201:
        id: string
        name: string
        width: number
        height: number
        unit: string
        color_space: string
        dpi: number
        created_at: ISO8601
        updated_at: ISO8601
        url: string
        layers: []

      400: { error: string, details: object }
      401: { error: "Unauthorized" }
      429: { error: "Rate limit exceeded", retry_after: number }

  get_document:
    method: GET
    path: /documents/{id}
    description: "Retrieve a design document"
    parameters:
      id: { type: string, required: true, in: path }
      include_layers: { type: boolean, default: false, in: query }
      include_history: { type: boolean, default: false, in: query }

    response:
      200:
        id: string
        name: string
        width: number
        height: number
        color_space: string
        dpi: number
        layers: [Layer]
        history: [HistoryState]
        created_at: ISO8601
        updated_at: ISO8601

  update_document:
    method: PATCH
    path: /documents/{id}
    description: "Update document properties"
    request_body:
      name: { type: string }
      width: { type: number }
      height: { type: number }
      color_space: { type: string }
      metadata: { type: object }

  delete_document:
    method: DELETE
    path: /documents/{id}
    description: "Delete a design document"

  list_documents:
    method: GET
    path: /documents
    description: "List all documents for the authenticated user/team"
    parameters:
      page: { type: number, default: 1, in: query }
      per_page: { type: number, default: 20, max: 100, in: query }
      sort: { type: string, enum: [created_at, updated_at, name], default: updated_at, in: query }
      order: { type: string, enum: [asc, desc], default: desc, in: query }
      folder_id: { type: string, in: query }
      tag: { type: string, in: query }
      search: { type: string, in: query }

    response:
      200:
        data: [Document]
        pagination:
          page: number
          per_page: number
          total: number
          total_pages: number
          has_next: boolean
          has_prev: boolean
```

### 2.2 Layers

```yaml
layers_endpoints:
  create_layer:
    method: POST
    path: /documents/{document_id}/layers
    description: "Add a new layer to a document"
    request_body:
      type: { type: string, enum: [raster, vector, text, group, adjustment, smart_object], required: true }
      name: { type: string, required: true }
      parent_id: { type: string, required: false }
      index: { type: number, required: false }
      properties: { type: object, required: false }

  get_layer:
    method: GET
    path: /documents/{document_id}/layers/{layer_id}
    description: "Get layer details"

  update_layer:
    method: PATCH
    path: /documents/{document_id}/layers/{layer_id}
    description: "Update layer properties"
    request_body:
      name: { type: string }
      visible: { type: boolean }
      locked: { type: boolean }
      opacity: { type: number, min: 0, max: 1 }
      blend_mode: { type: string }
      transform: { type: object }
      properties: { type: object }

  delete_layer:
    method: DELETE
    path: /documents/{document_id}/layers/{layer_id}
    description: "Delete a layer"

  reorder_layers:
    method: PUT
    path: /documents/{document_id}/layers/reorder
    description: "Reorder layers"
    request_body:
      layer_ids: { type: [string], required: true }

  duplicate_layer:
    method: POST
    path: /documents/{document_id}/layers/{layer_id}/duplicate
    description: "Duplicate a layer"

  merge_layers:
    method: POST
    path: /documents/{document_id}/layers/merge
    description: "Merge multiple layers"
    request_body:
      layer_ids: { type: [string], required: true }
      target_name: { type: string, required: false }
```

### 2.3 Export & Render

```yaml
export_endpoints:
  render_document:
    method: POST
    path: /documents/{id}/render
    description: "Render document to image or file"
    request_body:
      format: { type: string, enum: [png, jpeg, webp, avif, svg, pdf, psd, ai, fig, mp4, gif], required: true }
      quality: { type: number, min: 0, max: 100, default: 90 }
      scale: { type: number, default: 1 }
      color_space: { type: string, enum: [sRGB, DisplayP3, CMYK], default: sRGB }
      include_bleed: { type: boolean, default: false }
      bleed_size: { type: number, default: 3 }
      crop_marks: { type: boolean, default: false }
      layers: { type: [string], required: false }
      artboard: { type: string, required: false }

    response:
      202:
        job_id: string
        status: "queued"
        estimated_time: number

      200:
        url: string
        format: string
        width: number
        height: number
        file_size: number
        expires_at: ISO8601

  get_render_status:
    method: GET
    path: /renders/{job_id}
    description: "Check render job status"
    response:
      200:
        job_id: string
        status: { enum: [queued, processing, completed, failed] }
        progress: { type: number, min: 0, max: 100 }
        result_url: { type: string, nullable: true }
        error: { type: string, nullable: true }
        created_at: ISO8601
        completed_at: { type: ISO8601, nullable: true }

  batch_render:
    method: POST
    path: /documents/batch-render
    description: "Render multiple documents"
    request_body:
      documents: { type: [{ id: string, format: string, scale: number }], required: true }

  export_template:
    method: POST
    path: /documents/{id}/export-template
    description: "Export document as reusable template"
    request_body:
      name: { type: string, required: true }
      description: { type: string }
      category: { type: string }
      tags: { type: [string] }
      variables: { type: object }
      rules: { type: [object] }
      is_public: { type: boolean, default: false }
```

### 2.4 AI Generation

```yaml
ai_endpoints:
  generate_design:
    method: POST
    path: /ai/generate
    description: "Generate design from text prompt"
    request_body:
      prompt: { type: string, required: true, max_length: 2000 }
      design_type: { type: string, enum: [social_post, poster, logo, flyer, banner, presentation, ui, illustration], required: true }
      platform: { type: string, required: false }
      dimensions: { type: { width: number, height: number, unit: string }, required: false }
      brand_kit_id: { type: string, required: false }
      style: { type: string, required: false }
      mood: { type: string, required: false }
      color_palette: { type: [string], required: false }
      fonts: { type: [string], required: false }
      content: { type: object, required: false }
      variants: { type: number, min: 1, max: 10, default: 3 }

    response:
      202:
        job_id: string
        status: "queued"
        estimated_time: number

      200:
        designs: [Design]

  edit_with_ai:
    method: POST
    path: /documents/{id}/ai-edit
    description: "Edit existing design with AI"
    request_body:
      instruction: { type: string, required: true, max_length: 1000 }
      target_layers: { type: [string], required: false }
      preserve_elements: { type: [string], required: false }

  generate_variants:
    method: POST
    path: /documents/{id}/ai-variants
    description: "Generate design variations"
    request_body:
      variation_type: { type: string, enum: [color, layout, style, content, size], required: true }
      count: { type: number, min: 1, max: 10, default: 3 }
      constraints: { type: object, required: false }

  analyze_design:
    method: POST
    path: /documents/{id}/ai-analyze
    description: "AI-powered design analysis and feedback"
    request_body:
      criteria: { type: [string], default: ["all"] }

    response:
      200:
        overall_score: number
        category_scores: object
        strengths: [string]
        weaknesses: [string]
        recommendations: [{ priority: string, issue: string, suggestion: string }]

  generate_assets:
    method: POST
    path: /ai/generate-assets
    description: "Generate images, icons, illustrations"
    request_body:
      asset_type: { type: string, enum: [image, icon, illustration, pattern, texture, background], required: true }
      prompt: { type: string, required: true }
      style: { type: string, required: false }
      dimensions: { type: { width: number, height: number }, required: false }
      count: { type: number, default: 1, max: 10 }

  remove_background:
    method: POST
    path: /ai/remove-background
    description: "AI background removal"
    request_body:
      image_url: { type: string, required: true }
      refine_edges: { type: boolean, default: true }

  upscale_image:
    method: POST
    path: /ai/upscale
    description: "AI image upscaling"
    request_body:
      image_url: { type: string, required: true }
      scale: { type: number, enum: [2, 4, 8], default: 2 }
      model: { type: string, enum: [standard, photo, anime, art], default: standard }

  generative_fill:
    method: POST
    path: /ai/generative-fill
    description: "AI generative fill/inpainting"
    request_body:
      image_url: { type: string, required: true }
      mask_url: { type: string, required: true }
      prompt: { type: string, required: true }

  style_transfer:
    method: POST
    path: /ai/style-transfer
    description: "Apply artistic style to image"
    request_body:
      image_url: { type: string, required: true }
      style_reference_url: { type: string, required: false }
      style_prompt: { type: string, required: false }
      strength: { type: number, min: 0, max: 1, default: 0.7 }
```

### 2.5 Templates

```yaml
template_endpoints:
  list_templates:
    method: GET
    path: /templates
    description: "List available templates"
    parameters:
      category: { type: string, in: query }
      subcategory: { type: string, in: query }
      platform: { type: string, in: query }
      format: { type: string, in: query }
      search: { type: string, in: query }
      tags: { type: [string], in: query }
      sort: { type: string, enum: [popular, newest, trending], default: popular, in: query }

  get_template:
    method: GET
    path: /templates/{id}
    description: "Get template details"

  create_template:
    method: POST
    path: /templates
    description: "Create custom template"
    request_body:
      name: { type: string, required: true }
      description: { type: string }
      category: { type: string, required: true }
      subcategory: { type: string }
      format: { type: string, required: true }
      dimensions: { type: object, required: true }
      structure: { type: object, required: true }
      variables: { type: object, required: true }
      rules: { type: [object], required: false }
      is_public: { type: boolean, default: false }

  apply_template:
    method: POST
    path: /templates/{id}/apply
    description: "Apply template with data to create document"
    request_body:
      variables: { type: object, required: true }
      brand_kit_id: { type: string, required: false }
      name: { type: string, required: false }

  update_template:
    method: PATCH
    path: /templates/{id}
    description: "Update template"

  delete_template:
    method: DELETE
    path: /templates/{id}
    description: "Delete template"
```

### 2.6 Brand Kits

```yaml
brand_kit_endpoints:
  create_brand_kit:
    method: POST
    path: /brand-kits
    description: "Create brand kit"
    request_body:
      name: { type: string, required: true }
      description: { type: string }
      logo: { type: object }
      colors: { type: object }
      fonts: { type: object }
      imagery: { type: object }
      voice: { type: object }
      guidelines: { type: object }

  get_brand_kit:
    method: GET
    path: /brand-kits/{id}
    description: "Get brand kit"

  update_brand_kit:
    method: PATCH
    path: /brand-kits/{id}
    description: "Update brand kit"

  list_brand_kits:
    method: GET
    path: /brand-kits
    description: "List brand kits"

  delete_brand_kit:
    method: DELETE
    path: /brand-kits/{id}
    description: "Delete brand kit"

  apply_brand_kit:
    method: POST
    path: /brand-kits/{id}/apply
    description: "Apply brand kit to document"
    request_body:
      document_id: { type: string, required: true }
      options: { type: object, required: false }
```

### 2.7 Assets

```yaml
asset_endpoints:
  upload_asset:
    method: POST
    path: /assets
    description: "Upload asset (image, font, video, etc.)"
    request_body:
      file: { type: file, required: true }
      name: { type: string, required: false }
      tags: { type: [string], required: false }
      folder_id: { type: string, required: false }
      metadata: { type: object, required: false }

    response:
      201:
        id: string
        name: string
        url: string
        thumbnail_url: string
        type: string
        size: number
        dimensions: { width: number, height: number }
        format: string
        created_at: ISO8601

  get_asset:
    method: GET
    path: /assets/{id}
    description: "Get asset details"

  list_assets:
    method: GET
    path: /assets
    description: "List assets"
    parameters:
      type: { type: string, enum: [image, video, font, audio, vector, other], in: query }
      folder_id: { type: string, in: query }
      search: { type: string, in: query }
      tags: { type: [string], in: query }
      sort: { type: string, default: created_at, in: query }

  delete_asset:
    method: DELETE
    path: /assets/{id}
    description: "Delete asset"

  search_assets:
    method: GET
    path: /assets/search
    description: "AI-powered asset search"
    parameters:
      query: { type: string, required: true, in: query }
      type: { type: string, in: query }
      limit: { type: number, default: 20, in: query }

  generate_asset:
    method: POST
    path: /assets/generate
    description: "Generate asset with AI"
    request_body:
      prompt: { type: string, required: true }
      type: { type: string, enum: [image, illustration, icon, pattern, texture], required: true }
      style: { type: string, required: false }
      dimensions: { type: { width: number, height: number }, required: false }

  optimize_asset:
    method: POST
    path: /assets/{id}/optimize
    description: "Optimize asset for web/print"
    request_body:
      target: { type: string, enum: [web, print, social], required: true }
      format: { type: string, enum: [jpeg, png, webp, avif], required: false }
      quality: { type: number, default: 85 }
      max_width: { type: number, required: false }
      max_height: { type: number, required: false }
```

### 2.8 Collaboration

```yaml
collaboration_endpoints:
  share_document:
    method: POST
    path: /documents/{id}/share
    description: "Share document with users/teams"
    request_body:
      users: { type: [{ email: string, role: string }], required: false }
      teams: { type: [{ team_id: string, role: string }], required: false }
      public_access: { type: boolean, default: false }
      link_expiry: { type: number, default: 7 }
      permissions: { type: object }

  get_collaborators:
    method: GET
    path: /documents/{id}/collaborators
    description: "List document collaborators"

  update_permissions:
    method: PATCH
    path: /documents/{id}/collaborators/{user_id}
    description: "Update user permissions"
    request_body:
      role: { type: string, enum: [owner, editor, commenter, viewer] }

  remove_collaborator:
    method: DELETE
    path: /documents/{id}/collaborators/{user_id}
    description: "Remove collaborator"

  get_comments:
    method: GET
    path: /documents/{id}/comments
    description: "Get comments on document"

  add_comment:
    method: POST
    path: /documents/{id}/comments
    description: "Add comment to document"
    request_body:
      text: { type: string, required: true }
      position: { type: { x: number, y: number }, required: false }
      layer_id: { type: string, required: false }
      parent_id: { type: string, required: false }

  resolve_comment:
    method: PATCH
    path: /documents/{id}/comments/{comment_id}
    description: "Resolve comment"
    request_body:
      resolved: { type: boolean, required: true }

  get_activity:
    method: GET
    path: /documents/{id}/activity
    description: "Get document activity log"
    parameters:
      page: { type: number, default: 1, in: query }
      per_page: { type: number, default: 20, in: query }
```

---

## 3. WEBSOCKET API

### 3.1 Connection

```yaml
websocket_connection:
  endpoint: "wss://realtime.aura.design/v1/documents/{document_id}"
  authentication: "JWT token in query parameter: ?token={jwt_token}"
  heartbeat: "Ping every 30 seconds, expect pong within 10 seconds"
  reconnection: "Exponential backoff: 1s, 2s, 4s, 8s, 16s, max 60s"

  connection_flow:
    1. "Client connects to WebSocket endpoint with JWT token"
    2. "Server sends connection_ack with session_id and document state"
    3. "Client can now send and receive operations"
    4. "Server broadcasts operations to all connected clients"
    5. "Client sends heartbeat ping every 30s"
    6. "Server responds with pong"
    7. "On disconnect, client reconnects with last known sequence number"
```

### 3.2 Message Types

```yaml
websocket_messages:
  client_to_server:
    join:
      type: "join"
      document_id: string
      client_id: string

    operation:
      type: "operation"
      operation: CRDTOperation
      sequence: number

    cursor:
      type: "cursor"
      position: { x: number, y: number }
      selection: [string]

    selection:
      type: "selection"
      layer_ids: [string]

    ping:
      type: "ping"
      timestamp: number

    presence:
      type: "presence"
      status: { enum: [active, idle, away] }

  server_to_client:
    connection_ack:
      type: "connection_ack"
      session_id: string
      document_state: DocumentState
      collaborators: [Collaborator]
      sequence: number

    operation:
      type: "operation"
      operation: CRDTOperation
      user_id: string
      user_name: string
      sequence: number
      timestamp: ISO8601

    cursor:
      type: "cursor"
      user_id: string
      user_name: string
      user_color: string
      position: { x: number, y: number }
      selection: [string]

    presence:
      type: "presence"
      user_id: string
      user_name: string
      user_color: string
      status: { enum: [active, idle, away] }
      cursor_position: { x: number, y: number }

    pong:
      type: "pong"
      timestamp: number

    error:
      type: "error"
      code: string
      message: string
      operation_sequence: number

    conflict:
      type: "conflict"
      operation: CRDTOperation
      resolution: ResolvedOperation

    document_update:
      type: "document_update"
      property: string
      value: any
      user_id: string
```

### 3.3 CRDT Operations

```yaml
crdt_operations:
  insert_layer:
    type: "insert_layer"
    layer_id: string
    parent_id: string
    index: number
    layer_data: Layer
    timestamp: number

  delete_layer:
    type: "delete_layer"
    layer_id: string
    timestamp: number

  update_layer:
    type: "update_layer"
    layer_id: string
    property: string
    value: any
    old_value: any
    timestamp: number

  reorder_layers:
    type: "reorder_layers"
    layer_ids: [string]
    timestamp: number

  update_document:
    type: "update_document"
    property: string
    value: any
    old_value: any
    timestamp: number

  add_comment:
    type: "add_comment"
    comment_id: string
    text: string
    position: { x: number, y: number }
    layer_id: string
    timestamp: number

  resolve_comment:
    type: "resolve_comment"
    comment_id: string
    timestamp: number

  transform:
    type: "transform"
    layer_id: string
    transform_matrix: [number]
    timestamp: number
```

---

## 4. SDK REFERENCE

### 4.1 JavaScript/TypeScript SDK

```typescript
// Installation: npm install @aura/sdk

import { AuraClient } from '@aura/sdk';

// Initialize client
const client = new AuraClient({
  apiKey: 'your_api_key',
  environment: 'production', // or 'staging', 'development'
});

// Authentication
await client.auth.withApiKey('your_api_key');
// or
await client.auth.withOAuth2({
  clientId: 'your_client_id',
  clientSecret: 'your_client_secret',
  scopes: ['design:read', 'design:write']
});

// Documents
const document = await client.documents.create({
  name: 'Summer Campaign',
  width: 1080,
  height: 1080,
  colorSpace: 'sRGB'
});

const doc = await client.documents.get(document.id, {
  includeLayers: true,
  includeHistory: true
});

const documents = await client.documents.list({
  page: 1,
  perPage: 20,
  sort: 'updated_at',
  order: 'desc'
});

await client.documents.update(document.id, {
  name: 'Updated Name'
});

await client.documents.delete(document.id);

// Layers
const layer = await client.layers.create(document.id, {
  type: 'text',
  name: 'Headline',
  properties: {
    content: 'Hello World',
    font: { family: 'Inter', size: 48, weight: 700 },
    color: '#1A1A1A',
    position: { x: 100, y: 100 }
  }
});

await client.layers.update(document.id, layer.id, {
  opacity: 0.8,
  blendMode: 'multiply'
});

await client.layers.delete(document.id, layer.id);

// AI Generation
const generation = await client.ai.generate({
  prompt: 'Create a minimalist Instagram post for a tech product launch',
  designType: 'social_post',
  platform: 'instagram',
  variants: 3,
  brandKitId: 'brand_kit_123'
});

// Poll for completion
const result = await client.ai.waitForCompletion(generation.jobId);

// Or use webhooks
client.webhooks.on('ai.generation.completed', (event) => {
  console.log('Generation completed:', event.data);
});

// Export/Render
const render = await client.documents.render(document.id, {
  format: 'png',
  quality: 90,
  scale: 2
});

const downloadUrl = await client.renders.waitForCompletion(render.jobId);

// Real-time collaboration
const realtime = await client.realtime.connect(document.id);

realtime.on('operation', (operation) => {
  console.log('Remote operation:', operation);
});

realtime.on('cursor', (cursor) => {
  console.log('Remote cursor:', cursor.userId, cursor.position);
});

realtime.on('presence', (presence) => {
  console.log('User presence:', presence.userId, presence.status);
});

// Send operations
realtime.sendOperation({
  type: 'update_layer',
  layerId: layer.id,
  property: 'opacity',
  value: 0.5
});

// Send cursor position
realtime.sendCursor({
  x: 500,
  y: 300,
  selection: [layer.id]
});

// Templates
const template = await client.templates.get('template_123');

const newDoc = await client.templates.apply('template_123', {
  variables: {
    headline: 'Summer Sale',
    discount: '50% OFF',
    productImage: 'https://example.com/product.jpg'
  },
  brandKitId: 'brand_kit_123'
});

// Brand Kits
const brandKit = await client.brandKits.create({
  name: 'My Brand',
  colors: {
    primary: '#FF6B35',
    secondary: '#004E89',
    accent: '#FFD166'
  },
  fonts: {
    primary: 'Montserrat',
    secondary: 'Inter'
  }
});

await client.brandKits.apply(brandKit.id, document.id);

// Assets
const asset = await client.assets.upload(file, {
  name: 'Product Photo',
  tags: ['product', 'summer']
});

const assets = await client.assets.list({
  type: 'image',
  search: 'product'
});

// Webhooks
await client.webhooks.create({
  url: 'https://your-app.com/webhooks/aura',
  events: [
    'document.created',
    'document.updated',
    'render.completed',
    'ai.generation.completed',
    'collaborator.joined',
    'comment.added'
  ],
  secret: 'your_webhook_secret'
});

// Error handling
client.on('error', (error) => {
  console.error('API Error:', error.code, error.message);
});

client.on('rateLimit', (info) => {
  console.warn('Rate limit approaching:', info.remaining, 'remaining');
});
```

### 4.2 Python SDK

```python
# Installation: pip install aura-sdk

from aura_sdk import AuraClient

# Initialize client
client = AuraClient(
    api_key="your_api_key",
    environment="production"  # or "staging", "development"
)

# Documents
document = client.documents.create(
    name="Summer Campaign",
    width=1080,
    height=1080,
    color_space="sRGB"
)

doc = client.documents.get(document.id, include_layers=True)

documents = client.documents.list(
    page=1,
    per_page=20,
    sort="updated_at",
    order="desc"
)

# AI Generation
generation = client.ai.generate(
    prompt="Create a minimalist Instagram post for a tech product launch",
    design_type="social_post",
    platform="instagram",
    variants=3,
    brand_kit_id="brand_kit_123"
)

result = client.ai.wait_for_completion(generation.job_id)

# Export
render = client.documents.render(
    document.id,
    format="png",
    quality=90,
    scale=2
)

download_url = client.renders.wait_for_completion(render.job_id)

# Real-time (using WebSocket)
import asyncio

async def collaborate():
    realtime = await client.realtime.connect(document.id)

    @realtime.on("operation")
    def on_operation(operation):
        print(f"Remote operation: {operation}")

    @realtime.on("cursor")
    def on_cursor(cursor):
        print(f"Remote cursor: {cursor.user_id} at {cursor.position}")

    await realtime.send_operation({
        "type": "update_layer",
        "layer_id": layer.id,
        "property": "opacity",
        "value": 0.5
    })

asyncio.run(collaborate())

# Templates
template = client.templates.get("template_123")

new_doc = client.templates.apply(
    "template_123",
    variables={
        "headline": "Summer Sale",
        "discount": "50% OFF",
        "product_image": "https://example.com/product.jpg"
    },
    brand_kit_id="brand_kit_123"
)

# Brand Kits
brand_kit = client.brand_kits.create(
    name="My Brand",
    colors={
        "primary": "#FF6B35",
        "secondary": "#004E89",
        "accent": "#FFD166"
    },
    fonts={
        "primary": "Montserrat",
        "secondary": "Inter"
    }
)

client.brand_kits.apply(brand_kit.id, document.id)
```

### 4.3 CLI Tool

```bash
# Installation: npm install -g @aura/cli

# Authentication
aura auth login
aura auth status
aura auth logout

# Documents
aura docs create --name "Summer Campaign" --width 1080 --height 1080
aura docs list --page 1 --per-page 20
aura docs get <id> --include-layers
aura docs update <id> --name "New Name"
aura docs delete <id>

# AI Generation
aura ai generate   --prompt "Create a minimalist Instagram post"   --type social_post   --platform instagram   --variants 3   --brand-kit brand_kit_123

# Export
aura docs render <id>   --format png   --quality 90   --scale 2   --output ./output/

# Templates
aura templates list --category social-media
aura templates apply template_123   --var headline="Summer Sale"   --var discount="50% OFF"   --brand-kit brand_kit_123

# Brand Kits
aura brand-kits create --name "My Brand" --from-file brand.json
aura brand-kits list
aura brand-kits apply brand_kit_123 --doc <id>

# Assets
aura assets upload ./photo.jpg --name "Product Photo" --tags product,summer
aura assets list --type image --search product
aura assets delete <id>

# Real-time collaboration
aura collaborate <document_id>

# Webhooks
aura webhooks create   --url https://your-app.com/webhooks/aura   --events document.created,render.completed   --secret your_secret
```

---

## 5. WEBHOOKS

### 5.1 Event Types

```yaml
webhook_events:
  document_events:
    - "document.created"
    - "document.updated"
    - "document.deleted"
    - "document.shared"
    - "document.exported"
    - "document.rendered"

  layer_events:
    - "layer.created"
    - "layer.updated"
    - "layer.deleted"
    - "layer.reordered"

  collaboration_events:
    - "collaborator.joined"
    - "collaborator.left"
    - "collaborator.updated"
    - "comment.added"
    - "comment.resolved"
    - "comment.deleted"

  ai_events:
    - "ai.generation.started"
    - "ai.generation.completed"
    - "ai.generation.failed"
    - "ai.edit.completed"
    - "ai.analysis.completed"

  render_events:
    - "render.queued"
    - "render.started"
    - "render.completed"
    - "render.failed"

  template_events:
    - "template.created"
    - "template.updated"
    - "template.deleted"
    - "template.applied"

  brand_kit_events:
    - "brand_kit.created"
    - "brand_kit.updated"
    - "brand_kit.deleted"
    - "brand_kit.applied"

  asset_events:
    - "asset.uploaded"
    - "asset.updated"
    - "asset.deleted"
    - "asset.optimized"

  user_events:
    - "user.created"
    - "user.updated"
    - "user.deleted"

  team_events:
    - "team.created"
    - "team.updated"
    - "team.member_added"
    - "team.member_removed"
    - "team.member_updated"

  billing_events:
    - "subscription.created"
    - "subscription.updated"
    - "subscription.cancelled"
    - "payment.succeeded"
    - "payment.failed"
    - "usage.threshold_reached"
```

### 5.2 Webhook Payload Structure

```json
{
  "event_id": "evt_1234567890",
  "event_type": "document.created",
  "timestamp": "2026-06-07T12:00:00Z",
  "api_version": "v1",
  "data": {
    "id": "doc_1234567890",
    "name": "Summer Campaign",
    "width": 1080,
    "height": 1080,
    "created_at": "2026-06-07T12:00:00Z",
    "created_by": {
      "id": "user_1234567890",
      "email": "user@example.com",
      "name": "John Doe"
    }
  }
}
```

### 5.3 Webhook Security

```python
import hmac
import hashlib

# Verify webhook signature
def verify_webhook(payload, signature, secret):
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        payload.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(
        f"sha256={expected_signature}",
        signature
    )

# Express.js example
app.post('/webhooks/aura', express.raw({type: 'application/json'}), (req, res) => {
    const signature = req.headers['x-aura-signature'];
    const payload = req.body;

    if (!verifyWebhook(payload, signature, WEBHOOK_SECRET)) {
        return res.status(401).send('Invalid signature');
    }

    const event = JSON.parse(payload);

    switch (event.event_type) {
        case 'ai.generation.completed':
            handleGenerationCompleted(event.data);
            break;
        case 'render.completed':
            handleRenderCompleted(event.data);
            break;
        // ... handle other events
    }

    res.status(200).send('OK');
});
```

---

## 6. ERROR HANDLING

### 6.1 Error Codes

```yaml
error_codes:
  400_bad_request:
    code: "bad_request"
    message: "Invalid request parameters"
    details: "Specific validation errors"

  401_unauthorized:
    code: "unauthorized"
    message: "Invalid or missing authentication"
    action: "Check API key or refresh token"

  403_forbidden:
    code: "forbidden"
    message: "Insufficient permissions"
    action: "Check API key scopes or user permissions"

  404_not_found:
    code: "not_found"
    message: "Resource not found"
    action: "Verify resource ID and existence"

  409_conflict:
    code: "conflict"
    message: "Resource conflict (e.g., duplicate name)"
    action: "Use unique identifier or update existing"

  422_unprocessable:
    code: "unprocessable"
    message: "Request valid but cannot be processed"
    action: "Check business logic constraints"

  429_rate_limit:
    code: "rate_limit_exceeded"
    message: "Too many requests"
    retry_after: "Seconds until retry"
    action: "Wait for retry_after or upgrade plan"

  500_internal:
    code: "internal_error"
    message: "Internal server error"
    action: "Contact support with request ID"

  502_bad_gateway:
    code: "bad_gateway"
    message: "Upstream service error"
    action: "Retry with exponential backoff"

  503_service_unavailable:
    code: "service_unavailable"
    message: "Service temporarily unavailable"
    action: "Retry with exponential backoff"

  504_gateway_timeout:
    code: "gateway_timeout"
    message: "Request timeout"
    action: "Retry or break into smaller requests"
```

### 6.2 Rate Limits

```yaml
rate_limits:
  free_tier:
    requests_per_minute: 100
    requests_per_hour: 1000
    requests_per_day: 5000
    concurrent_renders: 2
    ai_generations_per_day: 50
    storage_gb: 5

  pro_tier:
    requests_per_minute: 1000
    requests_per_hour: 10000
    requests_per_day: 50000
    concurrent_renders: 10
    ai_generations_per_day: 500
    storage_gb: 50

  enterprise_tier:
    requests_per_minute: 10000
    requests_per_hour: 100000
    requests_per_day: 500000
    concurrent_renders: 50
    ai_generations_per_day: 5000
    storage_gb: 500

  headers:
    X-RateLimit-Limit: "Maximum requests allowed"
    X-RateLimit-Remaining: "Remaining requests in window"
    X-RateLimit-Reset: "Unix timestamp when window resets"
    X-RateLimit-Retry-After: "Seconds until retry allowed"
```

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: API Integration Guide*
