# AURA AI Prompt Engineering Guide
## Complete Prompt-to-Design System Reference v1.0

---

## 1. PROMPT ARCHITECTURE

### 1.1 Prompt Structure

```
PROMPT = CONTEXT + INTENT + CONSTRAINTS + OUTPUT_FORMAT + EXAMPLES + REFINEMENT

CONTEXT:
  - Design domain (web, print, social, UI, etc.)
  - Brand context (brand kit, guidelines, existing assets)
  - Audience (demographics, psychographics, use case)
  - Platform (Instagram, web, billboard, etc.)
  - Technical constraints (dimensions, color space, file format)

INTENT:
  - Primary goal (what the design should achieve)
  - Content (what information to include)
  - Style (aesthetic direction, mood, references)
  - Action (create, edit, iterate, analyze, optimize)

CONSTRAINTS:
  - Must include (required elements)
  - Must avoid (prohibited elements)
  - Style rules (color palette, typography, layout)
  - Technical specs (resolution, format, bleed)
  - Accessibility requirements (contrast, alt text)

OUTPUT_FORMAT:
  - Format type (image, vector, code, JSON, description)
  - Dimensions and specs
  - Layer structure
  - Export settings

EXAMPLES:
  - Few-shot examples of desired output
  - Reference images or designs
  - Style references (mood boards, art direction)

REFINEMENT:
  - Iteration instructions
  - Feedback loop parameters
  - Quality thresholds
  - Approval criteria
```

### 1.2 Prompt Template System

```yaml
prompt_templates:
  create_design:
    template: |
      Create a {design_type} for {platform} with the following specifications:

      PURPOSE: {purpose}
      AUDIENCE: {audience}

      CONTENT:
      {content}

      BRAND CONTEXT:
      {brand_context}

      STYLE DIRECTION:
      {style_direction}

      TECHNICAL SPECIFICATIONS:
      - Dimensions: {dimensions}
      - Color Space: {color_space}
      - Format: {format}
      - Resolution: {resolution}

      CONSTRAINTS:
      - Must include: {must_include}
      - Must avoid: {must_avoid}
      - Color palette: {color_palette}
      - Typography: {typography}

      OUTPUT:
      Generate {variants} design variants with:
      1. Full design with all layers editable
      2. Layer-by-layer breakdown
      3. Design rationale and decisions
      4. Accessibility compliance check
      5. Export-ready files in specified format

  edit_design:
    template: |
      Edit the existing design with the following changes:

      CURRENT DESIGN:
      {current_design_description}

      CHANGES REQUIRED:
      {changes}

      CONSTRAINTS:
      - Preserve: {preserve_elements}
      - Update: {update_elements}
      - Add: {add_elements}
      - Remove: {remove_elements}

      STYLE MAINTENANCE:
      - Keep brand consistency: {brand_consistency}
      - Maintain visual hierarchy: {hierarchy_rules}

      OUTPUT:
      Provide:
      1. Updated design
      2. Change log with before/after comparison
      3. Impact analysis on other elements
      4. Updated layer structure

  generate_variants:
    template: |
      Generate {n} design variants based on the base design:

      BASE DESIGN:
      {base_design_description}

      VARIATION PARAMETERS:
      - Style variations: {style_variations}
      - Color variations: {color_variations}
      - Layout variations: {layout_variations}
      - Content variations: {content_variations}

      CONSTRAINTS:
      - Maintain brand consistency across all variants
      - Ensure each variant is distinct and purposeful
      - All variants must meet accessibility standards

      OUTPUT:
      For each variant:
      1. Full design preview
      2. Design rationale
      3. Best use case recommendation
      4. A/B testing suggestions

  analyze_design:
    template: |
      Analyze the following design for quality, effectiveness, and compliance:

      DESIGN:
      {design_description_or_image}

      ANALYSIS CRITERIA:
      - Visual hierarchy and composition
      - Color theory and accessibility
      - Typography and readability
      - Brand alignment
      - Platform optimization
      - Technical quality
      - User experience

      OUTPUT:
      Provide:
      1. Overall score (0-100) with breakdown
      2. Strengths (top 5)
      3. Weaknesses (top 5)
      4. Specific recommendations for improvement
      5. Priority-ranked action items
      6. Before/after mockup suggestions

  optimize_for_platform:
    template: |
      Optimize the design for {target_platform}:

      ORIGINAL DESIGN:
      {original_design_description}

      TARGET PLATFORM REQUIREMENTS:
      - Dimensions: {platform_dimensions}
      - Safe zones: {safe_zones}
      - File format: {platform_format}
      - Max file size: {max_file_size}
      - Text overlay rules: {text_rules}
      - Color profile: {color_profile}

      OPTIMIZATION GOALS:
      - Maintain visual impact at platform dimensions
      - Ensure text readability at platform size
      - Optimize for platform-specific engagement patterns
      - Meet all platform technical requirements

      OUTPUT:
      1. Platform-optimized design
      2. Technical specification checklist
      3. Platform-specific best practices applied
      4. Performance optimization notes
```

---

## 2. PROMPT-TO-DESIGN WORKFLOW

### 2.1 Intent Analysis Pipeline

```
User Input (Natural Language)
    |
[Intent Classifier]
    |
Intent Categories:
  - CREATE: Generate new design from scratch
  - EDIT: Modify existing design
  - ITERATE: Generate variations based on feedback
  - ANALYZE: Evaluate design quality
  - OPTIMIZE: Adapt for specific platform/context
  - AUTOMATE: Batch generate from data
  - CONVERT: Change format/style of existing design
  - TEMPLATE: Create reusable template
    |
[Entity Extractor]
    |
Extracted Entities:
  - Design Type: logo, poster, social post, UI, etc.
  - Platform: Instagram, web, print, etc.
  - Dimensions: explicit or inferred from platform
  - Content: text, images, data
  - Style: modern, vintage, minimalist, etc.
  - Brand: brand kit reference, colors, fonts
  - Audience: demographic, psychographic
  - Mood: energetic, calm, professional, etc.
  - Color: specific colors or mood-based
  - Typography: specific fonts or style
  - Deadline: urgency, timeline
  - Budget: resource constraints
    |
[Constraint Parser]
    |
Constraints:
  - Hard Constraints (must satisfy):
    * Technical specs (dimensions, format, resolution)
    * Legal requirements (copyright, trademark, compliance)
    * Brand guidelines (colors, fonts, logo usage)
    * Accessibility (WCAG level, contrast, alt text)
    * Platform rules (safe zones, text limits, aspect ratios)

  - Soft Constraints (should satisfy):
    * Style preferences (trend alignment, aesthetic)
    * Content preferences (messaging, tone)
    * Performance (file size, load time)
    * SEO (image alt text, structured data)
    |
[Knowledge Retrieval]
    |
Retrieved Knowledge:
  - Platform specifications (dimensions, safe zones, best practices)
  - Design principles (composition, color theory, typography)
  - Industry benchmarks (competitor designs, trends)
  - Brand guidelines (if brand kit provided)
  - Template library (matching templates)
  - Asset library (stock photos, icons, illustrations)
    |
[Design Plan Generator]
    |
Design Plan:
  - Layout strategy (grid, composition, hierarchy)
  - Color strategy (palette, harmony, accessibility)
  - Typography strategy (fonts, scale, hierarchy)
  - Asset strategy (images, icons, illustrations, patterns)
  - Effect strategy (shadows, gradients, animations)
  - Export strategy (formats, sizes, optimizations)
    |
[Design Execution Engine]
    |
Generated Design Document (JSON)
```

### 2.2 Design Plan Structure

```json
{
  "design_plan": {
    "version": "1.0.0",
    "intent": {
      "action": "create",
      "design_type": "social_media_post",
      "platform": "instagram",
      "purpose": "product_announcement",
      "audience": {
        "demographics": "18-35, urban, tech-savvy",
        "psychographics": "early adopters, design-conscious",
        "behavior": "high engagement with visual content"
      }
    },
    "specifications": {
      "dimensions": { "width": 1080, "height": 1080, "unit": "px" },
      "color_space": "sRGB",
      "format": "png",
      "resolution": 72,
      "max_file_size": 5000000
    },
    "layout": {
      "strategy": "centered_hero",
      "grid": "3x3",
      "composition": "rule_of_thirds",
      "hierarchy": [
        { "element": "product_image", "priority": 1, "position": "center" },
        { "element": "headline", "priority": 2, "position": "bottom_third" },
        { "element": "cta", "priority": 3, "position": "bottom_center" },
        { "element": "brand_logo", "priority": 4, "position": "top_left" }
      ],
      "safe_zones": { "top": 0, "bottom": 0, "left": 0, "right": 0 }
    },
    "color": {
      "strategy": "complementary",
      "base_mood": "energetic",
      "palette": {
        "primary": "#FF6B35",
        "secondary": "#004E89",
        "accent": "#FFD166",
        "neutral": {
          "light": "#F8F9FA",
          "dark": "#212529"
        }
      },
      "accessibility": {
        "wcag_level": "AA",
        "contrast_checks": [
          { "foreground": "#FF6B35", "background": "#F8F9FA", "required_ratio": 4.5 },
          { "foreground": "#212529", "background": "#FFD166", "required_ratio": 4.5 }
        ]
      }
    },
    "typography": {
      "strategy": "modern_bold",
      "fonts": {
        "primary": "Montserrat",
        "secondary": "Inter",
        "accent": "JetBrains Mono"
      },
      "scale": {
        "headline": { "size": 48, "weight": 700, "line_height": 1.2 },
        "subhead": { "size": 24, "weight": 600, "line_height": 1.3 },
        "body": { "size": 16, "weight": 400, "line_height": 1.5 },
        "caption": { "size": 12, "weight": 400, "line_height": 1.4 }
      }
    },
    "assets": {
      "images": [
        {
          "role": "hero",
          "source": "ai_generate",
          "prompt": "Modern minimalist product photo, clean white background, soft shadows, professional lighting, high-end tech product",
          "style": "photorealistic",
          "dimensions": { "width": 800, "height": 800 }
        }
      ],
      "icons": [
        {
          "role": "cta_arrow",
          "source": "library",
          "style": "filled",
          "size": 24
        }
      ],
      "patterns": [],
      "illustrations": []
    },
    "effects": {
      "shadows": [
        {
          "element": "product_image",
          "type": "drop_shadow",
          "x": 0, "y": 8, "blur": 24, "spread": 0,
          "color": "rgba(0,0,0,0.15)"
        }
      ],
      "gradients": [
        {
          "element": "background",
          "type": "linear",
          "angle": 135,
          "stops": [
            { "position": 0, "color": "#F8F9FA" },
            { "position": 100, "color": "#E9ECEF" }
          ]
        }
      ],
      "animations": []
    },
    "export": {
      "formats": ["png", "jpeg", "webp"],
      "sizes": [
        { "width": 1080, "height": 1080, "suffix": "_full" },
        { "width": 540, "height": 540, "suffix": "_half" },
        { "width": 150, "height": 150, "suffix": "_thumb" }
      ],
      "optimizations": {
        "png": { "compression": 9, "interlace": false },
        "jpeg": { "quality": 90, "progressive": true },
        "webp": { "quality": 85, "method": 6 }
      }
    }
  }
}
```

---

## 3. PROMPT ENGINEERING TECHNIQUES

### 3.1 Chain-of-Thought Design

```
Technique: Break complex design requests into sequential reasoning steps

Example:
User: "Create a brand identity for a sustainable coffee shop"

Step 1 - Brand Analysis:
  "First, analyze the brand context: sustainable coffee shop targeting
   eco-conscious millennials and Gen Z in urban areas. Values: sustainability,
   community, quality, transparency."

Step 2 - Strategy Development:
  "Based on the analysis, develop brand strategy:
   - Archetype: Everyman/Caregiver hybrid
   - Personality: Warm, authentic, knowledgeable, community-focused
   - Positioning: Premium sustainable coffee with transparent sourcing"

Step 3 - Visual Identity Design:
  "Design visual identity based on strategy:
   - Logo: Organic, hand-drawn feel with coffee bean motif and leaf element
   - Color palette: Earth tones (sage green, warm brown, cream, charcoal)
   - Typography: Friendly serif for headlines (Merriweather), clean sans for body (Inter)
   - Imagery: Natural, authentic, warm lighting, real people, sustainable practices"

Step 4 - Application Design:
  "Create brand applications:
   - Business card: Vertical format, kraft paper texture, minimal ink
   - Packaging: Compostable materials, stamp-style logo, batch numbers
   - Menu: Chalkboard style, hand-lettered elements, ingredient sourcing info
   - Social media: Warm filters, behind-the-scenes content, community highlights"

Step 5 - Validation:
  "Validate against brand strategy and accessibility:
   - Check color contrast ratios (all pass WCAG AA)
   - Verify sustainability messaging consistency
   - Ensure logo works at all sizes (16px to billboard)
   - Test across all intended applications"
```

### 3.2 Few-Shot Design Prompting

```
Technique: Provide examples of desired output style to guide generation

Example:
"Create a minimalist Instagram post for a tech product launch.

Here are 3 examples of the desired style:

Example 1:
- Background: Solid light gray (#F5F5F5)
- Product: Centered, 60% of frame, soft shadow
- Text: Bottom third, bold sans-serif, single line
- Accent: Small brand mark top-left
- Overall: Clean, spacious, premium feel

Example 2:
- Background: Gradient from white to very light blue
- Product: Slightly off-center right, dynamic angle
- Text: Left side, stacked headline + subhead
- Accent: Thin line separator, subtle geometric pattern
- Overall: Modern, airy, innovative

Example 3:
- Background: Dark charcoal (#1A1A1A)
- Product: Glowing, centered, dramatic lighting
- Text: Top, minimal, white, wide letter-spacing
- Accent: Neon accent color (cyan) on CTA
- Overall: Bold, futuristic, premium

Now create a new design following this minimalist, premium aesthetic
for our new wireless earbuds product."
```

### 3.3 Self-Consistency Design

```
Technique: Generate multiple design solutions and select/merge the best elements

Process:
1. Generate 5 independent design solutions for the same prompt
2. Evaluate each solution against criteria:
   - Visual impact (1-10)
   - Brand alignment (1-10)
   - Accessibility compliance (pass/fail)
   - Technical correctness (pass/fail)
   - Innovation (1-10)
   - Usability (1-10)

3. Identify best elements from each:
   - Solution A: Best color palette
   - Solution B: Best typography hierarchy
   - Solution C: Best layout composition
   - Solution D: Best asset selection
   - Solution E: Best overall concept

4. Merge best elements into final design:
   - Apply Solution A's color palette to Solution E's concept
   - Use Solution B's typography with Solution C's layout
   - Integrate Solution D's assets

5. Validate merged design:
   - Ensure all elements work harmoniously
   - Check accessibility compliance
   - Verify technical specifications
   - Confirm brand consistency
```

### 3.4 ReAct (Reasoning + Acting) for Design

```
Technique: Alternate between reasoning about design decisions and executing them

Loop:
1. REASON: Analyze current design state and identify next best action
2. ACT: Execute the design action (add element, modify property, etc.)
3. OBSERVE: Evaluate the result of the action
4. REASON: Based on observation, determine next action
5. Repeat until design meets all criteria

Example trace:
REASON: "Starting with blank 1080x1080 canvas. Need to create Instagram post
         for product launch. First, I need a background that sets the mood.
         Given the premium tech product, a subtle gradient would work well."

ACT: "Create background layer with linear gradient from #F8F9FA to #E9ECEF"

OBSERVE: "Background is clean and neutral. Good foundation. Now needs focal point."

REASON: "Product image should be the focal point. Need to place it centrally
         with good visual weight. Should be about 60% of canvas height."

ACT: "Add product image layer, position at center (540, 540), scale to 60% height"

OBSERVE: "Product is centered but feels flat. Needs depth and context."

REASON: "Adding a subtle drop shadow will create depth and elevate the product
         from the background. Shadow should be soft and natural."

ACT: "Add drop shadow effect: x=0, y=8, blur=24, color=rgba(0,0,0,0.12)"

OBSERVE: "Product now has depth. Need text hierarchy for messaging."

REASON: "Headline should be bold and prominent, positioned in bottom third
         to not compete with product. Use primary brand color for emphasis."

ACT: "Add text layer 'Introducing Aura Buds', position bottom-center,
     font=Montserrat Bold 48px, color=#FF6B35, line-height=1.2"

[Continue until all elements are placed and design is complete]
```

---

## 4. ADVANCED PROMPT TECHNIQUES

### 4.1 Multi-Modal Prompting

```yaml
multimodal_prompting:
  image_to_design:
    description: "Use reference image to guide design generation"
    technique: |
      "Analyze the attached reference image and create a new design
       that captures its [style/mood/composition] while adapting to
       [new context/content].

       Reference image characteristics to preserve:
       - Color palette: [extracted colors]
       - Composition: [layout description]
       - Typography style: [font characteristics]
       - Mood/atmosphere: [emotional description]
       - Visual weight distribution: [balance description]

       New design requirements:
       - Content: [new content]
       - Dimensions: [new dimensions]
       - Platform: [target platform]
       - Brand: [brand guidelines]"

  sketch_to_design:
    description: "Convert rough sketch or wireframe to polished design"
    technique: |
      "Transform the attached sketch into a polished, production-ready design.

       Sketch analysis:
       - Layout structure: [identified grid and zones]
       - Element hierarchy: [priority order]
       - Content placement: [text and image positions]
       - Intended flow: [user eye path]

       Design execution:
       - Apply professional typography and spacing
       - Add appropriate colors and visual effects
       - Select high-quality imagery and icons
       - Ensure accessibility and platform compliance
       - Generate responsive variants if applicable"

  mood_board_to_design:
    description: "Synthesize multiple reference images into cohesive design"
    technique: |
      "Create a design that synthesizes the aesthetic of the attached mood board.

       Mood board analysis:
       - Dominant colors: [color palette extraction]
       - Typography trends: [font style patterns]
       - Composition patterns: [layout trends]
       - Texture and material: [surface qualities]
       - Emotional tone: [mood consensus]
       - Era/style references: [design movement identification]

       Design synthesis:
       - Create original design inspired by mood board
       - Do not copy specific elements from references
       - Capture the essence and feeling of the collection
       - Apply to the specific design brief: [brief]"

  text_plus_image:
    description: "Combine text prompt with image input for precise control"
    technique: |
      "Create a design using the provided image as the primary visual element.

       Image treatment:
       - [specific editing instructions: crop, filter, background removal, etc.]
       - Position: [placement in composition]
       - Style: [visual treatment to apply]

       Text and layout:
       - Headline: [text content]
       - Body copy: [text content]
       - CTA: [text content]
       - Layout: [composition instructions]

       Brand application:
       - Colors: [brand colors]
       - Fonts: [brand fonts]
       - Logo placement: [position and size]"
```

### 4.2 Constraint-Based Prompting

```yaml
constraint_based_prompting:
  hard_constraints:
    description: "Non-negotiable requirements that must be met"
    examples:
      - "Dimensions must be exactly 1080x1920 pixels"
      - "Must include brand logo in top-left corner, minimum 48px height"
      - "All text must meet WCAG AA contrast ratio of 4.5:1 minimum"
      - "File size must not exceed 2MB"
      - "Must use only approved brand colors: #FF6B35, #004E89, #FFD166, #F8F9FA, #212529"
      - "Must include disclaimer text: 'Terms and conditions apply' in 10pt font"
      - "No stock photos of people - use illustrations or product shots only"
      - "Must be print-ready with 3mm bleed and crop marks"

  soft_constraints:
    description: "Preferences that should be satisfied when possible"
    examples:
      - "Prefer modern, minimalist aesthetic"
      - "Use organic shapes and soft edges where possible"
      - "Include subtle texture or pattern in background"
      - "Typography should feel friendly and approachable"
      - "Color palette should feel warm and inviting"
      - "Composition should feel balanced and harmonious"
      - "Consider mobile-first viewing experience"

  negative_constraints:
    description: "Elements or styles to explicitly avoid"
    examples:
      - "Do NOT use gradients on text"
      - "Do NOT use more than 3 font families"
      - "Do NOT place text over busy image areas"
      - "Do NOT use drop shadows on UI elements"
      - "Do NOT use pure black (#000000) - use dark gray (#212529) instead"
      - "Do NOT use clip art or generic icons"
      - "Do NOT use all caps for body text"
      - "Do NOT use more than 5 colors in the design"
```

### 4.3 Iterative Refinement Prompting

```yaml
iterative_refinement:
  technique: "Progressive refinement through feedback loops"

  round_1_initial:
    prompt: "Create initial design based on brief"
    output: "Design v1"

  round_2_feedback:
    prompt: |
      "Review the initial design and provide specific feedback:

       What works well:
       - [list strengths]

       What needs improvement:
       - [list specific issues with element references]

       Specific changes requested:
       1. [precise change instruction]
       2. [precise change instruction]
       3. [precise change instruction]

       Constraints to maintain:
       - [list unchanged constraints]

       Generate updated design incorporating feedback."
    output: "Design v2"

  round_3_polish:
    prompt: |
      "Final refinement pass on the design:

       Check and optimize:
       - Visual hierarchy: Is the focal point clear? (1-10)
       - Color harmony: Do colors work together? (1-10)
       - Typography: Is text readable and well-paced? (1-10)
       - Spacing: Is whitespace used effectively? (1-10)
       - Brand alignment: Does it feel on-brand? (1-10)
       - Accessibility: Does it meet WCAG AA? (pass/fail)
       - Technical: Are all specs correct? (pass/fail)

       Make final adjustments to achieve 9+ on all scores.
       Provide design rationale for each major decision."
    output: "Design v3 (Final)"
```

---

## 5. PROMPT OPTIMIZATION

### 5.1 Prompt Compression

```yaml
prompt_compression:
  technique: "Compress verbose prompts into efficient structured format"

  before: |
    "I need you to create a design for my company's Instagram account.
     We are a sustainable fashion brand called 'GreenThread' that sells
     organic cotton clothing. Our target audience is environmentally
     conscious millennials aged 25-35 who live in urban areas. We want
     to announce our new summer collection which features lightweight
     organic cotton dresses and shirts in natural colors. The design
     should feel fresh, natural, and aspirational. We want to show one
     of our dresses on a model in a natural setting. The text should
     say 'Summer Collection 2026' and 'Organic Cotton, Naturally Beautiful'.
     Our brand colors are sage green (#87A878), cream (#F5F5DC), and
     charcoal (#36454F). We use the font 'Playfair Display' for headlines
     and 'Inter' for body text. The post should be 1080x1080 pixels.
     Please make sure the design looks professional and on-brand."

  after: |
    "DESIGN: Instagram post (1080x1080px, sRGB)
     BRAND: GreenThread (sustainable fashion, organic cotton)
     AUDIENCE: Eco-conscious millennials, 25-35, urban
     CONTENT: Summer Collection 2026 launch
     HEADLINE: 'Summer Collection 2026'
     SUBHEAD: 'Organic Cotton, Naturally Beautiful'
     HERO: Model in organic cotton dress, natural setting
     MOOD: Fresh, natural, aspirational
     COLORS: #87A878 (sage), #F5F5DC (cream), #36454F (charcoal)
     FONTS: Playfair Display (headline), Inter (body)
     STYLE: Professional, on-brand, minimalist"

  compression_rules:
    - "Remove filler words and conversational language"
    - "Use structured key-value format"
    - "Group related information"
    - "Use standard abbreviations and codes"
    - "Remove redundant explanations"
    - "Use bullet points for lists"
    - "Include only actionable information"
```

### 5.2 Prompt Templates Library

```yaml
prompt_templates_library:
  social_media:
    instagram_post: |
      PLATFORM: Instagram Post (1080x1080px)
      BRAND: {brand_name}
      CONTENT: {content_description}
      HEADLINE: {headline_text}
      SUBHEAD: {subhead_text}
      CTA: {cta_text}
      HERO: {hero_image_description}
      COLORS: {color_palette}
      FONTS: {font_selection}
      MOOD: {mood_description}
      STYLE: {style_keywords}
      MUST_INCLUDE: {required_elements}
      MUST_AVOID: {prohibited_elements}

    instagram_story: |
      PLATFORM: Instagram Story (1080x1920px)
      SAFE_ZONE: Center 1080x1420px
      BRAND: {brand_name}
      CONTENT: {content_description}
      INTERACTIVE: {interactive_element: poll|quiz|countdown|swipe|link}
      HERO: {hero_description}
      COLORS: {color_palette}
      FONTS: {font_selection}
      MOOD: {mood_description}
      DURATION: {view_duration_estimate}

    twitter_post: |
      PLATFORM: Twitter/X Post (1200x675px, 16:9)
      BRAND: {brand_name}
      CONTENT: {content_description}
      HEADLINE: {headline_text}
      HERO: {hero_description}
      COLORS: {color_palette}
      FONTS: {font_selection}
      MOOD: {mood_description}
      MAX_TEXT: 3-5 words visible

    linkedin_post: |
      PLATFORM: LinkedIn Post (1200x627px, 1.91:1)
      BRAND: {brand_name}
      CONTENT: {content_description}
      TONE: Professional, thought-leadership
      HEADLINE: {headline_text}
      HERO: {hero_description}
      COLORS: {color_palette}
      FONTS: {font_selection}
      MOOD: {mood_description}

    youtube_thumbnail: |
      PLATFORM: YouTube Thumbnail (1280x720px, 16:9)
      BRAND: {brand_name}
      VIDEO: {video_title}
      HOOK: {attention_grabbing_element}
      FACE: {face_expression_description}
      TEXT: {thumbnail_text}
      COLORS: {high_contrast_palette}
      FONTS: {bold_font_selection}
      MOOD: {mood_description}
      RULES: High contrast, readable at 154x86px, max 3-5 words

  print:
    business_card: |
      FORMAT: Business Card ({dimensions})
      BRAND: {brand_name}
      INFO: Name, Title, Phone, Email, Website, Social
      STYLE: {style_description}
      COLORS: {color_palette}
      FONTS: {font_selection}
      PAPER: {paper_type}
      FINISH: {finish_description}
      BLEED: {bleed_size}
      SAFE_ZONE: {safe_zone_size}

    flyer: |
      FORMAT: Flyer ({dimensions})
      BRAND: {brand_name}
      PURPOSE: {purpose}
      HEADLINE: {headline}
      BODY: {body_copy}
      CTA: {call_to_action}
      CONTACT: {contact_info}
      IMAGES: {image_requirements}
      COLORS: {color_palette}
      FONTS: {font_selection}
      BLEED: {bleed_size}
      SAFE_ZONE: {safe_zone_size}

    poster: |
      FORMAT: Poster ({dimensions})
      BRAND: {brand_name}
      PURPOSE: {purpose}
      HEADLINE: {headline}
      SUBHEAD: {subhead}
      BODY: {body_copy}
      VISUAL: {visual_description}
      CTA: {call_to_action}
      COLORS: {color_palette}
      FONTS: {font_selection}
      BLEED: {bleed_size}
      SAFE_ZONE: {safe_zone_size}
      VIEWING_DISTANCE: {distance}

  web:
    landing_page: |
      FORMAT: Landing Page (Responsive)
      BRAND: {brand_name}
      PURPOSE: {conversion_goal}
      AUDIENCE: {target_audience}
      SECTIONS: {section_list}
      HERO: {hero_content}
      CTA: {primary_cta}
      SOCIAL_PROOF: {testimonials|logos|stats}
      COLORS: {color_palette}
      FONTS: {font_selection}
      STYLE: {style_description}
      BREAKPOINTS: {breakpoint_specs}

    email_template: |
      FORMAT: Email Template (600px max width)
      BRAND: {brand_name}
      TYPE: {email_type}
      SUBJECT: {subject_line}
      PREHEADER: {preheader_text}
      HERO: {hero_content}
      BODY: {body_content}
      CTA: {cta_button}
      FOOTER: {footer_content}
      COLORS: {color_palette}
      FONTS: {web_safe_fonts}
      DARK_MODE: {dark_mode_support}

  branding:
    logo_design: |
      FORMAT: Logo Design (Vector)
      BRAND: {brand_name}
      INDUSTRY: {industry}
      VALUES: {brand_values}
      AUDIENCE: {target_audience}
      STYLE: {logo_style: wordmark|lettermark|pictorial|abstract|mascot|combination}
      MOOD: {mood_description}
      COLORS: {color_preferences}
      FONTS: {font_preferences}
      VARIATIONS: {needed_variations}
      USAGE: {primary_applications}

    brand_identity: |
      FORMAT: Brand Identity System
      BRAND: {brand_name}
      INDUSTRY: {industry}
      VALUES: {brand_values}
      AUDIENCE: {target_audience}
      DELIVERABLES:
        - Logo system (primary, secondary, icon, favicon)
        - Color palette (primary, secondary, accent, neutral, semantic)
        - Typography system (primary, secondary, accent, scale)
        - Imagery style (photography, illustration, iconography)
        - Graphic elements (patterns, textures, shapes)
        - Brand applications (business card, letterhead, social media)
      CONSTRAINTS: {specific_constraints}
```

---

## 6. QUALITY ASSURANCE PROMPTS

### 6.1 Design Review Prompt

```
DESIGN REVIEW PROTOCOL

Review the following design against these criteria and provide a detailed report:

1. VISUAL HIERARCHY (Score 1-10)
   - Is there a clear focal point?
   - Does the eye flow naturally through the content?
   - Are elements sized according to importance?
   - Is there appropriate use of whitespace?

2. COMPOSITION & BALANCE (Score 1-10)
   - Is the layout balanced (symmetrical or intentionally asymmetrical)?
   - Are elements aligned to a grid?
   - Is there visual tension where appropriate?
   - Does the composition support the message?

3. COLOR THEORY (Score 1-10)
   - Is the color palette harmonious?
   - Do colors support the intended mood?
   - Is there sufficient contrast for readability?
   - Are colors accessible (colorblind-safe)?
   - Do colors align with brand guidelines?

4. TYPOGRAPHY (Score 1-10)
   - Are fonts appropriate for the brand and message?
   - Is there clear typographic hierarchy?
   - Is text readable at intended viewing distance?
   - Is line length appropriate (45-75 characters)?
   - Is line spacing appropriate?
   - Are font pairings harmonious?

5. BRAND ALIGNMENT (Score 1-10)
   - Does the design feel on-brand?
   - Are brand colors used correctly?
   - Are brand fonts used correctly?
   - Is the logo used appropriately?
   - Does the tone match brand voice?

6. PLATFORM OPTIMIZATION (Score 1-10)
   - Are dimensions correct for the platform?
   - Are safe zones respected?
   - Is text readable at platform viewing size?
   - Is the design optimized for platform engagement?
   - Does it meet platform technical requirements?

7. TECHNICAL QUALITY (Pass/Fail)
   - Resolution is sufficient for output
   - File format is appropriate
   - Color space is correct
   - Bleed and safe zones are correct (print)
   - File size is optimized

8. ACCESSIBILITY (Pass/Fail)
   - WCAG contrast requirements met
   - Color not sole means of conveying info
   - Text size readable
   - Alt text provided for images
   - Keyboard navigable (digital)

9. INNOVATION & CREATIVITY (Score 1-10)
   - Is the design fresh and original?
   - Does it stand out from competitors?
   - Is there a creative concept?
   - Does it push boundaries while remaining effective?

10. OVERALL EFFECTIVENESS (Score 1-10)
    - Will it achieve the intended goal?
    - Is the message clear?
    - Is the CTA prominent?
    - Will the target audience respond positively?

OUTPUT FORMAT:
{
  "overall_score": "weighted average",
  "category_scores": {
    "visual_hierarchy": "score",
    "composition": "score",
    "color_theory": "score",
    "typography": "score",
    "brand_alignment": "score",
    "platform_optimization": "score",
    "technical_quality": "pass/fail",
    "accessibility": "pass/fail",
    "innovation": "score",
    "effectiveness": "score"
  },
  "strengths": ["top 5 strengths with specific examples"],
  "weaknesses": ["top 5 weaknesses with specific examples"],
  "recommendations": [
    {
      "priority": "high/medium/low",
      "issue": "description",
      "suggestion": "specific actionable fix",
      "impact": "expected improvement"
    }
  ],
  "quick_wins": ["3 easy improvements with high impact"],
  "major_revisions": ["changes that would significantly improve the design"]
}
```

### 6.2 A/B Testing Prompt

```
A/B TEST DESIGN GENERATION

Generate two design variants (A and B) for the same brief with one key difference:

BRIEF: [design brief]

VARIANT A (Control):
- [baseline design approach]

VARIANT B (Test):
- Change ONE element: [specific change]
- Keep all other elements identical to Variant A
- Ensure the change is significant enough to test

HYPOTHESIS: [what we expect to learn]

METRICS TO TRACK:
- Primary: [main KPI]
- Secondary: [supporting metrics]
- Engagement: [engagement metrics]

OUTPUT:
For each variant:
1. Full design preview
2. Design rationale
3. Expected performance based on design psychology
4. Risk assessment
5. Rollback plan if underperforms
```

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: Prompt Engineering Guide*
