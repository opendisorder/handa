# AURA Branding Handbook
## Complete Brand Identity & Guidelines Reference v1.0

---

## 1. BRAND STRATEGY FRAMEWORK

### 1.1 Brand Identity Components

```yaml
brand_identity_components:
  purpose:
    mission: "Why the brand exists (beyond profit)"
    vision: "What the brand wants to achieve in the world"
    values: "Core principles guiding all decisions"

  positioning:
    target_audience: "Who the brand serves (demographics, psychographics, behaviors)"
    market_category: "The industry and competitive landscape"
    differentiation: "What makes the brand unique and valuable"
    value_proposition: "The promise to customers"
    brand_promise: "What customers can always expect"

  personality:
    traits: "5-7 adjectives describing brand character"
    archetype: "Universal character pattern (see Brand Archetypes)"
    voice: "How the brand speaks (tone, vocabulary, style)"

  visual_identity:
    logo: "Primary and secondary marks"
    color_palette: "Primary, secondary, accent, neutral colors"
    typography: "Primary, secondary, and accent typefaces"
    imagery: "Photography style, illustration style, iconography"
    graphic_elements: "Patterns, textures, shapes, lines"

  verbal_identity:
    naming: "Brand name, product names, tagline"
    messaging: "Key messages, elevator pitch, brand story"
    voice_guidelines: "Tone, vocabulary, grammar, style rules"

  sensory_identity:
    sound: "Audio logo, brand music, voice characteristics"
    motion: "Animation style, video style, interaction patterns"
    haptics: "Physical touch (for products), texture, weight"
    scent: "For physical environments (retail, hospitality)"
```

### 1.2 Brand Archetypes

```yaml
brand_archetypes:
  innocent:
    traits: ["Optimistic", "Honest", "Wholesome", "Happy", "Trusting"]
    goal: "To be happy"
    fear: "Doing something wrong, punishment"
    strategy: "Do things right, be simple, be good"
    examples: ["Coca-Cola", "Dove", "Innocent Drinks"]
    colors: ["White", "Pastels", "Soft Blue", "Light Green"]
    typography: ["Rounded sans-serif", "Friendly", "Simple"]

  explorer:
    traits: ["Adventurous", "Curious", "Independent", "Self-directed", "Authentic"]
    goal: "To experience a better, more authentic life"
    fear: "Conformity, entrapment, emptiness"
    strategy: "Journey, seek, experience the new"
    examples: ["Patagonia", "The North Face", "Jeep", "National Geographic"]
    colors: ["Earth tones", "Forest Green", "Deep Blue", "Rust"]
    typography: ["Bold sans-serif", "Handwritten", "Rugged"]

  sage:
    traits: ["Wise", "Knowledgeable", "Expert", "Thoughtful", "Analytical"]
    goal: "To understand the world through knowledge"
    fear: "Ignorance, being misled, inaccuracy"
    strategy: "Seek truth and share it, be objective"
    examples: ["Google", "BBC", "Harvard", "Philips", "MIT"]
    colors: ["Navy", "Deep Blue", "Gray", "White", "Gold"]
    typography: ["Classic serif", "Clean sans-serif", "Academic"]

  hero:
    traits: ["Courageous", "Determined", "Competent", "Inspiring", "Strong"]
    goal: "To prove worth through courageous acts"
    fear: "Weakness, vulnerability, failure"
    strategy: "Be strong, competent, achieve mastery"
    examples: ["Nike", "FedEx", "BMW", "Marines", "Duracell"]
    colors: ["Red", "Black", "Bold Blue", "Silver", "White"]
    typography: ["Bold sans-serif", "Strong", "Dynamic"]

  outlaw:
    traits: ["Rebellious", "Disruptive", "Revolutionary", "Shocking", "Liberated"]
    goal: "To overturn what isn't working"
    fear: "Being powerless, trivialized, inconsequential"
    strategy: "Disrupt, destroy, shock, liberate"
    examples: ["Harley-Davidson", "Virgin", "Diesel", "Apple (1984)"]
    colors: ["Black", "Red", "Dark Gray", "Neon accents"]
    typography: ["Bold", "Distressed", "Industrial", "Custom"]

  magician:
    traits: ["Visionary", "Charismatic", "Transformative", "Holistic", "Inspiring"]
    goal: "To make dreams come true, transform reality"
    fear: "Unintended negative consequences, tricks exposed"
    strategy: "Develop vision, live by it, make it happen"
    examples: ["Disney", "Dyson", "Tesla", "Absolut"]
    colors: ["Purple", "Deep Blue", "Gold", "Silver", "Black"]
    typography: ["Elegant", "Futuristic", "Custom", "Sophisticated"]

  everyman:
    traits: ["Down-to-earth", "Supportive", "Faithful", "Genuine", "Humble"]
    goal: "To belong, connect with others"
    fear: "Standing out, being left out, loneliness"
    strategy: "Develop solid virtues, be down to earth"
    examples: ["IKEA", "Home Depot", "eBay", "Levi's", "Walmart"]
    colors: ["Warm neutrals", "Blue", "Green", "Earth tones"]
    typography: ["Friendly sans-serif", "Accessible", "Simple"]

  lover:
    traits: ["Passionate", "Sensual", "Intimate", "Romantic", "Committed"]
    goal: "To be in relationships, experience intimacy"
    fear: "Being alone, unloved, rejected"
    strategy: "Become more attractive, connect emotionally"
    examples: ["Chanel", "Victoria's Secret", "Godiva", "Häagen-Dazs"]
    colors: ["Red", "Pink", "Purple", "Gold", "Black", "Deep Burgundy"]
    typography: ["Elegant script", "Refined serif", "Sensual"]

  jester:
    traits: ["Playful", "Spontaneous", "Funny", "Optimistic", "Irreverent"]
    goal: "To have a great time, enjoy life"
    fear: "Boredom, sadness, being a killjoy"
    strategy: "Play, make jokes, be funny, lighten up"
    examples: ["Old Spice", "Ben & Jerry's", "M&M's", "Budweiser"]
    colors: ["Bright", "Multicolor", "Orange", "Yellow", "Purple"]
    typography: ["Playful", "Bold", "Hand-drawn", "Whimsical"]

  caregiver:
    traits: ["Compassionate", "Generous", "Nurturing", "Protective", "Empathetic"]
    goal: "To help others, care for people"
    fear: "Selfishness, ingratitude, blame"
    strategy: "Do things for others, be altruistic"
    examples: ["Johnson & Johnson", "UNICEF", "Kleenex", "Campbell's"]
    colors: ["Soft Blue", "Green", "White", "Pastel Pink", "Light Yellow"]
    typography: ["Warm", "Rounded", "Friendly", "Approachable"]

  ruler:
    traits: ["Responsible", "Controlled", "Authoritative", "Organized", "Leader"]
    goal: "To create prosperity and success"
    fear: "Chaos, being overthrown, losing control"
    strategy: "Exercise power, create order, be the best"
    examples: ["Mercedes-Benz", "American Express", "Microsoft", "Rolex"]
    colors: ["Black", "Gold", "Navy", "Silver", "White", "Deep Red"]
    typography: ["Classic serif", "Elegant sans-serif", "Authoritative"]

  creator:
    traits: ["Innovative", "Imaginative", "Artistic", "Ambitious", "Non-conformist"]
    goal: "To create something of enduring value"
    fear: "Mediocre execution, inauthenticity, stagnation"
    strategy: "Develop artistic control, skill, create culture"
    examples: ["Lego", "Crayola", "Adobe", "Apple", "Canon"]
    colors: ["Vibrant", "Multicolor", "Creative combinations", "Bold"]
    typography: ["Custom", "Artistic", "Variable fonts", "Expressive"]
```

---

## 2. LOGO DESIGN SYSTEM

### 2.1 Logo Types & Applications

```yaml
logo_types:
  wordmark:
    description: "Text-only logo using distinctive typography"
    best_for: ["Strong name recognition", "Premium brands", "Fashion", "Media"]
    characteristics: ["Custom typography", "Letterform uniqueness", "Memorable name"]
    examples: ["Google", "Coca-Cola", "Disney", "Canon", "FedEx"]
    considerations: ["Name must be distinctive", "Typography must be unique", "Works at all sizes"]

  lettermark:
    description: "Initials or acronym as logo"
    best_for: ["Long names", "Tech companies", "Government", "International"]
    characteristics: ["1-4 letters", "Distinctive letterforms", "Monogram style"]
    examples: ["IBM", "HBO", "NASA", "CNN", "HP", "EA"]
    considerations: ["Initials must be memorable", "Works as favicon/app icon", "May need full name for context"]

  pictorial:
    description: "Recognizable image or icon"
    best_for: ["Global brands", "App icons", "Consumer goods", "Startups"]
    characteristics: ["Literal representation", "Simple and recognizable", "Scalable"]
    examples: ["Apple", "Twitter", "Shell", "Target", "WWF"]
    considerations: ["Image must be unique and ownable", "Works in monochrome", "Avoids trends"]

  abstract:
    description: "Abstract geometric or organic form"
    best_for: ["Tech startups", "Innovation", "Diverse services", "Global brands"]
    characteristics: ["Non-literal", "Unique shape", "Symbolic meaning"]
    examples: ["Nike", "Pepsi", "Adidas", "BP", "Chase"]
    considerations: ["Shape must be distinctive", "Conveys brand values", "Works at all sizes"]

  mascot:
    description: "Character or figure as logo"
    best_for: ["Family brands", "Sports", "Food", "Entertainment"]
    characteristics: ["Personality", "Memorable character", "Emotional connection"]
    examples: ["KFC", "MailChimp", "Pringles", "Michelin", "Geico"]
    considerations: ["Character must be likable", "Works across cultures", "Age well"]

  combination:
    description: "Text + symbol combined"
    best_for: ["New brands", "Versatility", "Recognition building", "Diverse applications"]
    characteristics: ["Integrated or lockup", "Flexible usage", "Brand name + visual"]
    examples: ["Burger King", "Doritos", "Lacoste", "Puma", "Amazon"]
    considerations: ["Integration must be harmonious", "Works as separate elements", "Scalable"]

  emblem:
    description: "Text inside symbol or shape"
    best_for: ["Traditional", "Schools", "Organizations", "Sports teams"]
    characteristics: ["Contained within shape", "Badge or seal style", "Formal"]
    examples: ["Harvard", "Starbucks", "NFL", "Harley-Davidson", "BMW"]
    considerations: ["Detail must be legible at small sizes", "Shape must be distinctive", "May be complex"]

  dynamic:
    description: "Adaptable, changing form based on context"
    best_for: ["Creative agencies", "Media", "Tech", "Cultural institutions"]
    characteristics: ["Multiple variants", "System-based", "Generative"]
    examples: ["MTV", "AOL", "City of Melbourne", "Google (Doodles)", "Nordkyn"]
    considerations: ["System must be coherent", "Core identity must be recognizable", "Flexible but controlled"]

  responsive:
    description: "Logo adapts to context (size, platform, medium)"
    best_for: ["Digital-first brands", "Multi-platform", "Adaptive design"]
    characteristics: ["Multiple optimized versions", "Simplification at small sizes", "Detail at large sizes"]
    examples: ["Nike (swoosh alone at small sizes)", "Apple", "Microsoft", "Spotify"]
    considerations: ["All versions must be recognizable", "Clear hierarchy of versions", "Systematic simplification"]
```

### 2.2 Logo Design Principles

```yaml
logo_design_principles:
  simplicity:
    description: "Remove everything non-essential"
    rule: "A child should be able to draw it from memory"
    benefit: ["Memorable", "Scalable", "Versatile", "Timeless"]
    test: "Reduce to 1-inch size, should still be clear"

  memorability:
    description: "Create a distinctive, memorable impression"
    rule: "Unique enough to be recalled after brief exposure"
    technique: ["Unexpected element", "Clever negative space", "Unique proportion"]
    test: "Show for 3 seconds, ask people to draw it"

  timelessness:
    description: "Avoid trends that will date the logo"
    rule: "Will it look good in 10 years? 50 years?"
    technique: ["Classic proportions", "Simple geometry", "Avoid gradients/effects"]
    test: "Check logos from 50 years ago that still work"

  versatility:
    description: "Work across all applications and contexts"
    rule: "Must work in: color, black and white, reversed, small, large, digital, print"
    test: ["1-inch print", "Favicon (16x16)", "Billboard", "Embroidery", "Social media avatar"]

  appropriateness:
    description: "Fit the brand's industry, audience, and personality"
    rule: "A law firm and a toy company need different approaches"
    consideration: ["Industry norms", "Audience expectations", "Brand personality", "Cultural context"]

  scalability:
    description: "Maintain clarity at all sizes"
    rule: "Minimum size: 0.5 inch (12mm) for print, 16px for digital"
    technique: ["Simplified small version", "Thick strokes", "Clear shapes", "Test at all sizes"]

  balance:
    description: "Visual weight distributed harmoniously"
    rule: "Optical balance, not necessarily mathematical balance"
    technique: ["Adjust for visual weight, not center of mass", "Consider negative space", "Test by flipping"]

  proportion:
    description: "Use harmonious proportions and geometry"
    rule: "Golden ratio (1:1.618), √2 (1:1.414), or simple ratios (1:1, 2:1, 3:2)"
    technique: ["Construct with geometric guides", "Use grid systems", "Align to mathematical relationships"]

  negative_space:
    description: "Use empty space as an active design element"
    rule: "The space around and within is as important as the marks themselves"
    examples: ["FedEx arrow", "WWF panda", "NBC peacock", "Toblerone bear"]

  uniqueness:
    description: "Be distinctive and ownable"
    rule: "Avoid generic symbols (globes, swooshes, checkmarks unless truly unique)"
    technique: ["Custom letterforms", "Unique geometry", "Unexpected combinations", "Ownable concept"]
    test: ["Trademark search", "Competitive audit", "Google image search"]
```

### 2.3 Logo Construction

```yaml
logo_construction:
  grid_system:
    description: "Use a consistent grid for construction and scaling"
    types:
      - "Square grid (pixel-perfect alignment)"
      - "Golden ratio grid (1:1.618 proportions)"
      - "Modular grid (equal units)"
      - "Circle/square/triangle geometry (Platonic solids)"

  clear_space:
    description: "Minimum space around logo that must be kept clear"
    standard: "Equal to height of lowercase letter (x-height) or height of logo mark"
    application: "No text, graphics, or other elements within clear space"

  minimum_size:
    print: "0.5 inch (12mm) width for wordmark, 0.25 inch (6mm) for icon"
    digital: "16px height for favicon, 24px for UI icons, 120px for social media"

  color_variants:
    primary: "Full color on light background"
    secondary: "Full color on dark background"
    monochrome_black: "Black on light background"
    monochrome_white: "White on dark background"
    one_color: "Single brand color on light background"
    reversed: "Reversed (white on brand color)"
    grayscale: "Grayscale for low-quality printing"

  incorrect_usage:
    - "Stretching or distorting"
    - "Changing colors (except approved variants)"
    - "Adding effects (shadows, glows, outlines, bevels)"
    - "Rotating or tilting"
    - "Placing on busy backgrounds without clear space"
    - "Changing proportions"
    - "Using outdated versions"
    - "Placing too close to other logos or elements"
    - "Using low-resolution files"
    - "Altering letterforms or shapes"
```

---

## 3. BRAND COLOR SYSTEM

### 3.1 Brand Color Palette

```yaml
brand_color_palette:
  primary:
    description: "Main brand color, most recognizable and used"
    count: "1-2 colors"
    usage: "Logo, primary buttons, key headlines, brand moments"
    selection_criteria: ["Industry appropriate", "Differentiated from competitors", "Emotionally aligned with brand personality", "Accessible on white and dark backgrounds"]

  secondary:
    description: "Supporting colors that complement primary"
    count: "1-3 colors"
    usage: "Secondary buttons, accents, backgrounds, illustrations"
    selection_criteria: ["Harmonious with primary", "Provides contrast", "Expands palette without diluting brand"]

  accent:
    description: "High-energy colors for calls-to-action and highlights"
    count: "1-2 colors"
    usage: "CTAs, notifications, badges, highlights, important data"
    selection_criteria: ["High contrast with primary", "Action-oriented", "Not overused"]

  neutral:
    description: "Grays and off-whites for backgrounds, text, and UI"
    count: "5-8 shades"
    usage: "Backgrounds, text, borders, dividers, subtle UI elements"
    selection_criteria: ["Warm or cool undertone matching primary", "Sufficient contrast range", "Not pure black or white"]

  semantic:
    description: "Colors for system states and feedback"
    count: "4 colors (success, warning, error, info)"
    usage: "Alerts, form validation, status indicators, badges"
    selection_criteria: ["Universally understood (green=good, red=bad)", "Accessible contrast", "Distinct from brand colors"]

  extended:
    description: "Additional colors for illustrations, data visualization, seasonal campaigns"
    count: "5-10 colors"
    usage: "Charts, infographics, illustrations, campaigns, seasonal"
    selection_criteria: ["Harmonious with core palette", "Provides variety for data viz", "Can be updated without affecting core brand"]
```

### 3.2 Color Usage Ratios

```yaml
color_usage_ratios:
  60_30_10_rule:
    description: "Classic interior design rule applied to brand design"
    primary_60: "60% dominant neutral or primary color (backgrounds, large areas)"
    secondary_30: "30% secondary color (sections, cards, supporting elements)"
    accent_10: "10% accent color (CTAs, highlights, key elements)"

  70_20_10_rule:
    description: "More conservative version for professional brands"
    neutral_70: "70% neutral (backgrounds, text, UI chrome)"
    primary_20: "20% primary (headers, key UI, brand moments)"
    accent_10: "10% accent (CTAs, highlights, badges)"

  50_25_25_rule:
    description: "Balanced version for vibrant brands"
    primary_50: "50% primary (dominant brand presence)"
    secondary_25: "25% secondary (supporting, variety)"
    accent_25: "25% accent (energy, highlights, CTAs)"

  application_guidelines:
    backgrounds: "Neutral palette (white, light gray, dark gray, black)"
    text: "Neutral palette (dark gray, black, white on dark)"
    primary_actions: "Primary brand color"
    secondary_actions: "Secondary brand color or neutral"
    destructive_actions: "Semantic error color (red)"
    success_states: "Semantic success color (green)"
    warning_states: "Semantic warning color (yellow/orange)"
    info_states: "Semantic info color (blue)"
    links: "Primary or accent color"
    hover_states: "Darker or lighter variant of base color"
    focus_states: "High contrast outline (2px, 3:1 contrast)"
    disabled_states: "Neutral gray, reduced opacity (50%)"
```

---

## 4. BRAND TYPOGRAPHY SYSTEM

### 4.1 Brand Font Selection

```yaml
brand_font_selection:
  primary_font:
    description: "Main brand typeface for headlines, key messaging, and display"
    criteria:
      - "Aligns with brand personality (see Typography Psychology)"
      - "Distinctive and ownable (not overused by competitors)"
      - "Excellent legibility at display sizes"
      - "Sufficient weights (at least 4: Light, Regular, Medium, Bold)"
      - "Supports all required languages and scripts"
      - "Licensed for all use cases (web, app, print, broadcast)"
      - "Variable font preferred for performance and flexibility"

  secondary_font:
    description: "Supporting typeface for body text, UI, and long-form reading"
    criteria:
      - "High legibility at small sizes (8-16px)"
      - "Complements primary font (contrast in classification)"
      - "Large x-height for screen readability"
      - "Extensive character set and OpenType features"
      - "Works well at low weights (300-400)"
      - "Hinted for screen rendering"

  accent_font:
    description: "Optional decorative or special-use typeface"
    criteria:
      - "Used sparingly (quotes, special headlines, decorative text)"
      - "Highly distinctive and expressive"
      - "Aligns with specific brand moments or campaigns"
      - "Not required for all brands"

  monospace_font:
    description: "For code, data, tables, and technical content"
    criteria:
      - "Clear distinction between similar characters (0/O, 1/l/I)"
      - "Ligatures for programming (if applicable)"
      - "Aligns with brand personality (technical, retro, modern)"

  font_pairing_rules:
    - "Contrast in classification: Serif + Sans-Serif"
    - "Similar x-height for visual harmony when mixed"
    - "Maximum 2-3 font families in any single design"
    - "Use superfamilies when possible (guaranteed harmony)"
    - "Consider loading performance (variable fonts, subsetting)"
    - "Test at all sizes and weights used in brand"
    - "Ensure both fonts have similar character coverage"
```

### 4.2 Brand Typography Scale

```yaml
brand_typography_scale:
  display:
    sizes: ["96px", "80px", "72px", "64px", "56px", "48px"]
    use: "Hero headlines, massive statements, brand moments"
    weight: "Bold (700) or Black (900)"
    letter_spacing: "-0.02em to -0.04em (tight)"
    line_height: "1.0 to 1.1"
    text_transform: "None or uppercase (sparingly)"

  heading:
    h1: { size: "48px", weight: 700, line_height: 1.2, letter_spacing: "-0.02em" }
    h2: { size: "36px", weight: 600, line_height: 1.25, letter_spacing: "-0.01em" }
    h3: { size: "28px", weight: 600, line_height: 1.3, letter_spacing: "-0.01em" }
    h4: { size: "22px", weight: 600, line_height: 1.35, letter_spacing: "0" }
    h5: { size: "18px", weight: 600, line_height: 1.4, letter_spacing: "0" }
    h6: { size: "16px", weight: 600, line_height: 1.4, letter_spacing: "0.01em" }
    use: "Section headings, page titles, component headers"

  body:
    large: { size: "18px", weight: 400, line_height: 1.6, letter_spacing: "0" }
    regular: { size: "16px", weight: 400, line_height: 1.6, letter_spacing: "0" }
    small: { size: "14px", weight: 400, line_height: 1.5, letter_spacing: "0.01em" }
    use: "Paragraphs, descriptions, general content"

  ui:
    label: { size: "14px", weight: 500, line_height: 1.4, letter_spacing: "0.01em" }
    caption: { size: "12px", weight: 400, line_height: 1.4, letter_spacing: "0.02em" }
    overline: { size: "12px", weight: 500, line_height: 1.4, letter_spacing: "0.1em", text_transform: "uppercase" }
    button: { size: "14px", weight: 600, line_height: 1, letter_spacing: "0.02em" }
    input: { size: "16px", weight: 400, line_height: 1.5, letter_spacing: "0" }
    use: "UI elements, forms, buttons, navigation"

  special:
    quote: { size: "24px", weight: 400, line_height: 1.5, letter_spacing: "0", style: "italic" }
    pull_quote: { size: "32px", weight: 300, line_height: 1.4, letter_spacing: "-0.01em", style: "italic" }
    stat: { size: "64px", weight: 700, line_height: 1.1, letter_spacing: "-0.02em" }
    use: "Special content types, emphasis, data"
```

---

## 5. BRAND IMAGERY SYSTEM

### 5.1 Photography Style

```yaml
photography_style:
  authentic:
    description: "Real people, real moments, unposed"
    characteristics: ["Natural lighting", "Candid moments", "Diverse subjects", "Genuine emotions"]
    use: ["Social media", "About pages", "Culture content", "Testimonials"]
    avoid: ["Stock photos", "Overly posed", "Fake smiles", "Homogeneous subjects"]

  lifestyle:
    description: "Products/services in real-life contexts"
    characteristics: ["Environmental context", "Natural settings", " aspirational but achievable", "Emotional connection"]
    use: ["Product pages", "Marketing campaigns", "Social media", "Editorial"]
    avoid: ["Studio-only", "Disconnected from reality", "Unattainable perfection"]

  product:
    description: "Clean, focused product photography"
    characteristics: ["Clean backgrounds", "Consistent lighting", "Multiple angles", "Detail shots"]
    use: ["E-commerce", "Catalogs", "Product pages", "Ads"]
    avoid: ["Busy backgrounds", "Inconsistent lighting", "Low resolution", "Distracting props"]

  editorial:
    description: "Magazine-style, artistic, conceptual"
    characteristics: ["Strong composition", "Artistic lighting", "Conceptual", "Fashion-forward"]
    use: ["Magazines", "Lookbooks", "Brand campaigns", "Hero images"]
    avoid: ["Generic", "Overly commercial", "Disconnected from brand"]

  documentary:
    description: "Storytelling, narrative, behind-the-scenes"
    characteristics: ["Narrative sequence", "Candid moments", "Contextual details", "Human stories"]
    use: ["Brand films", "Culture content", "Impact reports", "Social responsibility"]
    avoid: ["Staged", "Manipulative", "Inauthentic"]

  abstract:
    description: "Non-representational, texture, color, form"
    characteristics: ["Macro details", "Textures", "Patterns", "Color fields"]
    use: ["Backgrounds", "Textures", "Decorative elements", "Mood setting"]
    avoid: ["Random", "Disconnected from brand", "Overused"]

  illustration_style:
    flat: "2D, minimal shading, bold colors, vector-based"
    isometric: "3D perspective without vanishing points, technical"
    3d: "Rendered 3D objects, realistic or stylized"
    hand_drawn: "Sketchy, organic, human, imperfect"
    line_art: "Single weight or variable weight lines, minimal"
    watercolor: "Soft, painterly, organic, artistic"
    collage: "Mixed media, cutouts, layered, eclectic"

  iconography_style:
    filled: "Solid shapes, bold, high contrast"
    outlined: "Line-based, minimal, modern"
    duotone: "Two colors, depth without complexity"
    gradient: "Color transitions, modern, dynamic"
    hand_drawn: "Organic, imperfect, friendly, unique"
    3d: "Rendered, realistic, tactile, premium"
```

### 5.2 Image Treatment Guidelines

```yaml
image_treatment:
  color_treatment:
    full_color: "Natural, vibrant, true-to-life"
    desaturated: "Reduced saturation, muted, sophisticated"
    monochrome: "Black and white, timeless, dramatic"
    duotone: "Two-color treatment, brand-aligned"
    color_overlay: "Brand color overlay at 20-40% opacity"
    color_cast: "Warm or cool cast for mood"

  contrast:
    high_contrast: "Dramatic, bold, impactful"
    medium_contrast: "Natural, balanced, versatile"
    low_contrast: "Soft, dreamy, ethereal, vintage"

  brightness:
    bright: "Optimistic, open, airy, positive"
    medium: "Natural, balanced, true-to-life"
    dark: "Moody, dramatic, mysterious, intimate"

  sharpness:
    sharp: "Crisp, detailed, modern, technical"
    soft: "Dreamy, romantic, nostalgic, gentle"
    selective_focus: "Sharp subject, soft background (bokeh)"

  grain:
    clean: "Digital, modern, crisp, professional"
    film_grain: "Analog, nostalgic, artistic, textured"
    heavy_grain: "Vintage, gritty, documentary, raw"

  cropping:
    rule_of_thirds: "Standard, balanced, versatile"
    center_crop: "Direct, bold, symmetrical, focused"
    extreme_crop: "Abstract, detail-focused, artistic"
    full_bleed: "Edge-to-edge, immersive, dramatic"

  consistency_rules:
    - "All images in a series must use same treatment"
    - "Brand imagery should have consistent color temperature"
    - "Contrast levels should be similar across brand images"
    - "Cropping style should be consistent within a campaign"
    - "Subject matter should align with brand values and audience"
    - "Diversity and inclusion must be authentic and representative"
```

---

## 6. BRAND VOICE & TONE

### 6.1 Voice Characteristics

```yaml
voice_characteristics:
  personality_traits:
    description: "5-7 adjectives that describe how the brand sounds"
    examples:
      - "Friendly, Professional, Confident, Clear, Innovative"
      - "Bold, Playful, Direct, Authentic, Energetic"
      - "Sophisticated, Warm, Knowledgeable, Trustworthy, Inspiring"

  vocabulary:
    words_to_use:
      description: "Words and phrases that reflect brand personality"
      examples: ["Empower", "Simplify", "Transform", "Discover", "Create"]

    words_to_avoid:
      description: "Words that contradict brand personality or are overused"
      examples: ["Synergy", "Leverage", "Paradigm", "Disruptive (unless truly disruptive)", "Revolutionary"]

  grammar_and_style:
    contractions: "Use or avoid? (e.g., 'we're' vs 'we are')"
    humor: "Type and frequency of humor"
    emoji: "When and how to use emojis"
    abbreviations: "When acceptable (e.g., 'AI' vs 'artificial intelligence')"
    numbers: "Numerals vs spelled out"
    capitalization: "Title case vs sentence case"
    oxford_comma: "Use or not?"
    active_voice: "Preferred over passive voice"
    second_person: "'You' vs 'we' vs 'customers'"

  tone_variations:
    by_context:
      marketing: "Energetic, aspirational, benefit-focused"
      product: "Clear, instructional, helpful, concise"
      support: "Empathetic, patient, solution-focused"
      legal: "Formal, precise, cautious, comprehensive"
      social_media: "Conversational, timely, engaging, brand-appropriate"
      internal: "Direct, collaborative, inclusive, motivating"

    by_audience:
      new_customers: "Welcoming, educational, reassuring"
      existing_customers: "Appreciative, familiar, advanced"
      enterprise: "Professional, detailed, ROI-focused"
      developers: "Technical, precise, efficient, code examples"
      casual_users: "Simple, friendly, visual, step-by-step"
```

### 6.2 Messaging Framework

```yaml
messaging_framework:
  brand_promise:
    description: "The one thing customers can always expect"
    format: "We promise to [verb] [target audience] by [unique mechanism]"
    example: "We promise to empower creators by making design accessible to everyone"

  elevator_pitch:
    description: "30-second explanation of what the brand does and why it matters"
    format: "For [target audience] who [problem/need], [brand name] is a [category] that [key benefit]. Unlike [competitors], we [unique differentiation]."

  value_propositions:
    primary: "Main benefit that drives purchase decision"
    secondary: "2-3 supporting benefits that reinforce primary"
    emotional: "How the brand makes customers feel"
    functional: "What the brand enables customers to do"

  key_messages:
    description: "3-5 core messages that should appear across all communications"
    requirements:
      - "Aligned with brand strategy"
      - "Differentiated from competitors"
      - "Supported by proof points"
      - "Memorable and repeatable"
      - "Adaptable to different contexts"

  proof_points:
    description: "Evidence that supports key messages"
    types: ["Statistics", "Customer testimonials", "Case studies", "Awards", "Expert endorsements", "Data", "Research"]

  tagline:
    description: "Short, memorable phrase that captures brand essence"
    characteristics: ["Under 7 words", "Memorable", "Differentiated", "Aligned with brand promise", "Timeless"]
    examples: ["Nike: Just Do It", "Apple: Think Different", "De Beers: A Diamond is Forever"]
```

---

## 7. BRAND APPLICATIONS

### 7.1 Digital Applications

```yaml
digital_applications:
  website:
    sections: ["Homepage", "Product pages", "About", "Blog", "Contact", "Support"]
    requirements: ["Responsive", "Accessible (WCAG AA)", "Fast loading", "SEO optimized", "Brand consistent"]

  mobile_app:
    platforms: ["iOS", "Android"]
    requirements: ["Native feel", "Platform guidelines", "Brand consistent", "Performance optimized"]

  social_media:
    platforms: ["Instagram", "Facebook", "Twitter", "LinkedIn", "TikTok", "YouTube", "Pinterest"]
    requirements: ["Platform-optimized formats", "Consistent visual identity", "Engaging content", "Brand voice"]

  email:
    types: ["Newsletter", "Promotional", "Transactional", "Onboarding", "Re-engagement"]
    requirements: ["Mobile optimized", "Brand consistent", "Clear CTAs", "Accessible", "Spam compliant"]

  digital_ads:
    formats: ["Display", "Social", "Search", "Video", "Native"]
    requirements: ["Platform specs", "Brand consistent", "Clear messaging", "Strong CTA", "A/B testable"]

  presentations:
    types: ["Sales deck", "Investor pitch", "Internal training", "Webinar", "Conference"]
    requirements: ["Brand templates", "Consistent layouts", "Clear hierarchy", "Engaging visuals"]
```

### 7.2 Print Applications

```yaml
print_applications:
  business_cards:
    standard_us: "3.5in x 2in"
    standard_eu: "85mm x 55mm"
    requirements: ["Legible at small size", "Logo clear", "Contact info hierarchy", "Premium paper feel"]

  letterhead:
    standard: "8.5in x 11in (US), A4 (EU)"
    requirements: ["Professional", "Logo placement consistent", "Contact info", "Legal compliance"]

  brochures:
    types: ["Tri-fold", "Bi-fold", "Z-fold", "Gate-fold"]
    requirements: ["Clear hierarchy", "Scannable", "Strong CTA", "Brand consistent", "Print quality"]

  flyers:
    standard: "8.5in x 11in, A4, A5"
    requirements: ["Attention-grabbing", "Clear message", "Strong CTA", "Contact info", "Scannable in 3 seconds"]

  posters:
    sizes: ["11x17in", "18x24in", "24x36in", "A2", "A1", "A0"]
    requirements: ["Readable from distance", "Strong visual impact", "Clear hierarchy", "Brand consistent"]

  packaging:
    types: ["Box", "Bag", "Bottle", "Label", "Tube"]
    requirements: ["Brand recognition", "Legal compliance", "Sustainability info", "Barcode", "Product info"]

  merchandise:
    items: ["T-shirts", "Tote bags", "Stickers", "Mugs", "Notebooks", "Pens"]
    requirements: ["Brand consistent", "Quality materials", "Practical", "Desirable"]

  signage:
    types: ["Storefront", "Wayfinding", "Event", "Vehicle", "Billboard"]
    requirements: ["Readable from distance", "Weather resistant", "Brand consistent", "Legal compliance"]
```

### 7.3 Environmental Applications

```yaml
environmental_applications:
  office_space:
    elements: ["Reception", "Meeting rooms", "Workspaces", "Common areas", "Wayfinding"]
    requirements: ["Brand immersion", "Employee pride", "Visitor impression", "Functional"]

  retail:
    elements: ["Storefront", "Window displays", "Interior design", "Product displays", "Checkout", "Fitting rooms"]
    requirements: ["Brand experience", "Sales optimization", "Customer journey", "Consistent globally"]

  events:
    elements: ["Booth design", "Banners", "Swag", "Presentations", "Digital displays", "Lighting"]
    requirements: ["Attention-grabbing", "Brand consistent", "Functional", "Memorable"]

  vehicles:
    types: ["Cars", "Trucks", "Vans", "Buses"]
    requirements: ["Visible from distance", "Brand consistent", "Legal compliance", "Durable"]
```

---

## 8. BRAND GOVERNANCE

### 8.1 Brand Guidelines Structure

```yaml
brand_guidelines_structure:
  introduction:
    contents: ["Brand story", "Mission, vision, values", "Brand promise", "How to use these guidelines"]

  visual_identity:
    contents:
      - "Logo (correct usage, clear space, minimum size, variants, incorrect usage)"
      - "Color palette (primary, secondary, accent, neutral, semantic, usage ratios)"
      - "Typography (primary font, secondary font, scale, usage, web fonts)"
      - "Imagery (photography style, illustration style, iconography, image treatment)"
      - "Graphic elements (patterns, textures, shapes, lines, gradients)"
      - "Layout (grid system, spacing, composition rules)"

  verbal_identity:
    contents:
      - "Brand voice (personality traits, vocabulary, grammar, style)"
      - "Tone variations (by context, by audience)"
      - "Messaging framework (elevator pitch, key messages, proof points, tagline)"
      - "Naming conventions (products, features, programs)"
      - "Writing guidelines (style guide, grammar rules, formatting)"

  applications:
    contents:
      - "Digital (website, app, social media, email, ads, presentations)"
      - "Print (business cards, letterhead, brochures, flyers, posters, packaging)"
      - "Environmental (office, retail, events, vehicles)"
      - "Merchandise (apparel, accessories, promotional items)"

  legal:
    contents:
      - "Trademark usage (registered symbols, proper nouns, legal text)"
      - "Copyright notices"
      - "Usage permissions (who can use, what requires approval)"
      - "Co-branding guidelines (partnerships, sponsorships)"
      - "Third-party usage (media, press, partners)"

  resources:
    contents:
      - "Asset downloads (logo files, templates, fonts, color swatches)"
      - "Design templates (PPT, Word, InDesign, Figma, Sketch)"
      - "Contact information (brand team, approvals, questions)"
      - "Version history (updates, changes, archive)"
```

### 8.2 Brand Approval Process

```yaml
brand_approval_process:
  tier_1_standard:
    description: "Pre-approved templates and assets, no approval needed"
    examples: ["Business cards using approved template", "Social posts using approved templates", "Email using approved templates"]
    process: "Self-service, use approved templates only"

  tier_2_custom:
    description: "Custom applications using brand guidelines"
    examples: ["Custom marketing collateral", "Event materials", "Custom presentations", "New web pages"]
    process: "Submit to brand team for review, 2-3 business days turnaround"

  tier_3_strategic:
    description: "High-visibility or strategic brand applications"
    examples: ["New campaigns", "Rebranding initiatives", "Major partnerships", "Product launches", "Global campaigns"]
    process: "Brand strategy team involvement, multiple rounds, executive approval"

  tier_4_exception:
    description: "Exceptions to brand guidelines"
    examples: ["Co-branding with partners", "Cultural adaptations", "Special events", "Experimental campaigns"]
    process: "Formal exception request, brand council review, documented approval"

  approval_criteria:
    - "Alignment with brand strategy and values"
    - "Consistency with visual and verbal identity"
    - "Quality and craftsmanship"
    - "Appropriateness for target audience and context"
    - "Legal and regulatory compliance"
    - "Accessibility standards"
    - "Cultural sensitivity and inclusivity"
```

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: Branding Handbook*
