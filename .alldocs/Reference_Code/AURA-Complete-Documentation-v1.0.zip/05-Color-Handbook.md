# AURA Color Handbook
## Complete Color Science & Application Reference v1.0

---

## 1. COLOR THEORY FUNDAMENTALS

### 1.1 Color Models

```yaml
color_models:
  RGB:
    description: "Additive color model for digital displays"
    primaries: ["Red (R)", "Green (G)", "Blue (B)"]
    range: "0-255 per channel (8-bit) or 0.0-1.0 (float)"
    gamut: "Device-dependent, typically sRGB or Display P3"
    use: ["Digital screens", "Web", "Video", "Photography"]

  CMYK:
    description: "Subtractive color model for print"
    primaries: ["Cyan (C)", "Magenta (M)", "Yellow (Y)", "Key/Black (K)"]
    range: "0-100% per channel"
    gamut: "Smaller than RGB, device-dependent (ISO standards)"
    use: ["Print", "Packaging", "Textiles", "Physical media"]

  HSL:
    description: "Hue-Saturation-Lightness, intuitive for humans"
    components:
      hue: "0-360 degrees (color wheel position)"
      saturation: "0-100% (color intensity vs gray)"
      lightness: "0-100% (0% black, 50% pure color, 100% white)"
    use: ["UI design", "Color pickers", "Theme generation"]

  LAB:
    description: "CIELAB, perceptually uniform color space"
    components:
      L: "0-100 (Lightness, 0 black, 100 white)"
      A: "-128 to +127 (Green to Red axis)"
      B: "-128 to +127 (Blue to Yellow axis)"
    use: ["Color difference calculation", "Color management", "Print proofing"]

  LCH:
    description: "Lightness-Chroma-Hue, polar form of LAB"
    components:
      L: "0-100 (Lightness)"
      C: "0-100+ (Chroma/saturation intensity)"
      H: "0-360 degrees (Hue angle)"
    use: ["Color palette generation", "Accessibility", "Perceptual color operations"]
```

### 1.2 Color Space Specifications

```yaml
color_spaces:
  sRGB:
    standard: "IEC 61966-2-1:1999"
    white_point: "D65 (0.3127, 0.3290)"
    gamma: "2.2 (approximate piecewise)"
    gamut_coverage: "~35% of visible spectrum"
    use: ["Web", "Standard monitors", "Consumer cameras", "Most digital content"]

  Display_P3:
    standard: "SMPTE EG 432-1"
    white_point: "D65"
    gamma: "2.2"
    gamut_coverage: "~53% of visible spectrum (25% larger than sRGB)"
    use: ["Apple devices", "Modern displays", "HDR content", "Cinema"]

  Adobe_RGB:
    standard: "Adobe Systems (1998)"
    white_point: "D65"
    gamma: "2.2"
    gamut_coverage: "~52% of visible spectrum"
    use: ["Professional photography", "Print preparation", "Wide-gamut monitors"]

  ProPhoto_RGB:
    standard: "Kodak (ROMM RGB)"
    white_point: "D50"
    gamma: "1.8 (with linear segment)"
    gamut_coverage: "~90% of visible spectrum (includes imaginary colors)"
    use: ["Professional photography", "Archival", "Color science"]

  Rec_2020:
    standard: "ITU-R BT.2020"
    white_point: "D65"
    gamma: "PQ (Perceptual Quantizer) or HLG"
    gamut_coverage: "~75% of visible spectrum"
    use: ["UHD TV", "HDR video", "Future displays"]

  CMYK_ISO_Coated:
    standard: "ISO 12647-2:2004, Condition 1 (Coated)"
    total_ink_coverage: "320%"
    use: ["Commercial offset printing", "Magazines", "Brochures"]

  CMYK_GRACoL:
    standard: "GRACoL 2006 #1 (SWOP)"
    total_ink_coverage: "300%"
    use: ["Sheet-fed offset", "High-quality print", "North America"]

  CMYK_FOGRA:
    standard: "FOGRA39 (ISO 12647-2:2004/Amd 1)"
    total_ink_coverage: "330%"
    use: ["European offset printing", "Commercial print"]
```

### 1.3 Color Conversion Mathematics

```
RGB to XYZ (sRGB):
  1. Inverse Gamma: C_linear = C_srgb <= 0.04045 ? C/12.92 : ((C+0.055)/1.055)^2.4
  2. Matrix: [X,Y,Z] = M * [R_linear, G_linear, B_linear]
     M = [[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]]

XYZ to LAB (D65 white point):
  1. Normalize by white point (D65: Xn=95.047, Yn=100.000, Zn=108.883)
  2. f(t) = t > 0.008856 ? t^(1/3) : 7.787 * t + 16/116
  3. L = 116 * f(yr) - 16
  4. a = 500 * (f(xr) - f(yr))
  5. b = 200 * (f(yr) - f(zr))

LAB to LCH:
  L = L (unchanged)
  C = sqrt(a^2 + b^2)
  H = atan2(b, a) * (180/pi)
  If H < 0: H += 360

Color Difference (Delta E):
  Delta E 1976: sqrt((L2-L1)^2 + (a2-a1)^2 + (b2-b1)^2)
  Delta E 2000: Most accurate, accounts for lightness/chroma/hue weighting
  Just Noticeable Difference (JND): Delta E ~ 1.0
```

---

## 2. COLOR HARMONY SYSTEMS

### 2.1 Traditional Harmonies

| Harmony | Formula | Effect | Use Case |
|---------|---------|--------|----------|
| Complementary | H2 = (H1 + 180) mod 360 | High contrast, vibrant, energetic | CTAs, Sports, Action |
| Split-Complementary | H2 = (H1 + 150), H3 = (H1 + 210) | High contrast, less tension | Marketing, Branding, Websites |
| Analogous | H2 = (H1 + 30), H3 = (H1 - 30) | Harmonious, natural, serene | Nature brands, Wellness, Backgrounds |
| Triadic | H2 = (H1 + 120), H3 = (H1 + 240) | Vibrant, balanced, playful | Children's products, Creative brands |
| Tetradic (Rectangle) | H2 = H1 + 60, H3 = H1 + 180, H4 = H1 + 240 | Rich, complex, balanced | Complex branding, Editorial |
| Monochromatic | Same H, vary L and S | Clean, elegant, cohesive | Minimalist design, Corporate |
| Accented Analogous | H1, H2=H1+30, H3=H1-30, H4=H1+180 | Harmony with accent pop | Websites, Apps, Branding with CTA |
| Diadic | H2 = (H1 + 60) mod 360 | Pleasant contrast, less tension | Friendly brands, Casual designs |

### 2.2 Advanced Harmonies

```yaml
advanced_harmonies:
  golden_angle:
    description: "Colors spaced by golden angle (137.5 degrees)"
    formula: "H_n = (H_0 + n * 137.5) mod 360"
    effect: "Naturally harmonious, organic distribution"
    use: ["Complex palettes", "Data visualization", "Generative art"]

  fibonacci:
    description: "Spacing based on Fibonacci sequence angles"
    effect: "Natural, organic, aesthetically pleasing"
    use: ["Nature-inspired design", "Organic brands", "Wellness"]

  temperature:
    description: "Balance warm and cool colors"
    warm_range: "0-60 degrees and 300-360 degrees"
    cool_range: "120-240 degrees"
    rule: "Every palette should have temperature balance"
    use: ["All design", "Emotional balance", "Visual interest"]

  value_harmony:
    description: "Colors with similar lightness values"
    rule: "L values within 10-15 points for harmonious feel"
    use: ["Backgrounds", "Subtle variations", "Monochromatic depth"]

  saturation_harmony:
    description: "Strategic saturation distribution"
    rules:
      - "One dominant saturated color"
      - "Secondary colors at 60-80% saturation"
      - "Accent at 100% saturation"
      - "Backgrounds at 5-20% saturation"
    use: ["Brand palettes", "UI design", "Visual hierarchy"]
```

---

## 3. COLOR PALETTE GENERATION

### 3.1 AI Palette Generation Algorithm

```python
def generate_palette(strategy, base_color, constraints=None):
    # Step 1: Convert base to LCH
    base_lch = rgb_to_lch(base_color)

    # Step 2: Determine harmony angles
    if strategy == "complementary":
        angles = [0, 180]
    elif strategy == "split_complementary":
        angles = [0, 150, 210]
    elif strategy == "analogous":
        angles = [-30, 0, 30]
    elif strategy == "triadic":
        angles = [0, 120, 240]
    elif strategy == "tetradic":
        angles = [0, 60, 180, 240]
    elif strategy == "monochromatic":
        angles = [0]
    elif strategy == "golden_angle":
        angles = [0, 137.5, 275, 52.5, 190]

    # Step 3: Generate hue variations
    hues = [(base_lch.H + angle) % 360 for angle in angles]

    # Step 4: Build palette with lightness/saturation rules
    palette = {}
    palette['primary'] = LCH(L=clamp(base_lch.L, 45, 65), C=clamp(base_lch.C, 40, 80), H=hues[0])
    if len(hues) > 1:
        palette['secondary'] = LCH(L=clamp(base_lch.L, 45, 65), C=clamp(base_lch.C * 0.8, 30, 60), H=hues[1])
    if len(hues) > 2:
        palette['accent'] = LCH(L=clamp(base_lch.L, 50, 70), C=clamp(base_lch.C * 1.2, 50, 90), H=hues[2])

    # Neutrals
    palette['neutral_100'] = LCH(L=98, C=2, H=hues[0])
    palette['neutral_200'] = LCH(L=90, C=3, H=hues[0])
    palette['neutral_300'] = LCH(L=70, C=4, H=hues[0])
    palette['neutral_400'] = LCH(L=50, C=5, H=hues[0])
    palette['neutral_500'] = LCH(L=30, C=6, H=hues[0])
    palette['neutral_600'] = LCH(L=15, C=4, H=hues[0])
    palette['neutral_700'] = LCH(L=5, C=2, H=hues[0])

    # Semantic colors
    palette['success'] = LCH(L=55, C=60, H=120)
    palette['warning'] = LCH(L=55, C=60, H=45)
    palette['error'] = LCH(L=55, C=60, H=0)
    palette['info'] = LCH(L=55, C=60, H=210)

    # Step 5: Accessibility check
    palette = ensure_accessibility(palette, constraints)

    return palette

def ensure_accessibility(palette, constraints):
    # Ensure primary on white meets 4.5:1
    while contrast_ratio(palette['primary'], palette['neutral_100']) < 4.5:
        palette['primary'].L = max(palette['primary'].L - 5, 20)
    return palette
```

### 3.2 Mood-Based Palettes

| Mood | Characteristics | Colors | Use Case |
|------|----------------|--------|----------|
| Energetic | High saturation, warm, high contrast | Red, Orange, Yellow, Bright Green | Sports, Fitness, Youth brands |
| Calm | Low saturation, cool, low contrast | Light Blue, Mint, Lavender, Soft Gray | Wellness, Spa, Meditation |
| Professional | Medium saturation, neutral with accent | Navy, Gray, White, Accent Blue | Corporate, Finance, B2B |
| Luxurious | Deep saturation, rich, gold accents | Deep Purple, Burgundy, Gold, Black | Fashion, Jewelry, Hotels |
| Playful | Bright, multiple hues, high saturation | Pink, Cyan, Lime, Yellow, Purple | Children's products, Toys, Games |
| Natural | Earth tones, organic, muted | Olive, Terracotta, Sage, Brown, Cream | Organic food, Eco brands, Outdoor |
| Modern | Monochrome, high contrast, minimal | Black, White, Gray, Single accent | Tech, Startups, Architecture |
| Vintage | Desaturated, warm, nostalgic | Mustard, Dusty Rose, Teal, Cream, Brown | Retro brands, Craft beer, Artisan |
| Futuristic | Neon accents, dark, cyan/magenta | Black, Cyan, Magenta, Electric Blue | Gaming, Sci-fi, Tech |
| Romantic | Soft pastels, pink tones, warm | Blush, Rose, Peach, Lavender, Cream | Weddings, Beauty, Romance |

---

## 4. COLOR IN UI DESIGN

### 4.1 UI Color System

```yaml
ui_color_system:
  background:
    primary: "Main page background"
    secondary: "Card, modal, elevated surface backgrounds"
    tertiary: "Input fields, subtle containers"
    inverse: "Dark backgrounds for light text"

  surface:
    elevated: "Cards, modals, popovers (higher elevation)"
    sunken: "Inset areas, scrollable regions"
    overlay: "Backdrops, scrims, loading overlays"

  text:
    primary: "Headings, body text (highest contrast)"
    secondary: "Subtitles, descriptions, metadata"
    tertiary: "Hints, disabled text, placeholders"
    inverse: "Text on dark/colored backgrounds"

  border:
    default: "Dividers, card borders, input borders"
    focus: "Focused element borders"
    error: "Invalid input borders"
    success: "Valid input borders"

  action:
    primary: "Main CTA, most important action"
    primary_hover: "Primary on hover"
    primary_active: "Primary on press/click"
    primary_disabled: "Primary when unavailable"
    secondary: "Secondary actions, alternative paths"
    tertiary: "Low emphasis actions, text buttons"
    ghost: "Transparent background, border only"
    danger: "Destructive actions (delete, remove)"

  feedback:
    success: "Positive outcomes, confirmations"
    warning: "Caution, attention needed"
    error: "Errors, failures, critical issues"
    info: "Neutral information, tips"

  accent:
    brand: "Brand color for emphasis"
    highlight: "Selection, search matches"
    decoration: "Decorative elements, illustrations"
```

### 4.2 Dark Mode Color Mapping

```yaml
dark_mode_mapping:
  background:
    light: "#FFFFFF"
    dark: "#0F0F0F"
  surface:
    light: "#F5F5F5"
    dark: "#1A1A1A"
  elevated:
    light: "#FFFFFF"
    dark: "#242424"
  text_primary:
    light: "#1A1A1A"
    dark: "#F5F5F5"
  text_secondary:
    light: "#6B6B6B"
    dark: "#A0A0A0"
  text_tertiary:
    light: "#9E9E9E"
    dark: "#6B6B6B"
  border:
    light: "#E0E0E0"
    dark: "#333333"
  rules:
    - "Dark backgrounds should be pure black or very dark gray (#0F0F0F - #1A1A1A)"
    - "Surfaces should be slightly lighter than background (#1A1A1A - #242424)"
    - "Text should be off-white (#F5F5F5) not pure white to reduce eye strain"
    - "Borders should be subtle (#333333) not pure white"
    - "Saturated colors should be slightly desaturated in dark mode"
    - "Elevation should use lighter surfaces, not shadows"
    - "Accent colors may need to be brighter in dark mode"
```

### 4.3 Color Token System (CSS)

```css
:root {
  /* Gray Scale (LCH-based, perceptually uniform) */
  --color-gray-50:  #FAFAFA;
  --color-gray-100: #F5F5F5;
  --color-gray-200: #E5E5E5;
  --color-gray-300: #D4D4D4;
  --color-gray-400: #A3A3A3;
  --color-gray-500: #737373;
  --color-gray-600: #525252;
  --color-gray-700: #404040;
  --color-gray-800: #262626;
  --color-gray-900: #171717;
  --color-gray-950: #0A0A0A;

  /* Semantic Colors (Light Mode) */
  --color-background-primary: var(--color-white);
  --color-background-secondary: var(--color-gray-100);
  --color-background-tertiary: var(--color-gray-200);
  --color-background-inverse: var(--color-gray-900);

  --color-surface-elevated: var(--color-white);
  --color-surface-sunken: var(--color-gray-100);
  --color-surface-overlay: rgba(0, 0, 0, 0.5);

  --color-text-primary: var(--color-gray-900);
  --color-text-secondary: var(--color-gray-500);
  --color-text-tertiary: var(--color-gray-400);
  --color-text-inverse: var(--color-white);
  --color-text-placeholder: var(--color-gray-400);

  --color-border-default: var(--color-gray-200);
  --color-border-focus: var(--color-primary-500);
  --color-border-error: var(--color-error-500);
  --color-border-success: var(--color-success-500);

  /* Brand Colors (Example: Blue) */
  --color-primary-50:  #EFF6FF;
  --color-primary-100: #DBEAFE;
  --color-primary-200: #BFDBFE;
  --color-primary-300: #93C5FD;
  --color-primary-400: #60A5FA;
  --color-primary-500: #3B82F6;
  --color-primary-600: #2563EB;
  --color-primary-700: #1D4ED8;
  --color-primary-800: #1E40AF;
  --color-primary-900: #1E3A8A;
  --color-primary-950: #172554;

  --color-action-primary: var(--color-primary-600);
  --color-action-primary-hover: var(--color-primary-700);
  --color-action-primary-active: var(--color-primary-800);
  --color-action-primary-disabled: var(--color-primary-300);

  --color-action-secondary: var(--color-gray-100);
  --color-action-secondary-hover: var(--color-gray-200);
  --color-action-secondary-active: var(--color-gray-300);
  --color-action-secondary-border: var(--color-gray-300);

  --color-action-ghost: transparent;
  --color-action-ghost-hover: var(--color-gray-100);
  --color-action-ghost-border: var(--color-gray-300);

  --color-action-danger: #DC2626;
  --color-action-danger-hover: #B91C1C;

  /* Feedback Colors */
  --color-success-50:  #F0FDF4;
  --color-success-100: #DCFCE7;
  --color-success-500: #22C55E;
  --color-success-600: #16A34A;
  --color-success-700: #15803D;

  --color-warning-50:  #FFFBEB;
  --color-warning-100: #FEF3C7;
  --color-warning-500: #F59E0B;
  --color-warning-600: #D97706;
  --color-warning-700: #B45309;

  --color-error-50:  #FEF2F2;
  --color-error-100: #FEE2E2;
  --color-error-500: #EF4444;
  --color-error-600: #DC2626;
  --color-error-700: #B91C1C;

  --color-info-50:  #EFF6FF;
  --color-info-100: #DBEAFE;
  --color-info-500: #3B82F6;
  --color-info-600: #2563EB;
  --color-info-700: #1D4ED8;

  /* Accent */
  --color-accent-brand: var(--color-primary-500);
  --color-accent-highlight: rgba(59, 130, 246, 0.2);
}

/* Dark Mode */
[data-theme="dark"] {
  --color-background-primary: var(--color-gray-950);
  --color-background-secondary: var(--color-gray-900);
  --color-background-tertiary: var(--color-gray-800);
  --color-background-inverse: var(--color-gray-100);

  --color-surface-elevated: var(--color-gray-800);
  --color-surface-sunken: var(--color-gray-900);
  --color-surface-overlay: rgba(0, 0, 0, 0.7);

  --color-text-primary: var(--color-gray-100);
  --color-text-secondary: var(--color-gray-400);
  --color-text-tertiary: var(--color-gray-500);
  --color-text-inverse: var(--color-gray-900);
  --color-text-placeholder: var(--color-gray-600);

  --color-border-default: var(--color-gray-800);
  --color-border-focus: var(--color-primary-400);

  --color-action-primary: var(--color-primary-500);
  --color-action-primary-hover: var(--color-primary-400);
  --color-action-primary-active: var(--color-primary-300);
  --color-action-primary-disabled: var(--color-primary-800);

  --color-action-secondary: var(--color-gray-800);
  --color-action-secondary-hover: var(--color-gray-700);
  --color-action-secondary-active: var(--color-gray-600);
  --color-action-secondary-border: var(--color-gray-700);

  --color-action-ghost-hover: var(--color-gray-800);
  --color-action-ghost-border: var(--color-gray-700);
}
```

---

## 5. ACCESSIBILITY & COLOR

### 5.1 WCAG Contrast Requirements

| Level | Text Type | Requirement |
|-------|-----------|-------------|
| AA Normal | Text < 18pt or bold < 14pt | 4.5:1 minimum |
| AA Large | Text >= 18pt or bold >= 14pt | 3:1 minimum |
| AAA Normal | Text < 18pt or bold < 14pt | 7:1 minimum |
| AAA Large | Text >= 18pt or bold >= 14pt | 4.5:1 minimum |
| UI Components | Visual boundaries | 3:1 minimum |
| Graphical Objects | Icons, charts, graphs | 3:1 minimum |
| Focus Indicators | Keyboard focus | 3:1 against adjacent colors |

### 5.2 Colorblind Accessibility

| Type | Affected | Confusion | Safe Pairs |
|------|----------|-----------|------------|
| Deuteranopia | Green cone (~5% males) | Red-Green | Blue-Yellow, Black-White |
| Protanopia | Red cone (~1% males) | Red-Green | Blue-Yellow, Black-White |
| Tritanopia | Blue cone (~0.01%) | Blue-Yellow | Red-Green, Black-White |
| Achromatopsia | All cones (very rare) | All colors | Black-White, Dark Gray-Light Gray |

**Design Guidelines:**
- Never rely on color alone to convey information
- Use patterns, labels, icons, or text in addition to color
- Ensure sufficient brightness contrast (not just hue contrast)
- Test designs with colorblind simulators
- Use colorblind-safe palettes (avoid red-green, blue-yellow combinations)
- Provide alternative text for color-coded information

**Colorblind-Safe Palettes:**
- **Viridis:** Purple, Blue, Green, Yellow (data visualization, heatmaps)
- **Plasma:** Dark Purple, Magenta, Orange, Yellow (data visualization)
- **Cividis:** Dark Blue, Blue-Green, Yellow-Green, Yellow (data visualization, optimized)
- **Tol:** Purple, Blue, Green, Yellow, Red (categorical data, maps)
- **Okabe-Ito:** Orange, Sky Blue, Bluish Green, Yellow, Blue, Vermillion, Reddish Purple (categorical, scientific)

### 5.3 Contrast Calculation

```python
def relative_luminance(rgb):
    def channel(c):
        c = c / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = rgb
    return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)

def contrast_ratio(color1, color2):
    l1 = relative_luminance(color1)
    l2 = relative_luminance(color2)
    lighter = max(l1, l2)
    darker = min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)

def find_accessible_color(background, target_hue, min_contrast=4.5):
    best_color = None
    best_contrast = 0
    for l in range(5, 100, 2):
        for c in range(0, 100, 5):
            color = lch_to_rgb(LCH(l, c, target_hue))
            ratio = contrast_ratio(background, color)
            if ratio >= min_contrast and ratio > best_contrast:
                best_contrast = ratio
                best_color = color
    return best_color, best_contrast
```

---

## 6. COLOR GRADING

### 6.1 Color Grading Techniques

| Technique | Description | Use Case |
|-----------|-------------|----------|
| Curves | Adjust tonal range with curves | General contrast, color balance |
| Color Wheels | Shadows/midtones/highlights color balance | Cinematic color casts |
| HSL Selective | Adjust specific hue ranges | Targeted color correction |
| Split Toning | Different colors for shadows and highlights | Cinematic looks |
| LUT | Lookup Table for color transformation | Consistent looks, film emulation |
| Film Emulation | Emulate specific film stocks | Vintage, nostalgic looks |
| Channel Mixer | Mix RGB channels | B&W conversion, color channel swapping |

### 6.2 Cinematic Looks

| Look | Description | Colors | Use Case |
|------|-------------|--------|----------|
| Teal and Orange | Shadows toward teal, highlights toward orange | Shadows: Cyan, Highlights: Orange | Blockbuster, action, modern cinema |
| Bleach Bypass | High contrast, desaturated, silver retention | Contrast: +30, Saturation: -30 | War films, gritty, dramatic |
| Day for Night | Convert daylight to night look | Shadows: Blue, Contrast: +20, Saturation: -20 | Budget filmmaking, VFX |
| Vintage Film | Warm tones, faded blacks, film grain | Lift blacks: +15, Warm highlights | Nostalgic, romantic, lifestyle |
| High Key | Bright, low contrast, minimal shadows | Exposure: +1, Contrast: -15 | Beauty, fashion, clean aesthetic |
| Low Key | Dark, high contrast, dramatic shadows | Crush shadows, Boost contrast | Drama, horror, noir |
| Cross Processing | Process in wrong chemistry for color shift | Shadows: Green, Highlights: Magenta | Experimental, editorial, artistic |
| Monochrome | Black and white with tonal control | B&W conversion, Channel mixer | Timeless, dramatic, documentary |
| Cyberpunk | Neon accents on dark, cyan and magenta | Shadows: Near-black, Highlights: Cyan/Magenta | Sci-fi, tech, futuristic |
| Warm Earth | Warm browns, oranges, soft greens | Shadows: Warm brown, Midtones: Orange | Nature, organic, autumn |

---

## 7. COLOR IN PRINT

### 7.1 CMYK Color Management

```yaml
cmyk_color_management:
  color_separation:
    rgb_to_cmyk:
      - "Convert RGB to LAB (device-independent)"
      - "Convert LAB to CMYK using ICC profile"
      - "Apply GCR (Gray Component Replacement) or UCR (Under Color Removal)"
      - "Check total ink coverage (TIC)"

    gcr:
      description: "Replace CMY with K in neutral areas"
      advantage: "Better gray balance, less ink"
      disadvantage: "Slightly duller colors"
      use: "General print, cost savings"

    ucr:
      description: "Remove CMY from shadows, add K"
      advantage: "Deeper blacks, better shadow detail"
      disadvantage: "Can cause color shift in shadows"
      use: "High-quality print, photography"

  total_ink_coverage:
    coated_paper: "320% maximum"
    uncoated_paper: "260% maximum"
    newsprint: "240% maximum"

  rich_black:
    formula: "C60 M40 Y40 K100"
    use: "Large solid areas, backgrounds"
    warning: "Never use for small text (registration issues)"

  registration_black:
    formula: "C100 M100 Y100 K100"
    use: "Trims, crop marks, registration marks only"
    warning: "Too much ink for large areas"

  pure_black_text:
    formula: "C0 M0 Y0 K100"
    use: "All text under 12pt"
    reason: "Sharper text, no registration issues"
```

### 7.2 Spot Colors

```yaml
spot_colors:
  pantone:
    description: "Pantone Matching System (PMS)"
    use: "Brand consistency across print jobs"
    cost: "Additional plate per spot color"
    specification: "Pantone Formula Guide (Coated/Uncoated)"

  metallic:
    types: ["Gold", "Silver", "Copper", "Holographic"]
    use: "Luxury packaging, certificates, invitations"

  fluorescent:
    types: ["Orange", "Green", "Pink", "Yellow"]
    use: "Safety, attention, packaging"

  white:
    use: "Printing on dark/colored substrates"
    types: ["Opaque white", "White underprint"]

  varnish:
    types: ["Gloss", "Matte", "Satin", "Soft-touch", "UV"]
    use: "Protection, texture, visual enhancement"
    application: ["Spot varnish (selective)", "Flood varnish (all over)"]
```

---

## 8. COLOR EXTRACTION & ANALYSIS

### 8.1 Dominant Color Extraction

```python
from sklearn.cluster import KMeans
import numpy as np

def extract_dominant_colors(image, n_colors=5, exclude_background=True):
    pixels = image.reshape(-1, 3)
    pixels_lab = rgb_to_lab(pixels)

    if exclude_background:
        chroma = np.sqrt(pixels_lab[:, 1]**2 + pixels_lab[:, 2]**2)
        mask = (chroma > 10) & (pixels_lab[:, 0] > 15) & (pixels_lab[:, 0] < 95)
        pixels_lab = pixels_lab[mask]

    kmeans = KMeans(n_clusters=n_colors, random_state=42, n_init=10)
    kmeans.fit(pixels_lab)

    centers_lab = kmeans.cluster_centers_
    labels = kmeans.labels_
    counts = np.bincount(labels)
    percentages = counts / len(labels) * 100

    colors_rgb = lab_to_rgb(centers_lab)
    sorted_indices = np.argsort(percentages)[::-1]

    return [
        {
            'color': colors_rgb[i],
            'percentage': percentages[i],
            'lab': centers_lab[i]
        }
        for i in sorted_indices
    ]

def extract_color_palette(image, mood=None, n_colors=5):
    dominant = extract_dominant_colors(image, n_colors)
    base_color = dominant[0]['color']

    if mood:
        strategy = mood_to_harmony(mood)
    else:
        strategy = auto_detect_harmony(dominant)

    palette = generate_palette(strategy, base_color)
    palette['extracted'] = [d['color'] for d in dominant]

    return palette
```

### 8.2 Color Analysis Metrics

| Metric | Description | Values |
|--------|-------------|--------|
| Temperature | Warm vs Cool | Warm: Red/Orange/Yellow dominant, Cool: Blue/Green/Purple dominant |
| Saturation | Color intensity | Vivid: >70%, Muted: 30-70%, Desaturated: <30% |
| Contrast | Light-dark difference | High: Large difference, Medium: Moderate, Low: Small difference |
| Harmony | Color relationships | Complementary, Analogous, Monochromatic, Complex |
| Mood | Emotional association | Warm+Vivid: Energetic, Cool+Muted: Calm, High Contrast: Dramatic |

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: Color Handbook*
