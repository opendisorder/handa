# AURA Animation & Motion Design Guide
## Complete Motion Design Reference v1.0

---

## 1. ANIMATION PRINCIPLES

### 1.1 The 12 Principles of Animation (Disney)

```yaml
animation_principles:
  squash_and_stretch:
    description: "Give weight and flexibility to objects"
    application: "Objects deform on impact or during acceleration"
    example: "Ball squashing on ground, stretching during bounce"
    technique: "Maintain volume while changing shape"
    use: "UI elements bouncing, buttons pressing, cards expanding"

  anticipation:
    description: "Prepare audience for action before it happens"
    application: "Wind-up before main action"
    example: "Character crouching before jump, button pulsing before click"
    technique: "Small movement opposite to main action direction"
    use: "Loading indicators, transitions, micro-interactions"

  staging:
    description: "Present idea clearly with camera angle, lighting, composition"
    application: "Direct attention to important elements"
    example: "Spotlight on main character, blur background"
    technique: "Simplify, focus, remove distractions"
    use: "Onboarding flows, feature highlights, empty states"

  straight_ahead_and_pose_to_pose:
    description: "Two approaches to animation timing"
    straight_ahead: "Frame by frame from start to end, spontaneous"
    pose_to_pose: "Key poses first, then fill in between"
    use: "Pose-to-pose for UI animations (predictable), straight-ahead for organic effects"

  follow_through_and_overlapping_action:
    description: "Parts of body continue moving after main action stops"
    application: "Hair, clothes, tails continue moving after character stops"
    example: "Scroll momentum, list items settling after scroll"
    technique: "Secondary animation with delayed timing"
    use: "Scroll physics, parallax, staggered list animations"

  slow_in_and_slow_out:
    description: "More frames at beginning and end of action"
    application: "Objects accelerate and decelerate, not instant speed"
    example: "Car accelerating from stop, easing curves"
    technique: "Easing functions: ease-in, ease-out, ease-in-out"
    use: "All UI transitions, modal animations, page transitions"

  arc:
    description: "Natural movements follow curved paths, not straight lines"
    application: "Arms swinging, ball thrown, head turning"
    example: "Swipe gesture following arc, menu items fanning out"
    technique: "Bezier curves for motion paths"
    use: "Gesture animations, radial menus, carousel transitions"

  secondary_action:
    description: "Supporting actions that reinforce main action"
    application: "Facial expressions while walking, hair bouncing while running"
    example: "Button press + ripple effect, card hover + shadow change"
    technique: "Subtle, doesn't distract from main action"
    use: "Hover states, focus states, loading states"

  timing:
    description: "Number of frames determines speed and weight"
    application: "More frames = slower, heavier; fewer frames = faster, lighter"
    example: "Heavy object falls slower than light object"
    technique: "Frame count and spacing between frames"
    use: "Animation duration, stagger delays, physics simulations"

  exaggeration:
    description: "Push reality for more impact and clarity"
    application: "Stretch squash more than real physics, bigger reactions"
    example: "Overshoot on bounce, exaggerated feedback on error"
    technique: "Amplify but keep believable"
    use: "Error states, success states, playful interfaces"

  solid_drawing:
    description: "Understand 3D form, weight, volume, anatomy"
    application: "Consistent perspective, proportion, lighting"
    example: "Consistent shadows, proper perspective in UI"
    technique: "Apply real-world physics to digital objects"
    use: "3D transforms, depth, shadows, lighting in UI"

  appeal:
    description: "Make characters/designs interesting and engaging"
    application: "Personality, charm, charisma"
    example: "Friendly mascot, delightful micro-interactions"
    technique: "Add personality, surprise, delight"
    use: "Brand animations, loading states, onboarding"
```

### 1.2 UI Animation Principles

```yaml
ui_animation_principles:
  purposeful:
    description: "Every animation must serve a purpose"
    purposes:
      - "Orientation: Show where elements came from or went"
      - "Feedback: Confirm user action was received"
      - "Guidance: Direct attention to next step"
      - "Delight: Create emotional connection"
      - "Branding: Reinforce brand personality"
    rule: "If removing animation doesn't hurt UX, remove it"

  subtle:
    description: "Animations should be noticed but not distracting"
    duration: "200-500ms for most UI animations"
    easing: "Subtle ease-in-out, not bouncy or exaggerated"
    rule: "Animation should feel natural, not performative"

  consistent:
    description: "Use consistent animation language throughout"
    timing: "Same durations for same types of actions"
    easing: "Same easing curves for same types of transitions"
    direction: "Consistent spatial logic (e.g., left = back, right = forward)"

  performant:
    description: "Animations must run at 60fps"
    properties: "Animate only transform and opacity (GPU-accelerated)"
    avoid: "Animating width, height, top, left, margin, padding"
    technique: "Use will-change sparingly, remove after animation"

  accessible:
    description: "Respect user preferences and needs"
    reduced_motion: "Support prefers-reduced-motion media query"
    duration: "Slower for cognitive accessibility (optional)"
    focus: "Ensure focus states are visible during animations"

  responsive:
    description: "Animations must feel immediate"
    threshold: "100ms feels instant, 200ms feels responsive, >500ms feels slow"
    feedback: "Immediate visual feedback on interaction (<100ms)"
    completion: "Full animation can take longer but feedback must be instant"
```

---

## 2. ANIMATION TIMING

### 2.1 Duration Guidelines

```yaml
animation_durations:
  micro_interactions:
    button_press: "100ms"
    toggle_switch: "150ms"
    checkbox_check: "150ms"
    radio_select: "150ms"
    hover_state: "150ms"
    focus_state: "100ms"
    ripple_effect: "400ms"
    tooltip_show: "150ms"
    tooltip_hide: "75ms"

  transitions:
    page_transition: "300-500ms"
    modal_open: "300ms"
    modal_close: "200ms"
    sidebar_open: "300ms"
    sidebar_close: "200ms"
    dropdown_open: "200ms"
    dropdown_close: "150ms"
    tab_switch: "200ms"
    card_expand: "300ms"
    card_collapse: "200ms"

  loading:
    skeleton_screen: "300ms fade-in"
    spinner_rotation: "1000ms per rotation"
    progress_bar: "300ms per segment"
    shimmer_effect: "1500ms"
    pulsing_dot: "1200ms"

  scroll:
    smooth_scroll: "500ms"
    parallax: "Continuous, tied to scroll position"
    scroll_snap: "300ms"
    infinite_scroll: "300ms fade-in for new items"

  notifications:
    toast_appear: "300ms"
    toast_dismiss: "200ms"
    banner_slide: "400ms"
    alert_pulse: "2000ms cycle"

  gestures:
    swipe_response: "0ms (immediate)"
    swipe_release: "300ms spring"
    drag_feedback: "0ms (immediate)"
    drop_settle: "200ms"
    pinch_zoom: "0ms (immediate)"
    pinch_release: "300ms"

  complex:
    onboarding_sequence: "3000-5000ms total"
    hero_animation: "5000-10000ms"
    data_visualization: "1000-2000ms"
    illustration_animation: "3000-5000ms"
    brand_loader: "2000-3000ms"
```

### 2.2 Easing Functions

```yaml
easing_functions:
  standard:
    name: "Standard Easing"
    css: "cubic-bezier(0.4, 0.0, 0.2, 1)"
    use: "Most UI transitions, general purpose"
    characteristic: "Gentle acceleration and deceleration"

  decelerate:
    name: "Decelerate (Ease-Out)"
    css: "cubic-bezier(0.0, 0.0, 0.2, 1)"
    use: "Elements entering screen, expanding, appearing"
    characteristic: "Fast start, gentle stop"

  accelerate:
    name: "Accelerate (Ease-In)"
    css: "cubic-bezier(0.4, 0.0, 1, 1)"
    use: "Elements leaving screen, collapsing, disappearing"
    characteristic: "Gentle start, fast exit"

  sharp:
    name: "Sharp"
    css: "cubic-bezier(0.4, 0.0, 0.6, 1)"
    use: "Quick feedback, temporary states"
    characteristic: "Quick transition, slight overshoot"

  spring:
    name: "Spring"
    css: "cubic-bezier(0.34, 1.56, 0.64, 1)"
    use: "Playful interactions, bouncy elements"
    characteristic: "Overshoot and settle"

  bounce:
    name: "Bounce"
    css: "cubic-bezier(0.68, -0.55, 0.265, 1.55)"
    use: "Attention-grabbing, celebratory"
    characteristic: "Back-and-forth bounce"

  linear:
    name: "Linear"
    css: "linear"
    use: "Continuous animations, color transitions, rotation"
    characteristic: "Constant speed"

  step:
    name: "Step"
    css: "steps(n)"
    use: "Sprite animations, discrete state changes"
    characteristic: "Instant jumps between states"

  custom:
    name: "Custom"
    technique: "Define cubic-bezier(x1, y1, x2, y2)"
    tool: "https://cubic-bezier.com/"
    rule: "Keep values between 0 and 1 for predictable results (except overshoot)"
```

### 2.3 Easing Selection Guide

| Animation Type | Entering | Leaving | Continuous |
|---------------|----------|---------|------------|
| Fade | Decelerate | Accelerate | Linear |
| Scale (grow) | Decelerate | Accelerate | - |
| Scale (shrink) | Decelerate | Accelerate | - |
| Slide (in) | Decelerate | Accelerate | - |
| Slide (out) | - | Accelerate | - |
| Rotate | Linear | Linear | Linear |
| Color | Linear | Linear | Linear |
| Position | Decelerate | Accelerate | - |
| Bounce | Spring | - | - |
| Elastic | Spring | - | - |
| Shake | Bounce | - | - |
| Pulse | Spring | - | - |
| Parallax | - | - | Linear |
| Scroll | - | - | Linear |
| Stagger | Decelerate | - | - |

---

## 3. MOTION PATTERNS

### 3.1 Entrance Animations

```yaml
entrance_animations:
  fade_in:
    description: "Opacity 0 to 1"
    duration: "200-300ms"
    easing: "Decelerate"
    use: "Subtle appearance, loading content, modals"

  slide_in:
    description: "Translate from off-screen to position"
    directions: ["left", "right", "top", "bottom"]
    distance: "20-50px (subtle), 100% (full screen)"
    duration: "300-500ms"
    easing: "Decelerate"
    use: "Sidebars, drawers, cards, lists"

  scale_in:
    description: "Scale from 0.8-0.9 to 1.0"
    duration: "200-300ms"
    easing: "Spring or Decelerate"
    use: "Modals, dialogs, popovers, tooltips"

  grow_in:
    description: "Scale from 0 to 1 with origin point"
    origin: "Click point or center"
    duration: "300-400ms"
    easing: "Decelerate"
    use: "Material Design ripple, FAB expansion, menu items"

  flip_in:
    description: "Rotate from 90deg to 0deg"
    axis: "X or Y"
    duration: "300-400ms"
    easing: "Decelerate"
    use: "Cards, settings panels, content reveal"

  unfold_in:
    description: "Scale Y from 0 to 1 with origin top"
    duration: "300-400ms"
    easing: "Decelerate"
    use: "Dropdowns, accordions, expanding sections"

  stagger_in:
    description: "Multiple items entering with delay"
    delay: "50-100ms between items"
    duration: "200-300ms per item"
    easing: "Decelerate"
    use: "Lists, grids, cards, menu items"

  blur_in:
    description: "Filter blur from 10px to 0"
    duration: "300-400ms"
    easing: "Decelerate"
    use: "Focus transitions, background reveals"

  clip_in:
    description: "Clip-path reveal from center or edge"
    duration: "400-600ms"
    easing: "Decelerate"
    use: "Hero images, dramatic reveals, onboarding"

  mask_in:
    description: "Reveal through animated mask"
    duration: "500-800ms"
    easing: "Decelerate"
    use: "Brand animations, storytelling, illustrations"
```

### 3.2 Exit Animations

```yaml
exit_animations:
  fade_out:
    description: "Opacity 1 to 0"
    duration: "150-200ms"
    easing: "Accelerate"
    use: "Subtle disappearance, closing modals, removing items"

  slide_out:
    description: "Translate to off-screen"
    duration: "200-300ms"
    easing: "Accelerate"
    use: "Sidebars, drawers, dismissible items"

  scale_out:
    description: "Scale from 1.0 to 0.8-0.9"
    duration: "150-200ms"
    easing: "Accelerate"
    use: "Closing modals, dismissing popovers"

  shrink_out:
    description: "Scale to 0 with origin point"
    duration: "200-300ms"
    easing: "Accelerate"
    use: "Material Design ripple reverse, menu close"

  fold_out:
    description: "Scale Y from 1 to 0 with origin top"
    duration: "200-300ms"
    easing: "Accelerate"
    use: "Dropdowns, accordions, collapsing sections"

  stagger_out:
    description: "Multiple items leaving with delay"
    delay: "30-50ms between items"
    duration: "150-200ms per item"
    easing: "Accelerate"
    use: "Lists, grids, removing multiple items"

  collapse_out:
    description: "Height from auto to 0"
    duration: "200-300ms"
    easing: "Accelerate"
    use: "Accordions, removing list items, collapsing panels"
```

### 3.3 State Change Animations

```yaml
state_change_animations:
  hover:
    description: "Element response to mouse hover"
    scale: "1.02-1.05"
    shadow: "Increase elevation"
    color: "Lighten or darken 5-10%"
    duration: "150-200ms"
    easing: "Standard"

  active:
    description: "Element response to click/press"
    scale: "0.95-0.98"
    shadow: "Decrease elevation"
    duration: "100ms"
    easing: "Standard"

  focus:
    description: "Element response to keyboard focus"
    outline: "2px solid brand color"
    offset: "2-4px"
    shadow: "Glow effect"
    duration: "100ms"
    easing: "Standard"

  disabled:
    description: "Element in disabled state"
    opacity: "0.4-0.6"
    cursor: "not-allowed"
    duration: "150ms"
    easing: "Standard"

  loading:
    description: "Element in loading state"
    spinner: "Rotate 360deg, 1s per rotation"
    skeleton: "Shimmer animation, 1.5s cycle"
    pulse: "Opacity 0.5 to 1, 1.2s cycle"
    duration: "Continuous"

  success:
    description: "Element in success state"
    checkmark: "Scale in + draw stroke, 300ms"
    color: "Transition to green"
    duration: "300-400ms"
    easing: "Spring"

  error:
    description: "Element in error state"
    shake: "Translate X +/- 5px, 3 cycles, 300ms"
    color: "Transition to red"
    duration: "300-400ms"
    easing: "Standard"

  selected:
    description: "Element in selected state"
    scale: "1.02"
    border: "2px solid brand color"
    shadow: "Increase elevation"
    duration: "200ms"
    easing: "Standard"
```

### 3.4 Transition Patterns

```yaml
transition_patterns:
  shared_element:
    description: "Element transforms from one state to another across views"
    technique: "FLIP (First, Last, Invert, Play)"
    duration: "300-500ms"
    easing: "Standard"
    use: "Card to detail, list to grid, image zoom"

  container_transform:
    description: "Container expands to reveal new content"
    technique: "Scale and clip container, fade content"
    duration: "300-400ms"
    easing: "Decelerate"
    use: "FAB to form, chip to card, button to dialog"

  fade_through:
    description: "Current view fades out, new view fades in"
    technique: "Cross-fade with slight scale"
    duration: "300ms"
    easing: "Standard"
    use: "Tab switches, bottom navigation, settings pages"

  slide_through:
    description: "Views slide horizontally"
    technique: "Current slides out, new slides in"
    duration: "300-400ms"
    easing: "Decelerate (in), Accelerate (out)"
    use: "Wizards, onboarding, page navigation"

  elevation_change:
    description: "Element changes elevation (z-depth)"
    technique: "Shadow grows, scale slightly increases"
    duration: "200ms"
    easing: "Standard"
    use: "Card hover, drag and drop, focus states"

  parallax:
    description: "Elements move at different speeds"
    technique: "Translate Y at different rates based on scroll"
    ratio: "0.2x to 0.8x scroll speed"
    use: "Hero images, backgrounds, depth effects"

  morph:
    description: "One shape transforms into another"
    technique: "SVG path animation or CSS clip-path"
    duration: "400-600ms"
    easing: "Standard"
    use: "Play to pause, hamburger to close, icon transitions"

  page_transition:
    description: "Full page transition"
    types:
      - "Slide: Horizontal slide, 400ms"
      - "Fade: Cross-fade, 300ms"
      - "Scale: Scale out current, scale in new, 400ms"
      - "Flip: 3D rotation, 500ms"
      - "Cube: 3D cube rotation, 600ms"
      - "Cover: New page covers current, 400ms"
      - "Reveal: Current page reveals new, 400ms"
```

---

## 4. MICRO-INTERACTIONS

### 4.1 Button Interactions

```yaml
button_micro_interactions:
  hover:
    scale: "1.02"
    shadow: "Elevate 1 level"
    background: "Lighten 5%"
    duration: "150ms"
    easing: "Standard"

  active:
    scale: "0.97"
    shadow: "Reduce 1 level"
    duration: "100ms"
    easing: "Standard"

  loading:
    text: "Fade out, replace with spinner"
    spinner: "Rotate, 1s per rotation"
    disabled: "Prevent clicks"
    duration: "200ms"
    easing: "Standard"

  success:
    text: "Fade out"
    icon: "Checkmark scales in, 300ms"
    color: "Transition to green"
    duration: "400ms"
    easing: "Spring"

  error:
    shake: "Translate X +/- 5px, 3 cycles, 300ms"
    color: "Flash red, return to normal"
    duration: "400ms"
    easing: "Standard"

  ripple:
    trigger: "Click point"
    spread: "To element bounds"
    opacity: "0.3 to 0"
    duration: "400ms"
    easing: "Decelerate"
    color: "White or black based on background luminance"
```

### 4.2 Form Interactions

```yaml
form_micro_interactions:
  input_focus:
    border: "Transition to brand color, 2px"
    label: "Float up and shrink, 200ms"
    shadow: "Subtle glow, 150ms"
    duration: "200ms"
    easing: "Standard"

  input_typing:
    cursor: "Blink, 1s cycle"
    validation: "Real-time check with debounce 300ms"

  input_valid:
    border: "Transition to green"
    icon: "Checkmark fades in, 200ms"
    duration: "200ms"
    easing: "Standard"

  input_invalid:
    border: "Transition to red"
    shake: "Subtle shake, 200ms"
    message: "Error message slides down, 200ms"
    duration: "200ms"
    easing: "Standard"

  checkbox:
    check: "Scale from 0 to 1, 150ms, spring"
    border: "Transition to brand color"
    duration: "150ms"
    easing: "Spring"

  radio:
    select: "Dot scales in from center, 150ms"
    deselect: "Previous dot scales out, 100ms"
    duration: "150ms"
    easing: "Spring"

  toggle:
    switch: "Translate X, 200ms, spring"
    color: "Background transitions, 200ms"
    duration: "200ms"
    easing: "Spring"

  slider:
    thumb: "Follows drag, immediate"
    track: "Fill follows thumb, immediate"
    release: "Snap to nearest step, 100ms"

  dropdown:
    open: "Scale Y from 0 to 1, origin top, 200ms"
    items: "Stagger in, 30ms delay each"
    close: "Scale Y to 0, 150ms"
    duration: "200ms"
    easing: "Decelerate (open), Accelerate (close)"

  autocomplete:
    suggestions: "Fade in, 150ms"
    highlight: "Background highlight, 100ms"
    selection: "Fill input, close suggestions, 200ms"
```

### 4.3 Scroll Interactions

```yaml
scroll_micro_interactions:
  pull_to_refresh:
    threshold: "80px pull"
    indicator: "Rotate spinner, scale with pull distance"
    release: "Spinner accelerates, content slides down, 300ms"
    success: "Checkmark, content slides up, 200ms"

  infinite_scroll:
    trigger: "200px from bottom"
    loading: "Spinner fades in, 200ms"
    new_items: "Stagger in, 50ms delay, 200ms duration"

  scroll_snap:
    trigger: "Scroll end"
    snap: "Nearest item, 300ms, decelerate"

  scroll_progress:
    indicator: "Scale X or translate X based on scroll position"
    update: "Immediate (tied to scroll)"

  scroll_reveal:
    trigger: "Element enters viewport (Intersection Observer)"
    animation: "Fade up, 20px translate, 300ms, decelerate"
    threshold: "10% visible"

  scroll_hide:
    trigger: "Scroll down > 100px"
    element: "Header/toolbar"
    animation: "Translate Y to -100%, 200ms, accelerate"
    reverse: "Translate Y to 0, 200ms, decelerate"

  scroll_parallax:
    element: "Background or decorative elements"
    speed: "0.2x to 0.5x scroll speed"
    technique: "Translate Y based on scroll position"

  scroll_header_shrink:
    trigger: "Scroll down"
    animation: "Scale and translate header, 200ms"
    reverse: "Restore on scroll up, 200ms"
```

---

## 5. COMPLEX ANIMATIONS

### 5.1 Loading Animations

```yaml
loading_animations:
  skeleton_screens:
    description: "Placeholder content that mimics final layout"
    elements: "Gray blocks matching content structure"
    animation: "Shimmer - gradient sweep left to right, 1.5s"
    duration: "Until content loads"
    best_for: "Content-heavy pages, slow connections"

  spinners:
    description: "Rotating indicator"
    types:
      - "Circular: SVG stroke-dasharray animation, 1s"
      - "Dots: 3 dots scaling/pulsing, 1.2s"
      - "Bars: Vertical bars scaling, 1s"
      - "Pulse: Circle pulsing, 1.5s"
    size: "24px (inline), 48px (page), 96px (fullscreen)"
    color: "Brand color or neutral gray"

  progress_indicators:
    description: "Show completion percentage"
    types:
      - "Linear: Horizontal bar, fill width, 0-100%"
      - "Circular: SVG circle, stroke-dashoffset, 0-100%"
      - "Stepped: Segments filling, discrete steps"
      - "Indeterminate: Animated bar when progress unknown"
    animation: "Smooth width/offset transition, 100ms"

  brand_loaders:
    description: "Branded loading animation"
    elements: "Logo animation, mascot, brand colors"
    duration: "2-3s max before showing content"
    use: "Initial app load, major transitions"

  content_placeholders:
    description: "Animated placeholder matching content type"
    image: "Gray box with image icon"
    text: "Gray lines matching text block"
    card: "Gray card shape"
    avatar: "Gray circle"
```

### 5.2 Onboarding Animations

```yaml
onboarding_animations:
  walkthrough:
    description: "Step-by-step feature introduction"
    technique: "Spotlight + tooltip sequence"
    spotlight: "Dim background, highlight feature, 300ms"
    tooltip: "Slide in from direction, 300ms, decelerate"
    transition: "Between steps, 400ms"

  coach_marks:
    description: "Overlay pointers to key features"
    technique: "Pulsing circles or arrows pointing to elements"
    pulse: "Scale 1 to 1.2, opacity 1 to 0.5, 1.5s cycle"
    dismiss: "Tap to dismiss, fade out, 200ms"

  interactive_demo:
    description: "Simulated interaction demonstrating feature"
    technique: "Animated cursor performing actions"
    cursor: "Move to target, 500ms, decelerate"
    action: "Simulate click, ripple, 200ms"
    result: "Show outcome, 300ms"

  story_sequence:
    description: "Narrative animation telling brand story"
    technique: "Illustration animation with scroll trigger"
    trigger: "Scroll position or auto-play"
    scenes: "3-5 scenes, 3-5s each"
    transitions: "Cross-fade or slide, 500ms"
```

### 5.3 Data Visualization Animations

```yaml
data_viz_animations:
  chart_entrance:
    description: "Charts animating on load"
    bar_chart: "Bars grow from bottom, stagger 50ms, 400ms, decelerate"
    line_chart: "Line draws from left, 1000ms, linear"
    pie_chart: "Segments rotate in from 0, 600ms, decelerate"
    donut_chart: "Stroke-dashoffset animation, 800ms"
    scatter_plot: "Points fade in with scale, stagger 20ms, 200ms"

  data_update:
    description: "Charts updating with new data"
    bar_growth: "Height transition, 400ms, standard"
    line_morph: "Path morphing, 600ms, standard"
    point_move: "Translate to new position, 400ms, spring"
    color_transition: "Color change, 300ms, linear"

  tooltip_appear:
    description: "Tooltip on hover"
    animation: "Scale from 0.9 to 1, fade in, 150ms, decelerate"
    follow: "Follow cursor with slight lag, 50ms"

  axis_transition:
    description: "Axis scale changes"
    animation: "Labels fade and reposition, 400ms, standard"

  real_time:
    description: "Live data updates"
    animation: "New data point enters, old points shift, 300ms"
    buffer: "Smooth transition, not jarring"
```

### 5.4 Illustration Animations

```yaml
illustration_animations:
  character:
    description: "Animated character or mascot"
    idle: "Subtle breathing, blinking, 3-5s cycle"
    reaction: "Expression change, 200ms"
    action: "Full body animation, 500-1000ms"
    loop: "Continuous idle animation"

  icon:
    description: "Animated icon or illustration"
    morph: "SVG path morphing between states, 300ms"
    draw: "Stroke-dashoffset draw-on effect, 500ms"
    bounce: "Scale spring on appearance, 300ms"
    wiggle: "Rotation oscillation, 200ms"

  background:
    description: "Animated background elements"
    parallax: "Multiple layers at different speeds"
    particles: "Floating shapes, continuous, subtle"
    gradient: "Color shift, 10-20s cycle"
    pattern: "Subtle movement, 30-60s cycle"

  decorative:
    description: "Decorative animation elements"
    confetti: "Particle burst on success, 2-3s"
    sparkle: "Star twinkle, 1-2s cycle"
    wave: "Sine wave motion, continuous"
    float: "Gentle up-down, 3-5s cycle"
```

---

## 6. MOTION SYSTEM SPECIFICATION

### 6.1 CSS Animation System

```css
/* Base Animation System */

/* Duration Tokens */
:root {
  --duration-instant: 0ms;
  --duration-fast: 100ms;
  --duration-normal: 200ms;
  --duration-slow: 300ms;
  --duration-slower: 400ms;
  --duration-slowest: 500ms;
}

/* Easing Tokens */
:root {
  --ease-linear: linear;
  --ease-standard: cubic-bezier(0.4, 0.0, 0.2, 1);
  --ease-decelerate: cubic-bezier(0.0, 0.0, 0.2, 1);
  --ease-accelerate: cubic-bezier(0.4, 0.0, 1, 1);
  --ease-sharp: cubic-bezier(0.4, 0.0, 0.6, 1);
  --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
  --ease-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

/* Animation Classes */
.animate-fade-in {
  animation: fadeIn var(--duration-slow) var(--ease-decelerate) forwards;
}

.animate-fade-out {
  animation: fadeOut var(--duration-normal) var(--ease-accelerate) forwards;
}

.animate-slide-in-left {
  animation: slideInLeft var(--duration-slow) var(--ease-decelerate) forwards;
}

.animate-slide-in-right {
  animation: slideInRight var(--duration-slow) var(--ease-decelerate) forwards;
}

.animate-slide-in-up {
  animation: slideInUp var(--duration-slow) var(--ease-decelerate) forwards;
}

.animate-slide-in-down {
  animation: slideInDown var(--duration-slow) var(--ease-decelerate) forwards;
}

.animate-scale-in {
  animation: scaleIn var(--duration-slow) var(--ease-spring) forwards;
}

.animate-scale-out {
  animation: scaleOut var(--duration-normal) var(--ease-accelerate) forwards;
}

.animate-bounce {
  animation: bounce var(--duration-slower) var(--ease-spring) forwards;
}

.animate-shake {
  animation: shake var(--duration-slow) var(--ease-standard) forwards;
}

.animate-pulse {
  animation: pulse 1.5s var(--ease-standard) infinite;
}

.animate-spin {
  animation: spin 1s linear infinite;
}

.animate-shimmer {
  animation: shimmer 1.5s var(--ease-standard) infinite;
}

/* Stagger Delays */
.stagger-1 { animation-delay: 50ms; }
.stagger-2 { animation-delay: 100ms; }
.stagger-3 { animation-delay: 150ms; }
.stagger-4 { animation-delay: 200ms; }
.stagger-5 { animation-delay: 250ms; }
.stagger-6 { animation-delay: 300ms; }
.stagger-7 { animation-delay: 350ms; }
.stagger-8 { animation-delay: 400ms; }

/* Keyframes */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes fadeOut {
  from { opacity: 1; }
  to { opacity: 0; }
}

@keyframes slideInLeft {
  from { transform: translateX(-20px); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}

@keyframes slideInRight {
  from { transform: translateX(20px); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}

@keyframes slideInUp {
  from { transform: translateY(20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

@keyframes slideInDown {
  from { transform: translateY(-20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

@keyframes scaleIn {
  from { transform: scale(0.9); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}

@keyframes scaleOut {
  from { transform: scale(1); opacity: 1; }
  to { transform: scale(0.9); opacity: 0; }
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-5px); }
  75% { transform: translateX(5px); }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}

/* Reduced Motion */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }

  .animate-pulse,
  .animate-spin,
  .animate-shimmer {
    animation: none !important;
  }
}

/* GPU Acceleration */
.gpu-accelerated {
  will-change: transform, opacity;
  transform: translateZ(0);
  backface-visibility: hidden;
}
```

### 6.2 JavaScript Animation API (Web Animations API)

```javascript
// Web Animations API Helper
class AuraAnimation {
  static fadeIn(element, options = {}) {
    return element.animate([
      { opacity: 0 },
      { opacity: 1 }
    ], {
      duration: options.duration || 300,
      easing: options.easing || 'cubic-bezier(0.0, 0.0, 0.2, 1)',
      fill: 'forwards'
    });
  }

  static fadeOut(element, options = {}) {
    return element.animate([
      { opacity: 1 },
      { opacity: 0 }
    ], {
      duration: options.duration || 200,
      easing: options.easing || 'cubic-bezier(0.4, 0.0, 1, 1)',
      fill: 'forwards'
    });
  }

  static slideIn(element, direction = 'up', options = {}) {
    const distance = options.distance || 20;
    const transforms = {
      up: `translateY(${distance}px)`,
      down: `translateY(-${distance}px)`,
      left: `translateX(${distance}px)`,
      right: `translateX(-${distance}px)`
    };

    return element.animate([
      { transform: transforms[direction], opacity: 0 },
      { transform: 'translate(0)', opacity: 1 }
    ], {
      duration: options.duration || 300,
      easing: options.easing || 'cubic-bezier(0.0, 0.0, 0.2, 1)',
      fill: 'forwards'
    });
  }

  static scaleIn(element, options = {}) {
    return element.animate([
      { transform: 'scale(0.9)', opacity: 0 },
      { transform: 'scale(1)', opacity: 1 }
    ], {
      duration: options.duration || 300,
      easing: options.easing || 'cubic-bezier(0.34, 1.56, 0.64, 1)',
      fill: 'forwards'
    });
  }

  static stagger(elements, animation, options = {}) {
    const delay = options.delay || 50;
    return elements.map((el, i) => {
      return animation(el, { ...options, delay: i * delay });
    });
  }

  static spring(element, property, from, to, options = {}) {
    const stiffness = options.stiffness || 100;
    const damping = options.damping || 10;
    const mass = options.mass || 1;

    // Spring physics simulation
    const duration = 1000; // Calculate based on spring parameters

    return element.animate([
      { [property]: from },
      { [property]: to }
    ], {
      duration,
      easing: `cubic-bezier(0.34, 1.56, 0.64, 1)`, // Approximate spring
      fill: 'forwards'
    });
  }

  // FLIP Animation (First, Last, Invert, Play)
  static flip(element, animateFn) {
    // First: Get initial state
    const first = element.getBoundingClientRect();

    // Execute the change
    animateFn();

    // Last: Get final state
    const last = element.getBoundingClientRect();

    // Invert: Calculate difference
    const deltaX = first.left - last.left;
    const deltaY = first.top - last.top;
    const deltaW = first.width / last.width;
    const deltaH = first.height / last.height;

    // Apply inverted transform
    element.style.transform = `translate(${deltaX}px, ${deltaY}px) scale(${deltaW}, ${deltaH})`;

    // Play: Animate to natural state
    requestAnimationFrame(() => {
      element.style.transition = 'transform 300ms cubic-bezier(0.4, 0.0, 0.2, 1)';
      element.style.transform = '';
    });
  }

  // Scroll-triggered animation
  static scrollTrigger(element, animation, options = {}) {
    const threshold = options.threshold || 0.1;
    const rootMargin = options.rootMargin || '0px';

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          animation(element);
          if (!options.repeat) {
            observer.unobserve(element);
          }
        }
      });
    }, { threshold, rootMargin });

    observer.observe(element);
    return observer;
  }

  // Parallax effect
  static parallax(element, speed = 0.5) {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const rect = element.getBoundingClientRect();
      const elementTop = rect.top + scrollY;
      const distance = (scrollY - elementTop) * speed;
      element.style.transform = `translateY(${distance}px)`;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }
}
```

### 6.3 Lottie Animation Integration

```yaml
lottie_integration:
  format: "JSON-based animation format"
  use_case: "Complex vector animations, icons, illustrations, brand animations"
  performance: "GPU-accelerated, 60fps"
  file_size: "Typically 10-100KB (smaller than GIF/video)"

  implementation:
    library: "lottie-web (npm install lottie-web)"
    react: "lottie-react (npm install lottie-react)"

  best_practices:
    - "Keep animations under 5 seconds for loops"
    - "Limit layers and shapes for performance"
    - "Use vector shapes, not raster images"
    - "Optimize in After Effects before export"
    - "Use lottiefiles.com to test and optimize"
    - "Consider lottie-light for simpler animations"
    - "Lazy load animations below the fold"

  export_settings:
    plugin: "Bodymovin (After Effects)"
    settings:
      - "Guided layers: Off"
      - "Hidden layers: Off (unless needed)"
      - "Extra compositions: Off"
      - "Assets: Include in JSON or separate files"
      - "Glyphs: Convert to shapes if possible"
      - "Demo: Export HTML demo for testing"

  react_component:
    code: |
      import Lottie from 'lottie-react';
      import animationData from './animation.json';

      function AnimatedIcon({ play, loop = true, speed = 1 }) {
        return (
          <Lottie
            animationData={animationData}
            loop={loop}
            autoplay={play}
            speed={speed}
            style={{ width: 48, height: 48 }}
            rendererSettings={{
              preserveAspectRatio: 'xMidYMid slice'
            }}
          />
        );
      }
```

---

## 7. MOTION DESIGN TOKENS

```yaml
motion_tokens:
  duration:
    instant: 0ms
    fast: 100ms
    normal: 200ms
    slow: 300ms
    slower: 400ms
    slowest: 500ms

  easing:
    linear: "linear"
    standard: "cubic-bezier(0.4, 0.0, 0.2, 1)"
    decelerate: "cubic-bezier(0.0, 0.0, 0.2, 1)"
    accelerate: "cubic-bezier(0.4, 0.0, 1, 1)"
    sharp: "cubic-bezier(0.4, 0.0, 0.6, 1)"
    spring: "cubic-bezier(0.34, 1.56, 0.64, 1)"
    bounce: "cubic-bezier(0.68, -0.55, 0.265, 1.55)"

  animation:
    fade_in: "opacity 0 to 1"
    fade_out: "opacity 1 to 0"
    slide_in_up: "translateY(20px) to 0, opacity 0 to 1"
    slide_in_down: "translateY(-20px) to 0, opacity 0 to 1"
    slide_in_left: "translateX(20px) to 0, opacity 0 to 1"
    slide_in_right: "translateX(-20px) to 0, opacity 0 to 1"
    scale_in: "scale(0.9) to 1, opacity 0 to 1"
    scale_out: "scale(1) to 0.9, opacity 1 to 0"
    bounce: "translateY(0) to -10px to 0"
    shake: "translateX(0) to -5px to 5px to 0"
    pulse: "opacity 1 to 0.5 to 1"
    spin: "rotate(0deg) to 360deg"
    shimmer: "background-position -200% to 200%"

  stagger:
    fast: 30ms
    normal: 50ms
    slow: 100ms

  spring:
    stiffness: 100
    damping: 10
    mass: 1
```

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: Animation & Motion Design Guide*
