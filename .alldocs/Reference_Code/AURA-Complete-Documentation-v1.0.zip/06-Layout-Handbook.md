# AURA Layout Handbook
## Complete Layout & Composition Reference v1.0

---

## 1. GRID SYSTEMS

### 1.1 Grid Fundamentals

```yaml
grid_fundamentals:
  definition: "A system of intersecting horizontal and vertical lines that create a structure for organizing content"
  purpose:
    - "Create order and consistency"
    - "Establish visual hierarchy"
    - "Improve readability and scanability"
    - "Ensure alignment and balance"
    - "Facilitate responsive design"
    - "Speed up design and development"

  types:
    manuscript:
      description: "Single column grid, traditional for books"
      columns: 1
      margins: "Generous (top/bottom/inside/outside)"
      use: ["Novels", "Essays", "Long-form reading"]

    column:
      description: "Multiple equal-width columns"
      columns: "2-12"
      gutter: "Consistent spacing between columns"
      use: ["Magazines", "Newspapers", "Websites", "Dashboards"]

    modular:
      description: "Columns + rows creating modules"
      columns: "2-12"
      rows: "Variable or fixed"
      module: "Consistent unit of space"
      use: ["Complex layouts", "Dashboards", "Masonry", "Editorial"]

    hierarchical:
      description: "Asymmetric grid with unequal columns"
      columns: "2-4 unequal widths"
      use: ["Editorial", "Blogs", "Product pages", "Landing pages"]

    baseline:
      description: "Horizontal lines based on line height"
      line_height: "Base unit (e.g., 8px, 16px, 24px)"
      use: ["Typography-heavy layouts", "Editorial", "Print"]

    compound:
      description: "Multiple grids overlaid or nested"
      use: ["Complex editorial", "Magazines", "Advanced layouts"]

    fluid:
      description: "Grid scales proportionally with viewport"
      columns: "Percentage-based"
      use: ["Responsive web", "Fluid layouts"]

    adaptive:
      description: "Grid changes at breakpoints"
      breakpoints: "Different column counts per breakpoint"
      use: ["Responsive web", "Mobile-first design"]
```

### 1.2 Grid Specifications

```yaml
grid_specifications:
  8px_grid:
    base_unit: 8px
    scale: [8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128]
    use: "Google Material Design, most modern UI systems"
    advantage: "Scales well, divisible by 2 and 4, works with 16px font base"

  4px_grid:
    base_unit: 4px
    scale: [4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64]
    use: "Very detailed UI, Apple iOS design"
    advantage: "Maximum flexibility, fine-grained control"
    disadvantage: "Can be too granular, harder to maintain consistency"

  10px_grid:
    base_unit: 10px
    scale: [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120]
    use: "Legacy systems, some print design"
    advantage: "Easy mental math (decimal system)"
    disadvantage: "Doesn't align well with 16px font base"

  12_column_grid:
    columns: 12
    gutter: "24px (desktop), 16px (tablet), 12px (mobile)"
    margin: "Auto (centered), or fixed (e.g., 24px)"
    max_width: "1200px, 1280px, 1440px"
    use: "Bootstrap, most web frameworks, standard web design"

  16_column_grid:
    columns: 16
    gutter: "24px"
    margin: "Auto"
    max_width: "1440px, 1600px"
    use: "Complex dashboards, data-heavy interfaces, wide screens"

  24_column_grid:
    columns: 24
    gutter: "16px"
    margin: "Auto"
    max_width: "1920px"
    use: "Very complex layouts, design tools, video editing interfaces"

  print_grid:
    columns: "3-5"
    gutter: "12pt (1pica)"
    margin: "0.5in - 1in depending on format"
    use: "Magazines, brochures, books"
```

### 1.3 Grid CSS Implementation

```css
/* 12-Column Grid System */
.grid {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 24px;
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 24px;
}

/* Column Span Classes */
.col-1  { grid-column: span 1; }
.col-2  { grid-column: span 2; }
.col-3  { grid-column: span 3; }
.col-4  { grid-column: span 4; }
.col-5  { grid-column: span 5; }
.col-6  { grid-column: span 6; }
.col-7  { grid-column: span 7; }
.col-8  { grid-column: span 8; }
.col-9  { grid-column: span 9; }
.col-10 { grid-column: span 10; }
.col-11 { grid-column: span 11; }
.col-12 { grid-column: span 12; }

/* Responsive Breakpoints */
@media (max-width: 767px) {
  .grid {
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    padding: 0 16px;
  }
  .col-sm-1 { grid-column: span 1; }
  .col-sm-2 { grid-column: span 2; }
  .col-sm-3 { grid-column: span 3; }
  .col-sm-4 { grid-column: span 4; }
}

@media (min-width: 768px) and (max-width: 1023px) {
  .grid {
    grid-template-columns: repeat(8, 1fr);
    gap: 16px;
    padding: 0 16px;
  }
  .col-md-1 { grid-column: span 1; }
  .col-md-2 { grid-column: span 2; }
  .col-md-3 { grid-column: span 3; }
  .col-md-4 { grid-column: span 4; }
  .col-md-5 { grid-column: span 5; }
  .col-md-6 { grid-column: span 6; }
  .col-md-7 { grid-column: span 7; }
  .col-md-8 { grid-column: span 8; }
}

/* Offset Classes */
.offset-1  { grid-column-start: 2; }
.offset-2  { grid-column-start: 3; }
.offset-3  { grid-column-start: 4; }
.offset-4  { grid-column-start: 5; }
.offset-5  { grid-column-start: 6; }
.offset-6  { grid-column-start: 7; }

/* Auto Layout (Flexbox fallback) */
.flex-grid {
  display: flex;
  flex-wrap: wrap;
  margin: -12px;
}

.flex-grid > * {
  flex: 1 1 0;
  min-width: 0;
  padding: 12px;
}

.flex-grid .flex-2 { flex: 2 1 0; }
.flex-grid .flex-3 { flex: 3 1 0; }
.flex-grid .flex-4 { flex: 4 1 0; }
.flex-grid .flex-6 { flex: 6 1 0; }
```

---

## 2. COMPOSITION SYSTEMS

### 2.1 Classical Composition

```yaml
classical_composition:
  rule_of_thirds:
    description: "Divide canvas into 3x3 grid, place focal points at intersections"
    grid: "3x3"
    intersections: "4 power points"
    use: "Photography, general design, most versatile"
    strength: "Natural, balanced, not too static"

  golden_ratio:
    ratio: 1.618
    description: "Divide canvas by golden ratio (61.8% / 38.2%)"
    applications:
      - "Canvas division: 61.8% / 38.2%"
      - "Spiral placement for focal points"
      - "Typography scale ratios"
      - "Grid proportions"
    use: "Nature-inspired, organic, aesthetically pleasing"
    strength: "Found in nature, universally appealing"

  golden_spiral:
    description: "Logarithmic spiral based on golden ratio squares"
    construction: "Squares with side lengths following Fibonacci sequence"
    focal_point: "Center of spiral (smallest square)"
    use: "Nature photography, artistic compositions, logos"

  golden_triangle:
    description: "Diagonal line + perpendiculars creating triangles"
    construction: "Draw diagonal, drop perpendiculars from corners"
    use: "Dynamic, diagonal compositions"

  dynamic_symmetry:
    root_rectangles: ["sqrt(1)", "sqrt(2)", "sqrt(3)", "sqrt(4)", "sqrt(5)", "phi"]
    description: "Rectangles with specific root proportions"
    use: "Classical art, editorial, architecture photography"

  diagonal_method:
    description: "Important elements on diagonals of square"
    use: "Square formats, portraits, Instagram"

  rabatment:
    description: "Square on short side of rectangle, elements in square or remaining area"
    use: "Rectangular formats, classical painting"
```

### 2.2 Modern Composition

```yaml
modern_composition:
  center_composition:
    description: "Focal point in center of frame"
    use: "Symmetrical subjects, icons, portraits, minimalism"
    strength: "Direct, powerful, formal"
    weakness: "Can be static, boring if overused"

  frame_within_frame:
    description: "Use natural or created frames within the image"
    examples: ["Doorways", "Windows", "Arches", "Branches", "Tunnels"]
    use: "Storytelling, photography, editorial"
    strength: "Adds depth, draws eye inward, creates layers"

  leading_lines:
    description: "Lines guide eye to focal point"
    types: ["Horizontal (calm, stable)", "Vertical (strength, growth)", "Diagonal (dynamic, movement)", "Curved (graceful, natural)", "Converging (depth, perspective)"]
    use: "Architecture, landscape, editorial, photography"
    strength: "Directs attention, creates depth, adds movement"

  symmetry:
    types:
      - "Reflection (mirror image)"
      - "Rotational (radial, around center)"
      - "Translational (repeating pattern)"
      - "Bilateral (left-right mirror)"
    use: "Formal, balanced, architectural, luxury"
    strength: "Ordered, stable, elegant, powerful"
    weakness: "Can be static, predictable"

  asymmetry:
    description: "Unequal visual weight balanced by interest"
    technique: "Large simple element vs small complex element"
    use: "Modern, dynamic, editorial, artistic"
    strength: "Interesting, engaging, contemporary"
    weakness: "Harder to balance, can feel unstable"

  negative_space:
    description: "Intentional empty space as design element"
    use: "Minimalism, luxury, elegance, focus"
    strength: "Creates focus, elegance, breathing room"
    rule: "Empty space should be intentional, not accidental"

  filling_the_frame:
    description: "Subject fills entire frame, minimal background"
    use: "Portraits, product photography, detail shots"
    strength: "Intimate, powerful, eliminates distractions"

  depth_layers:
    description: "Foreground, middle ground, background"
    use: "Landscape, editorial, storytelling"
    strength: "Creates depth, interest, narrative"

  breaking_the_grid:
    description: "Intentionally breaking grid for emphasis"
    use: "Editorial, artistic, attention-grabbing"
    strength: "Creates visual interest, highlights key elements"
    rule: "Must break grid intentionally, not accidentally"

  z_pattern:
    description: "Eye scans in Z-shape: top-left → top-right → diagonal → bottom-left → bottom-right"
    use: "Landing pages, ads, simple layouts"
    strength: "Matches natural reading pattern for simple content"

  f_pattern:
    description: "Eye scans in F-shape: horizontal top, then down left side"
    use: "Content-heavy pages, articles, search results"
    strength: "Matches natural web reading behavior"

  gutenberg_diagram:
    description: "Reading gravity: top-left (primary optical area) → bottom-right (terminal area)"
    zones:
      primary_optical: "Top-left (most attention)"
      strong_fallow: "Top-right"
      weak_fallow: "Bottom-left"
      terminal: "Bottom-right (natural end point for CTA)"
    use: "Print layouts, simple web pages"
```

### 2.3 Composition for Specific Formats

```yaml
format_composition:
  social_media_square:
    aspect_ratio: "1:1"
    focal_point: "Center or slightly above center"
    text_placement: "Top or bottom third, avoid center"
    safe_zone: "Keep critical content in center 80%"

  social_media_story:
    aspect_ratio: "9:16"
    focal_point: "Center, slightly above middle"
    text_placement: "Top or bottom, avoid very top (UI overlap)"
    safe_zone: "Keep critical content in center 70% vertically"

  landscape_banner:
    aspect_ratio: "16:9, 21:9, 3:1"
    focal_point: "Left third or center"
    text_placement: "Left or right third, avoid center if busy"
    safe_zone: "Check platform-specific safe zones"

  portrait_poster:
    aspect_ratio: "2:3, 3:4"
    focal_point: "Upper third (eye level)"
    text_placement: "Top or bottom, hierarchy from top"
    safe_zone: "Keep 10% margin from edges"

  presentation_slide:
    aspect_ratio: "16:9, 4:3"
    focal_point: "Left-center or center"
    text_placement: "Left-aligned, top or middle"
    safe_zone: "Keep 5% margin from edges"

  mobile_screen:
    aspect_ratio: "9:19.5, 9:18"
    focal_point: "Upper-middle (thumb zone)"
    text_placement: "Top or bottom, readable size"
    safe_zone: "Avoid very top (status bar) and bottom (gestures)"

  print_brochure:
    aspect_ratio: "Variable (tri-fold, bi-fold)"
    focal_point: "Front panel or center spread"
    text_placement: "Follow fold lines, keep text away from folds"
    safe_zone: "Keep 5mm from trim, 10mm from folds"
```

---

## 3. SPACING SYSTEMS

### 3.1 Spacing Scale

```yaml
spacing_scale:
  4px_base:
    name: "4px Base Scale"
    values: [4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64]
    use: "iOS, detailed UI, fine-grained control"

  8px_base:
    name: "8px Base Scale"
    values: [8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112, 120, 128]
    use: "Material Design, most web systems, Android"

  16px_base:
    name: "16px Base Scale"
    values: [16, 32, 48, 64, 80, 96, 112, 128, 144, 160, 176, 192, 208, 224, 240, 256]
    use: "Large layouts, spacious design, editorial"

  fibonacci_scale:
    name: "Fibonacci Scale"
    values: [4, 8, 12, 20, 32, 52, 84, 136, 220, 356]
    use: "Organic spacing, nature-inspired design"

  exponential_scale:
    name: "Exponential Scale"
    values: [4, 8, 16, 32, 64, 128, 256, 512]
    use: "Dramatic spacing, large-scale layouts"
```

### 3.2 Spacing Tokens

```yaml
spacing_tokens:
  primitive:
    - "space.0: 0px"
    - "space.1: 4px"
    - "space.2: 8px"
    - "space.3: 12px"
    - "space.4: 16px"
    - "space.5: 20px"
    - "space.6: 24px"
    - "space.7: 32px"
    - "space.8: 40px"
    - "space.9: 48px"
    - "space.10: 64px"
    - "space.11: 80px"
    - "space.12: 96px"
    - "space.13: 128px"
    - "space.14: 160px"
    - "space.15: 192px"
    - "space.16: 256px"
    - "space.17: 320px"
    - "space.18: 384px"
    - "space.19: 512px"

  semantic:
    - "space.gap.xs: {space.1}"
    - "space.gap.sm: {space.2}"
    - "space.gap.md: {space.4}"
    - "space.gap.lg: {space.6}"
    - "space.gap.xl: {space.8}"
    - "space.gap.2xl: {space.10}"

    - "space.padding.xs: {space.2}"
    - "space.padding.sm: {space.3}"
    - "space.padding.md: {space.4}"
    - "space.padding.lg: {space.6}"
    - "space.padding.xl: {space.8}"
    - "space.padding.2xl: {space.10}"
    - "space.padding.3xl: {space.12}"

    - "space.margin.xs: {space.2}"
    - "space.margin.sm: {space.4}"
    - "space.margin.md: {space.6}"
    - "space.margin.lg: {space.8}"
    - "space.margin.xl: {space.10}"
    - "space.margin.2xl: {space.12}"
    - "space.margin.3xl: {space.14}"

    - "space.section.xs: {space.8}"
    - "space.section.sm: {space.10}"
    - "space.section.md: {space.12}"
    - "space.section.lg: {space.14}"
    - "space.section.xl: {space.16}"

    - "space.container.sm: {space.4}"
    - "space.container.md: {space.6}"
    - "space.container.lg: {space.8}"
    - "space.container.xl: {space.10}"

    - "space.inset.xs: {space.2}"
    - "space.inset.sm: {space.3}"
    - "space.inset.md: {space.4}"
    - "space.inset.lg: {space.6}"
    - "space.inset.xl: {space.8}"

    - "space.stack.xs: {space.1}"
    - "space.stack.sm: {space.2}"
    - "space.stack.md: {space.3}"
    - "space.stack.lg: {space.4}"
    - "space.stack.xl: {space.6}"
    - "space.stack.2xl: {space.8}"

    - "space.inline.xs: {space.1}"
    - "space.inline.sm: {space.2}"
    - "space.inline.md: {space.3}"
    - "space.inline.lg: {space.4}"
    - "space.inline.xl: {space.6}"
    - "space.inline.2xl: {space.8}"
```

### 3.3 Spacing Rules

```yaml
spacing_rules:
  - rule: "Proximity Principle"
    description: "Related elements should be closer together than unrelated elements"
    related_spacing: "8-16px"
    unrelated_spacing: "32-64px"
    section_spacing: "64-128px"

  - rule: "Consistent Spacing"
    description: "Use spacing scale values, never arbitrary numbers"
    exception: "When optical alignment requires adjustment (e.g., icons vs text)"

  - rule: "Whitespace Hierarchy"
    description: "More important elements get more surrounding whitespace"
    hero_element: "2-3x standard spacing"
    section_divider: "2-3x standard spacing"
    related_elements: "1x standard spacing"

  - rule: "Padding vs Margin"
    description: "Padding is internal spacing, margin is external spacing"
    padding: "Space inside component (background color extends to edge)"
    margin: "Space outside component (background color doesn't extend)"

  - rule: "Stack Pattern"
    description: "Vertical spacing between stacked elements"
    formula: "Stack spacing = related element gap"

  - rule: "Inline Pattern"
    description: "Horizontal spacing between inline elements"
    formula: "Inline spacing = related element gap"

  - rule: "Inset Pattern"
    description: "Internal spacing within a container"
    formula: "Inset = padding on all sides"

  - rule: "Squish Inset"
    description: "More horizontal padding than vertical"
    use: "Buttons, badges, chips, horizontal emphasis"
    example: "padding: 8px 16px (vertical horizontal)"

  - rule: "Stretch Inset"
    description: "More vertical padding than horizontal"
    use: "Cards with top/bottom emphasis, vertical buttons"
    example: "padding: 16px 8px"

  - rule: "Optical Alignment"
    description: "Adjust spacing based on visual weight, not mathematical center"
    examples:
      - "Circles appear smaller than squares: increase circle size or reduce spacing"
      - "Text with descenders needs more bottom padding"
      - "Icons with visual weight on one side need asymmetric padding"
```

---

## 4. RESPONSIVE DESIGN

### 4.1 Breakpoint System

```yaml
breakpoint_system:
  mobile_first:
    xs: "0px - 639px"
    sm: "640px - 767px"
    md: "768px - 1023px"
    lg: "1024px - 1279px"
    xl: "1280px - 1535px"
    2xl: "1536px+"

  desktop_first:
    desktop: "1280px+"
    laptop: "1024px - 1279px"
    tablet: "768px - 1023px"
    mobile: "640px - 767px"
    tiny: "0px - 639px"

  content_based:
    description: "Breakpoints based on content needs, not device widths"
    approach: "Resize browser until layout breaks, set breakpoint there"
    advantage: "Future-proof, device-agnostic"

  common_breakpoints:
    - "320px: Small mobile (iPhone SE)"
    - "375px: Mobile (iPhone)"
    - "414px: Large mobile (iPhone Plus/Max)"
    - "640px: Small tablet / large phone landscape"
    - "768px: Tablet (iPad portrait)"
    - "1024px: Tablet landscape / small laptop"
    - "1280px: Laptop"
    - "1440px: Desktop"
    - "1920px: Large desktop"
    - "2560px: Ultra-wide / 4K"
```

### 4.2 Responsive Patterns

```yaml
responsive_patterns:
  mostly_fluid:
    description: "Multi-column layout that reflows at breakpoints"
    behavior: "Columns maintain proportions, stack at small breakpoints"
    use: "Blogs, content sites, general web"

  column_drop:
    description: "Columns drop below each other as viewport shrinks"
    behavior: "3-col → 2-col → 1-col"
    use: "Product grids, card layouts, dashboards"

  layout_shifter:
    description: "Layout changes significantly at breakpoints"
    behavior: "Different element order, different grid structures"
    use: "Complex layouts, marketing sites, landing pages"

  tiny_tweaks:
    description: "Minor adjustments, mostly single column"
    behavior: "Font size, padding, margins adjust slightly"
    use: "Simple layouts, single-column content, mobile-first"

  off_canvas:
    description: "Secondary content hidden off-screen, toggled visible"
    behavior: "Sidebar hidden by default, slides in on toggle"
    use: "Navigation, filters, shopping cart, chat"

  reveal:
    description: "Content progressively revealed as viewport grows"
    behavior: "More content/columns appear at larger breakpoints"
    use: "Dashboards, data tables, complex UIs"

  reflow:
    description: "Content reflows within same container"
    behavior: "Text wraps differently, images resize, grids adjust"
    use: "Articles, documentation, general content"

  reposition:
    description: "Elements move to different positions"
    behavior: "Sidebar moves from right to top, etc."
    use: "Forms, detail pages, product pages"
```

### 4.3 Responsive Typography

```css
/* Fluid Typography using clamp() */
:root {
  --font-size-xs: clamp(0.64rem, 0.05vw + 0.63rem, 0.68rem);
  --font-size-sm: clamp(0.8rem, 0.09vw + 0.78rem, 0.875rem);
  --font-size-base: clamp(1rem, 0.14vw + 0.97rem, 1.125rem);
  --font-size-lg: clamp(1.25rem, 0.23vw + 1.2rem, 1.45rem);
  --font-size-xl: clamp(1.563rem, 0.36vw + 1.49rem, 1.875rem);
  --font-size-2xl: clamp(1.953rem, 0.56vw + 1.84rem, 2.441rem);
  --font-size-3xl: clamp(2.441rem, 0.84vw + 2.27rem, 3.052rem);
  --font-size-4xl: clamp(3.052rem, 1.25vw + 2.8rem, 3.815rem);
  --font-size-5xl: clamp(3.815rem, 1.83vw + 3.45rem, 4.768rem);
  --font-size-6xl: clamp(4.768rem, 2.64vw + 4.24rem, 5.96rem);
}

/* Container Queries (Modern Approach) */
@container (min-width: 400px) {
  .card {
    grid-template-columns: 1fr 1fr;
  }
}

@container (min-width: 700px) {
  .card {
    grid-template-columns: 1fr 1fr 1fr;
  }
}
```

---

## 5. LAYOUT PATTERNS

### 5.1 Web Layout Patterns

```yaml
web_layout_patterns:
  hero_section:
    structure: "Full-width, above fold, headline + subhead + CTA + visual"
    height: "100vh or 60-80vh"
    content_alignment: "Center or left-aligned"
    visual: "Background image/video or illustration"
    cta_placement: "Below headline, prominent"

  feature_grid:
    structure: "3-4 columns of feature cards with icon + title + description"
    spacing: "24-32px between cards"
    card_style: "Equal height, consistent padding"
    icon: "Above title, centered or left-aligned"

  split_screen:
    structure: "50/50 or 60/40 split, text on one side, visual on other"
    use: "Storytelling, product showcases, about pages"
    alignment: "Vertically centered content"
    responsive: "Stack on mobile (image first or text first)"

  asymmetric_layout:
    structure: "Unequal columns, overlapping elements, broken grid"
    use: "Editorial, creative agencies, portfolios"
    technique: "Large image + overlapping text card"

  card_grid:
    structure: "Responsive grid of equal-sized cards"
    columns: "4 (desktop), 2 (tablet), 1 (mobile)"
    gap: "24px"
    card_elements: ["Image", "Title", "Description", "Meta", "CTA"]

  masonry:
    structure: "Pinterest-style, varying height items"
    use: "Image galleries, portfolios, discovery feeds"
    columns: "Dynamic based on container width"
    gap: "16-24px"

  dashboard:
    structure: "Sidebar nav + widget grid + header"
    sidebar: "240-280px fixed or collapsible"
    header: "64px fixed, with search and actions"
    widget_grid: "Responsive grid, 1-4 columns"
    widgets: "Resizable, customizable, draggable"

  magazine:
    structure: "Asymmetric grid, featured article + sidebar"
    use: "Editorial, content-heavy sites"
    featured: "Large hero article, spans 2-3 columns"
    sidebar: "Recent articles, categories, ads"

  single_page:
    structure: "Vertical scroll sections with anchor nav"
    use: "Portfolios, product launches, events"
    sections: ["Hero", "Features", "Gallery", "Testimonials", "CTA", "Footer"]
    nav: "Fixed top or side, highlights current section"

  sidebar_content:
    structure: "Sidebar (20-25%) + Main content (75-80%)"
    sidebar: "Navigation, filters, related content"
    main: "Primary content, article, product details"
    responsive: "Sidebar becomes drawer or top nav on mobile"

  sticky_footer:
    structure: "Header + Content (flex-grow) + Sticky Footer"
    footer: "Always visible at bottom, even with short content"

  holy_grail:
    structure: "Header + Left Sidebar + Content + Right Sidebar + Footer"
    use: "Complex content sites, documentation"
    responsive: "Sidebars collapse or become drawers on mobile"
```

### 5.2 Print Layout Patterns

```yaml
print_layout_patterns:
  single_page:
    structure: "Single page with margins, header, footer, content area"
    margins: "0.5in - 1in all sides"
    header_footer: "Page numbers, document title, section"

  facing_pages:
    structure: "Left and right pages with different margins"
    gutter: "Larger inner margin for binding"
    use: "Books, magazines, catalogs"

  grid_system:
    structure: "Consistent column grid across all pages"
    columns: "3-5 columns"
    gutter: "12pt (1 pica)"
    use: "Magazines, brochures, annual reports"

  modular_grid:
    structure: "Columns + rows creating modules"
    use: "Complex layouts, newspapers, editorial"

  baseline_grid:
    structure: "Text aligned to horizontal baseline grid"
    line_height: "Base unit (e.g., 14pt)"
    use: "Books, magazines, typography-heavy layouts"

  asymmetrical:
    structure: "Unequal column widths, overlapping elements"
    use: "Editorial, avant-garde design, artistic layouts"

  axial:
    structure: "Elements aligned along a central axis"
    use: "Formal documents, certificates, invitations"

  radial:
    structure: "Elements radiating from a central point"
    use: "Circular layouts, infographics, diagrams"

  dilatational:
    structure: "Elements emanating from a corner or edge"
    use: "Posters, dynamic layouts, directional emphasis"
```

---

## 6. AUTO LAYOUT & CONSTRAINTS

### 6.1 Auto Layout System (Figma-style)

```yaml
auto_layout_system:
  direction:
    vertical: "Stack children vertically (column)"
    horizontal: "Stack children horizontally (row)"

  spacing:
    gap: "Space between children"
    padding: "Space inside container (top, right, bottom, left)"

  alignment:
    start: "Align to start of axis (top/left)"
    center: "Center along axis"
    end: "Align to end of axis (bottom/right)"
    space_between: "Distribute with space between"
    space_around: "Distribute with space around"
    space_evenly: "Distribute with equal space"

  distribution:
    start: "Pack at start"
    center: "Pack at center"
    end: "Pack at end"

  sizing:
    hug: "Container shrinks to fit content"
    fill: "Container expands to fill parent"
    fixed: "Container has fixed size"

  child_sizing:
    fill: "Child expands to fill available space"
    hug: "Child shrinks to fit its own content"
    fixed: "Child has fixed size"

  wrap:
    enabled: "Children wrap to next line when overflow"
    spacing: "Gap between wrapped lines"

  advanced:
    counter_axis_align: "Alignment perpendicular to main axis"
    canvas_stacking: "How overlapping elements stack"
    stroke_align: "Stroke inside, center, or outside"
```

### 6.2 Constraint System

```yaml
constraint_system:
  horizontal:
    left: "Element maintains distance from left edge"
    right: "Element maintains distance from right edge"
    left_right: "Element stretches with parent (maintains both margins)"
    center: "Element maintains center position"
    scale: "Element scales proportionally with parent"

  vertical:
    top: "Element maintains distance from top edge"
    bottom: "Element maintains distance from bottom edge"
    top_bottom: "Element stretches with parent (maintains both margins)"
    center: "Element maintains center position"
    scale: "Element scales proportionally with parent"

  combinations:
    fixed_position:
      horizontal: "left"
      vertical: "top"
      result: "Element stays at fixed position from top-left"

    stretch_horizontal:
      horizontal: "left_right"
      vertical: "top"
      result: "Element stretches horizontally, fixed top"

    stretch_vertical:
      horizontal: "left"
      vertical: "top_bottom"
      result: "Element stretches vertically, fixed left"

    stretch_both:
      horizontal: "left_right"
      vertical: "top_bottom"
      result: "Element stretches to fill parent"

    center_fixed:
      horizontal: "center"
      vertical: "center"
      result: "Element stays centered, fixed size"

    center_stretch_horizontal:
      horizontal: "left_right"
      vertical: "center"
      result: "Element centered vertically, stretches horizontally"

    scale_proportionally:
      horizontal: "scale"
      vertical: "scale"
      result: "Element scales proportionally with parent"
```

### 6.3 CSS Implementation of Constraints

```css
/* Constraint System CSS */

/* Fixed Position (Left + Top) */
.constraint-left-top {
  position: absolute;
  left: var(--constraint-left, 0);
  top: var(--constraint-top, 0);
  width: var(--width);
  height: var(--height);
}

/* Stretch Horizontal (Left-Right + Top) */
.constraint-stretch-h-top {
  position: absolute;
  left: var(--constraint-left, 0);
  right: var(--constraint-right, 0);
  top: var(--constraint-top, 0);
  height: var(--height);
}

/* Stretch Vertical (Left + Top-Bottom) */
.constraint-stretch-v-left {
  position: absolute;
  left: var(--constraint-left, 0);
  top: var(--constraint-top, 0);
  bottom: var(--constraint-bottom, 0);
  width: var(--width);
}

/* Stretch Both (Left-Right + Top-Bottom) */
.constraint-stretch-both {
  position: absolute;
  left: var(--constraint-left, 0);
  right: var(--constraint-right, 0);
  top: var(--constraint-top, 0);
  bottom: var(--constraint-bottom, 0);
}

/* Center Fixed */
.constraint-center {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: var(--width);
  height: var(--height);
}

/* Scale Proportionally */
.constraint-scale {
  position: absolute;
  left: calc(var(--constraint-left-percent, 0) * 100%);
  top: calc(var(--constraint-top-percent, 0) * 100%);
  width: calc(var(--width-percent, 1) * 100%);
  height: calc(var(--height-percent, 1) * 100%);
}

/* Auto Layout (Flexbox) */
.auto-layout {
  display: flex;
}

.auto-layout.vertical {
  flex-direction: column;
}

.auto-layout.horizontal {
  flex-direction: row;
}

.auto-layout.gap-8 { gap: 8px; }
.auto-layout.gap-16 { gap: 16px; }
.auto-layout.gap-24 { gap: 24px; }
.auto-layout.gap-32 { gap: 32px; }

.auto-layout.align-start { align-items: flex-start; }
.auto-layout.align-center { align-items: center; }
.auto-layout.align-end { align-items: flex-end; }
.auto-layout.align-stretch { align-items: stretch; }

.auto-layout.justify-start { justify-content: flex-start; }
.auto-layout.justify-center { justify-content: center; }
.auto-layout.justify-end { justify-content: flex-end; }
.auto-layout.justify-between { justify-content: space-between; }
.auto-layout.justify-around { justify-content: space-around; }
.auto-layout.justify-evenly { justify-content: space-evenly; }

.auto-layout.wrap { flex-wrap: wrap; }
.auto-layout.wrap-reverse { flex-wrap: wrap-reverse; }

.auto-layout-child.fill { flex: 1 1 0; min-width: 0; min-height: 0; }
.auto-layout-child.hug { flex: 0 0 auto; }
.auto-layout-child.fixed { flex: 0 0 var(--fixed-size); }
```

---

## 7. DESIGN SYSTEM LAYOUT TOKENS

### 7.1 Layout Tokens

```yaml
layout_tokens:
  container:
    sm: "640px"
    md: "768px"
    lg: "1024px"
    xl: "1280px"
    2xl: "1536px"
    full: "100%"

  grid:
    columns: 12
    gutter: "24px"
    margin: "24px"
    max_width: "1280px"

  breakpoints:
    xs: "0px"
    sm: "640px"
    md: "768px"
    lg: "1024px"
    xl: "1280px"
    2xl: "1536px"

  z_index:
    base: 0
    dropdown: 1000
    sticky: 1020
    fixed: 1030
    modal_backdrop: 1040
    modal: 1050
    popover: 1060
    tooltip: 1070
    toast: 1080
    fullscreen: 9999

  aspect_ratio:
    square: "1/1"
    portrait: "3/4"
    landscape: "4/3"
    video: "16/9"
    ultrawide: "21/9"
    cinema: "2.39/1"
    story: "9/16"

  object_fit:
    cover: "Cover entire container, may crop"
    contain: "Fit entirely within container, may letterbox"
    fill: "Stretch to fill container"
    none: "Original size, may overflow"
    scale_down: "Like none or contain, whichever is smaller"
```

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: Layout Handbook*
