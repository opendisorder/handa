# AURA 3D, AR & VR Design Guide
## Complete Spatial Design Reference v1.0

---

## 1. 3D DESIGN FUNDAMENTALS

### 1.1 3D Coordinate Systems

```yaml
3d_coordinate_systems:
  cartesian:
    description: "Standard 3D coordinate system (X, Y, Z)"
    right_handed:
      x: "Right (positive)"
      y: "Up (positive)"
      z: "Toward viewer (positive) or away (negative)"
    left_handed:
      x: "Right (positive)"
      y: "Up (positive)"
      z: "Away from viewer (positive)"
    use: "WebGL, Three.js, Unity, Unreal Engine"

  spherical:
    description: "Position defined by radius, theta, phi"
    radius: "Distance from origin"
    theta: "Azimuthal angle (around Y axis, 0-360 degrees)"
    phi: "Polar angle (from Y axis, 0-180 degrees)"
    conversion: "x = r*sin(phi)*cos(theta), y = r*cos(phi), z = r*sin(phi)*sin(theta)"
    use: "Camera positioning, orbital controls, spherical environments"

  cylindrical:
    description: "Position defined by radius, angle, height"
    radius: "Distance from Y axis"
    angle: "Rotation around Y axis (0-360 degrees)"
    height: "Y coordinate"
    conversion: "x = r*cos(angle), y = height, z = r*sin(angle)"
    use: "Cylindrical projections, tower-like structures, radial layouts"

  barycentric:
    description: "Position relative to triangle vertices"
    coordinates: "(u, v, w) where u+v+w = 1"
    use: "Triangle interpolation, UV mapping, mesh deformation"

  normalized_device_coordinates:
    description: "Screen space coordinates (-1 to 1)"
    x: "-1 (left) to 1 (right)"
    y: "-1 (bottom) to 1 (top)"
    z: "0 (near) to 1 (far) or -1 to 1"
    use: "WebGL clip space, viewport mapping"
```

### 1.2 3D Transformations

```yaml
3d_transformations:
  translation:
    matrix: |
      | 1  0  0  tx |
      | 0  1  0  ty |
      | 0  0  1  tz |
      | 0  0  0  1  |
    description: "Move object by (tx, ty, tz)"

  rotation_x:
    matrix: |
      | 1  0      0       0 |
      | 0  cos   -sin     0 |
      | 0  sin    cos     0 |
      | 0  0      0       1 |
    description: "Rotate around X axis by angle theta"

  rotation_y:
    matrix: |
      | cos   0   sin    0 |
      | 0     1   0      0 |
      | -sin  0   cos    0 |
      | 0     0   0      1 |
    description: "Rotate around Y axis by angle theta"

  rotation_z:
    matrix: |
      | cos  -sin   0   0 |
      | sin   cos   0   0 |
      | 0     0     1   0 |
      | 0     0     0   1 |
    description: "Rotate around Z axis by angle theta"

  scale:
    matrix: |
      | sx  0   0   0 |
      | 0   sy  0   0 |
      | 0   0   sz  0 |
      | 0   0   0   1 |
    description: "Scale by (sx, sy, sz)"

  perspective_projection:
    matrix: |
      | 1   0   0       0     |
      | 0   1   0       0     |
      | 0   0   1       0     |
      | 0   0   -1/d    1     |
    description: "Perspective projection with focal distance d"

  orthographic_projection:
    matrix: |
      | 2/(r-l)   0        0       -(r+l)/(r-l) |
      | 0         2/(t-b)  0       -(t+b)/(t-b) |
      | 0         0        -2/(f-n) -(f+n)/(f-n) |
      | 0         0        0        1            |
    description: "Orthographic projection (no perspective distortion)"
    l: "left", r: "right", b: "bottom", t: "top", n: "near", f: "far"

  look_at:
    description: "Camera matrix looking from eye to target"
    parameters: "eye (position), target (look at), up (up vector)"
    formula: |
      z_axis = normalize(eye - target)
      x_axis = normalize(cross(up, z_axis))
      y_axis = cross(z_axis, x_axis)

      | x_axis.x  x_axis.y  x_axis.z  -dot(x_axis, eye) |
      | y_axis.x  y_axis.y  y_axis.z  -dot(y_axis, eye) |
      | z_axis.x  z_axis.y  z_axis.z  -dot(z_axis, eye) |
      | 0         0         0         1                 |

  euler_angles:
    description: "Rotation represented as pitch, yaw, roll"
    pitch: "Rotation around X axis (up/down)"
    yaw: "Rotation around Y axis (left/right)"
    roll: "Rotation around Z axis (tilt)"
    gimbal_lock: "Problem when pitch = +/- 90 degrees"
    solution: "Use quaternions instead"

  quaternions:
    description: "4D representation of rotation (x, y, z, w)"
    advantages: "No gimbal lock, smooth interpolation, compact"
    formula: |
      q = [x, y, z, w]
      x = axis.x * sin(angle/2)
      y = axis.y * sin(angle/2)
      z = axis.z * sin(angle/2)
      w = cos(angle/2)
    interpolation: "Spherical Linear Interpolation (SLERP)"
    use: "Camera rotation, object rotation, animation"
```

### 1.3 3D Lighting

```yaml
3d_lighting:
  ambient_light:
    description: "Uniform light from all directions, no shadows"
    intensity: "0.1-0.3 (subtle fill)"
    color: "Usually white or slightly warm/cool"
    use: "Base illumination, prevent pure black shadows"

  directional_light:
    description: "Parallel rays from infinite distance (like sun)"
    direction: "Vector pointing from light to scene"
    shadows: "Casts sharp shadows (if enabled)"
    intensity: "0.5-1.5"
    use: "Main light source, sun, moon, key light"

  point_light:
    description: "Light emanating from a point in all directions"
    position: "(x, y, z) in world space"
    attenuation: "Intensity decreases with distance (1/d^2)"
    shadows: "Casts soft shadows (if enabled)"
    intensity: "0.5-2.0"
    use: "Lamps, candles, light bulbs, fill lights"

  spot_light:
    description: "Cone-shaped light from a point"
    position: "(x, y, z)"
    direction: "Vector pointing from light"
    angle: "Cone angle (degrees)"
    penumbra: "Softness of edge (0-1)"
    decay: "Distance attenuation"
    shadows: "Casts sharp/soft shadows"
    intensity: "0.5-2.0"
    use: "Flashlights, stage lights, accent lights"

  hemisphere_light:
    description: "Gradient from sky color to ground color"
    sky_color: "Color from above"
    ground_color: "Color from below"
    intensity: "0.2-0.6"
    use: "Outdoor ambient lighting, sky dome"

  area_light:
    description: "Light from a rectangular or circular area"
    size: "Width and height of light area"
    shadows: "Soft shadows with penumbra"
    intensity: "0.5-2.0"
    use: "Studio softboxes, windows, screens"

  environment_light:
    description: "Light from environment map (HDRI)"
    map: "360 degree HDR image"
    intensity: "0.5-1.0"
    use: "Realistic reflections, ambient occlusion, global illumination"

  three_point_lighting:
    description: "Classic studio lighting setup"
    key_light:
      position: "45 degrees to subject, above eye level"
      intensity: "1.0 (main light)"
      color: "Warm white"
    fill_light:
      position: "Opposite key, lower intensity"
      intensity: "0.3-0.5 (fills shadows)"
      color: "Cool white or neutral"
    rim_light:
      position: "Behind subject, opposite key"
      intensity: "0.5-1.0 (separates from background)"
      color: "Warm or brand color"

  physically_based_rendering:
    description: "Realistic lighting based on physical properties"
    properties:
      - "Albedo (base color)"
      - "Metallic (0 = dielectric, 1 = metal)"
      - "Roughness (0 = mirror, 1 = diffuse)"
      - "Normal (surface detail)"
      - "AO (ambient occlusion)"
      - "Emissive (self-illumination)"
    workflow: "Metallic-Roughness or Specular-Glossiness"
```

### 1.4 3D Materials

```yaml
3d_materials:
  standard_material:
    properties:
      color: "Base color (RGB)"
      roughness: "0 = mirror-like, 1 = matte"
      metalness: "0 = non-metal, 1 = metal"
      normal_map: "Surface detail (bump)"
      ao_map: "Ambient occlusion (shadows in crevices)"
      emissive: "Self-illumination color"
      emissive_intensity: "Brightness of emissive"
      opacity: "0 = transparent, 1 = opaque"
      transparent: "Enable transparency"
      side: "Front, back, or double-sided"

  glass_material:
    properties:
      color: "Tint color"
      roughness: "0.0-0.1 (very smooth)"
      metalness: "0.0"
      transmission: "1.0 (full transparency)"
      ior: "1.5 (index of refraction)"
      thickness: "Physical thickness for refraction"
      attenuation_color: "Color absorbed through thickness"
      attenuation_distance: "Distance for full attenuation"

  metal_material:
    properties:
      color: "Metal color (gold, silver, copper, etc.)"
      roughness: "0.0-0.3 (polished) or 0.3-0.7 (brushed)"
      metalness: "1.0"
      env_map: "Environment reflection map"

  plastic_material:
    properties:
      color: "Plastic color"
      roughness: "0.1-0.5 (glossy to matte)"
      metalness: "0.0"
      clearcoat: "1.0 (glossy top layer)"
      clearcoat_roughness: "0.0-0.1"

  fabric_material:
    properties:
      color: "Fabric color"
      roughness: "0.8-1.0 (very matte)"
      metalness: "0.0"
      sheen: "1.0 (fabric sheen)"
      sheen_color: "Sheen tint"
      sheen_roughness: "0.5-1.0"
      normal_map: "Fabric weave texture"

  skin_material:
    properties:
      color: "Skin tone"
      roughness: "0.3-0.6"
      metalness: "0.0"
      subsurface: "1.0 (light scattering)"
      subsurface_color: "Warm red/orange"
      thickness: "Subsurface scattering depth"

  emission_material:
    properties:
      color: "Black (not reflective)"
      emissive: "Light color"
      emissive_intensity: "Brightness"
      tone_mapped: "false (for HDR)"

  toon_material:
    properties:
      color: "Base color"
      gradient_map: "Stepped lighting gradient"
      outline: "Black outline thickness"
      use: "Cel-shaded, anime, cartoon styles"
```

---

## 2. AR (AUGMENTED REALITY) DESIGN

### 2.1 AR Design Principles

```yaml
ar_design_principles:
  context_awareness:
    description: "Design for the user's physical environment"
    considerations:
      - "Lighting conditions (bright, dark, mixed)"
      - "Surface types (flat, textured, reflective)"
      - "Space size (small room, large open area)"
      - "Obstacles (furniture, people, walls)"
      - "Background (cluttered, plain, dynamic)"

  scale_and_proportion:
    description: "Objects should feel natural in the real world"
    rules:
      - "Use real-world scale (1 unit = 1 meter)"
      - "Objects should be appropriate size for context"
      - "Avoid objects that are too small or too large"
      - "Scale UI elements independently of 3D content"

  grounding:
    description: "Objects should appear to exist in the real world"
    techniques:
      - "Shadows cast on detected surfaces"
      - "Occlusion (objects behind real objects)"
      - "Physics (objects rest on surfaces, fall with gravity)"
      - "Contact reactions (sound, particle effects)"

  comfort_and_safety:
    description: "Ensure comfortable and safe AR experience"
    rules:
      - "Avoid requiring rapid head movements"
      - "Keep content within comfortable viewing angle (30 degrees)"
      - "Warn users about obstacles"
      - "Provide seated mode options"
      - "Limit session length (5-10 minutes recommended)"
      - "Encourage breaks"

  minimalism:
    description: "Keep AR content focused and uncluttered"
    rules:
      - "One primary action at a time"
      - "Minimal UI overlaid on camera view"
      - "Use audio cues to reduce visual clutter"
      - "Fade or hide UI when not needed"
      - "Avoid text-heavy interfaces in AR"

  feedback:
    description: "Provide clear feedback for all interactions"
    types:
      - "Visual: Highlight, glow, animation"
      - "Audio: Sound effects, voice feedback"
      - "Haptic: Vibration patterns"
      - "Spatial: Audio positioned in 3D space"

  discoverability:
    description: "Make interactive elements obvious"
    techniques:
      - "Highlight interactive objects"
      - "Use animations to draw attention"
      - "Provide tutorial on first use"
      - "Use gaze or proximity as hover state"

  accessibility:
    description: "Design for all users"
    considerations:
      - "High contrast for UI elements"
      - "Large touch targets (min 44x44pt)"
      - "Voice commands as alternative input"
      - "Adjustable text size"
      - "Colorblind-friendly palettes"
      - "Support for reduced motion"
```

### 2.2 AR Interaction Patterns

```yaml
ar_interaction_patterns:
  placement:
    description: "Place virtual objects in real world"
    methods:
      - "Plane detection: Tap on detected horizontal/vertical surface"
      - "Air placement: Object floats at fixed distance, user positions"
      - "Drag and drop: Drag from UI to real world position"
      - "Voice: 'Place the chair here'"
      - "Gaze: Look at position, confirm with gesture or voice"
    feedback: "Surface highlight, placement preview, snap indicators"

  manipulation:
    description: "Move, rotate, scale virtual objects"
    methods:
      - "Direct touch: Drag to move, pinch to scale, rotate gesture"
      - "Indirect: Select object, use UI controls"
      - "Gaze + gesture: Look at object, hand gestures to manipulate"
      - "Voice: 'Move left', 'Rotate 90 degrees', 'Scale up'"
      - "Controller: 6DOF controller for precise manipulation"
    constraints: "Snap to grid, snap to surface, collision detection"

  selection:
    description: "Select virtual objects"
    methods:
      - "Touch: Tap on object"
      - "Gaze: Look at object for dwell time (1-2s)"
      - "Raycast: Point controller or finger ray at object"
      - "Voice: 'Select the red chair'"
      - "Proximity: Object highlights when near"
    feedback: "Outline, glow, scale pulse, audio cue"

  navigation:
    description: "Move through AR space"
    methods:
      - "Walk: Physical movement (room-scale)"
      - "Teleport: Point and teleport to location"
      - "Fly: Virtual movement with joystick/gesture"
      - "Orbit: Rotate around focal point"
      - "Zoom: Scale entire scene"
    comfort: "Avoid artificial locomotion (causes motion sickness)"

  information_display:
    description: "Show information about real or virtual objects"
    methods:
      - "Floating label: Text label near object"
      - "Billboard: UI panel always facing user"
      - "World-anchored: Info panel fixed to object"
      - "Head-locked: Info in corner of view (like HUD)"
      - "Spatial audio: Audio information positioned in space"
    best_practice: "Minimize head-locked UI, prefer world-anchored"

  collaboration:
    description: "Multiple users in shared AR space"
    methods:
      - "Shared anchors: Objects synchronized across devices"
      - "Avatars: See other users' positions and gaze"
      - "Voice chat: Spatial audio communication"
      - "Gestures: See other users' hand movements"
      - "Annotations: Draw in 3D space"
    synchronization: "Real-time state sync, conflict resolution"
```

### 2.3 AR UI Patterns

```yaml
ar_ui_patterns:
  reticle:
    description: "Center point indicating where user is looking/pointing"
    types:
      - "Dot: Simple center point"
      - "Crosshair: For precision selection"
      - "Circle: For area selection"
      - "Brackets: For object framing"
    states:
      - "Idle: Neutral color, subtle animation"
      - "Hover: Highlight when over interactive object"
      - "Active: Confirm selection in progress"
      - "Loading: Animation during processing"
      - "Error: Red color, shake animation"

  placement_indicator:
    description: "Preview of where object will be placed"
    visual: "Ghost/transparent version of object"
    validation: "Green = valid placement, red = invalid"
    snapping: "Show snap guides (grid, alignment)"

  surface_visualization:
    description: "Show detected surfaces"
    visual: "Grid, dots, or outline on detected planes"
    fade: "Fade out after placement to reduce clutter"
    toggle: "Allow user to show/hide"

  mini_map:
    description: "Top-down view of AR space"
    position: "Corner of screen or wrist (smartwatch)"
    content: "User position, placed objects, boundaries"
    scale: "Adjustable zoom level"

  instruction_overlay:
    description: "Guide user through AR experience"
    types:
      - "Text: Brief instructions at bottom of screen"
      - "Arrow: Directional indicator pointing to target"
      - "Animation: Animated hand showing gesture"
      - "Voice: Audio instructions"
      - "Haptic: Vibration patterns for guidance"
    timing: "Show when needed, auto-hide after action"

  progress_indicator:
    description: "Show processing state"
    types:
      - "Scanning: Progress bar for surface detection"
      - "Loading: Spinner for asset loading"
      - "Processing: Progress for computation"
    position: "Center or near relevant object"

  menu_in_ar:
    description: "Access tools and options in AR"
    types:
      - "Wrist menu: Menu attached to wrist position"
      - "Floating menu: Menu floating in space near user"
      - "World menu: Menu attached to surface or object"
      - "Voice menu: Voice-activated commands"
      - "Gaze menu: Dwell on menu item to select"
    interaction: "Touch, gaze dwell, voice, gesture"

  notification:
    description: "Alert user to events"
    types:
      - "Head-locked: Fixed in corner of view"
      - "World-anchored: Attached to relevant object"
      - "Audio: Spatial audio cue"
      - "Haptic: Vibration pattern"
    duration: "Auto-dismiss after 3-5 seconds"
```

---

## 3. VR (VIRTUAL REALITY) DESIGN

### 3.1 VR Design Principles

```yaml
vr_design_principles:
  presence:
    description: "Create sense of being in virtual space"
    techniques:
      - "Consistent scale (1 unit = 1 meter)"
      - "Realistic physics and interactions"
      - "Spatial audio (3D positioned sound)"
      - "Hand presence (visible hands/controllers)"
      - "Body representation (avatar, mirror)"
      - "Environmental details (lighting, shadows, reflections)"

  comfort:
    description: "Prevent motion sickness and physical discomfort"
    rules:
      - "Maintain 90fps minimum (72fps absolute minimum)"
      - "Avoid artificial locomotion (causes motion sickness)"
      - "Use teleportation for movement"
      - "Keep latency < 20ms (motion-to-photon)"
      - "Provide comfort vignette during movement"
      - "Limit session length (20-30 minutes recommended)"
      - "Encourage breaks every 15 minutes"
      - "Provide seated mode"
      - "Avoid rapid acceleration/deceleration"
      - "Maintain horizon line stability"

  ergonomics:
    description: "Design for physical comfort and safety"
    rules:
      - "Place UI within comfortable reach (0.5-1.5 meters)"
      - "Keep UI within 30-degree field of view from center"
      - "Avoid requiring extended arm positions"
      - "Support both standing and seated play"
      - "Warn about real-world obstacles"
      - "Provide guardian/chaperone boundaries"
      - "Design for various heights and arm lengths"

  interaction:
    description: "Natural and intuitive interactions"
    principles:
      - "Direct manipulation: Grab, throw, push like real world"
      - "Physical affordances: Objects look grabbable, pushable"
      - "Consistent physics: Objects behave predictably"
      - "Haptic feedback: Vibration for touch confirmation"
      - "Audio feedback: Sound for every interaction"
      - "Visual feedback: Highlight, glow, animation"

  spatial_ui:
    description: "UI that exists in 3D space"
    types:
      - "World-anchored: Fixed to virtual object or location"
      - "Body-anchored: Attached to user (wrist, chest, belt)"
      - "Head-locked: Fixed to head rotation (use sparingly)"
      - "Floating: Free-floating in space"
    best_practice: "Prefer world-anchored and body-anchored, avoid head-locked"

  accessibility:
    description: "Design for all users"
    considerations:
      - "Multiple locomotion options (teleport, smooth, snap)"
      - "Multiple interaction methods (hand, controller, gaze, voice)"
      - "Adjustable height and scale"
      - "Seated mode support"
      - "High contrast and large text"
      - "Audio captions and visual sound indicators"
      - "Colorblind-friendly palettes"
      - "Reduced motion options"
      - "Cognitive load management (simple, clear instructions)"
```

### 3.2 VR Locomotion Patterns

```yaml
vr_locomotion:
  teleportation:
    description: "Point and teleport to location"
    method: "Point controller, press button, arc shows landing, release to teleport"
    comfort: "High (no motion sickness)"
    use: "Primary locomotion method for most VR"
    variants:
      - "Instant: Immediate teleport (can be disorienting)"
      - "Fade: Brief fade to black during teleport"
      - "Dash: Quick movement to target (0.1-0.3s)"
      - "Blink: Fade out, move, fade in"

  room_scale:
    description: "Physical walking within tracked space"
    method: "Walk in real space, tracked by headset"
    comfort: "Highest (natural movement)"
    limitation: "Limited to physical space size (2x2m to 4x4m typical)"
    use: "Best for small-scale interactions"

  smooth_locomotion:
    description: "Continuous movement with joystick"
    method: "Push joystick to move in direction"
    comfort: "Low (causes motion sickness for many)"
    mitigation: "Comfort vignette, slow speed, snap turns"
    use: "Experienced users, games requiring continuous movement"

  snap_turn:
    description: "Instant rotation by fixed angle"
    method: "Click joystick left/right to rotate 30-45 degrees"
    comfort: "High (avoids smooth rotation sickness)"
    use: "Alternative to smooth turning"

  smooth_turn:
    description: "Continuous rotation with joystick"
    method: "Push joystick left/right to rotate"
    comfort: "Low (causes motion sickness)"
    mitigation: "Very slow speed, comfort vignette"
    use: "Experienced users only"

  arm_swing:
    description: "Move by swinging arms"
    method: "Swing arms like walking to move forward"
    comfort: "Medium (vestibular feedback from arm movement)"
    use: "Walking simulation, fitness apps"

  grab_and_pull:
    description: "Pull yourself through environment"
    method: "Grab virtual surface and pull to move"
    comfort: "Medium (some users find disorienting)"
    use: "Climbing, zero-gravity environments"

  vehicle:
    description: "Movement within a virtual vehicle"
    method: "User is in cockpit/car/vehicle frame of reference"
    comfort: "Medium (frame of reference reduces sickness)"
    use: "Racing, flying, space simulators"

  redirected_walking:
    description: "Subtly rotate virtual world to guide walking"
    method: "User walks in circle in real world, thinks walking straight"
    comfort: "High (natural walking)"
    limitation: "Requires large space, complex implementation"
    use: "Research, large-scale VR experiences"
```

### 3.3 VR Interaction Patterns

```yaml
vr_interaction:
  direct_manipulation:
    description: "Grab and manipulate objects directly"
    method: "Reach out, grab with trigger/grip, move, release"
    feedback: "Haptic vibration on grab, visual hand pose change"
    constraints: "Physics, collision, joint limits"
    use: "Most natural, preferred for most interactions"

  raycast_selection:
    description: "Point ray at distant object to select"
    method: "Point controller, laser/line appears, press to select"
    distance: "Effective up to 10-20 meters"
    feedback: "Laser color change on hover, haptic on select"
    use: "Distant objects, menus, small targets"

  gaze_selection:
    description: "Look at object to select"
    method: "Head direction determines gaze, dwell or button to select"
    dwell_time: "1-2 seconds"
    feedback: "Progress circle around gaze point"
    use: "No controller scenarios, accessibility"

  gesture_recognition:
    description: "Hand gestures trigger actions"
    gestures:
      - "Pinch: Select/grab"
      - "Open hand: Release/drop"
      - "Point: Select/aim"
      - "Thumbs up: Confirm/like"
      - "Wave: Greeting/cancel"
      - "Swipe: Scroll/change page"
    use: "Hand tracking without controllers"

  voice_commands:
    description: "Speak commands to control VR"
    commands:
      - "Select [object]"
      - "Grab [object]"
      - "Move to [location]"
      - "Scale [object]"
      - "Rotate [object]"
      - "Menu"
      - "Back"
      - "Home"
    use: "Hands-free operation, accessibility"

  controller_mapping:
    description: "Standard VR controller button mapping"
    trigger:
      action: "Primary action (select, grab, fire)"
      feedback: "Haptic click, 0.5-1mm travel"
    grip:
      action: "Secondary grab, hold"
      feedback: "Haptic vibration, capacitive sensing"
    joystick:
      action: "Movement, rotation, scroll"
      feedback: "Click for confirm, smooth for movement"
    buttons:
      a_b_x_y: "Contextual actions, menu, back"
      menu: "System menu, pause"
      system: "Home, recenter, screenshot"

  haptic_feedback:
    description: "Vibration patterns for different interactions"
    patterns:
      - "Light tap: 50ms, 20% intensity (hover)"
      - "Click: 100ms, 40% intensity (button press)"
      - "Grab: 200ms, 60% intensity (object grab)"
      - "Impact: 300ms, 80% intensity (collision)"
      - "Error: 150ms, 100% intensity, 3 pulses (error)"
      - "Success: 200ms, 50% intensity, ascending pattern (success)"
      - "Notification: 100ms, 30% intensity, 2 pulses (alert)"
```

---

## 4. SPATIAL UI DESIGN

### 4.1 Spatial UI Principles

```yaml
spatial_ui_principles:
  distance:
    description: "Optimal distance for UI elements from user"
    comfortable: "0.5-1.5 meters (arm's reach)"
    reading: "1.0-2.0 meters (text comfortable to read)"
    overview: "2.0-5.0 meters (dashboards, maps)"
    background: "5.0+ meters (environment, sky)"
    minimum: "0.3 meters (closer causes eye strain)"

  angle:
    description: "Optimal angle for UI from center of view"
    primary: "0-15 degrees (center of attention)"
    secondary: "15-30 degrees (peripheral, easily glanceable)"
    tertiary: "30-60 degrees (requires head turn)"
    avoid: ">60 degrees (requires significant movement)"

  size:
    description: "Optimal size for UI elements in degrees of visual angle"
    text_minimum: "0.3 degrees (about 12px at 1m)"
    text_comfortable: "0.5-1.0 degrees (about 20-40px at 1m)"
    text_large: "1.0-2.0 degrees (about 40-80px at 1m)"
    button_minimum: "1.0 degrees (about 40px at 1m)"
    button_comfortable: "1.5-2.0 degrees (about 60-80px at 1m)"
    icon_minimum: "0.5 degrees (about 20px at 1m)"
    icon_comfortable: "1.0 degree (about 40px at 1m)"

  depth:
    description: "Use depth to organize information hierarchy"
    foreground: "0.5-1.0m (interactive elements, notifications)"
    midground: "1.0-2.0m (primary content, main UI)"
    background: "2.0-5.0m (context, environment, secondary info)"
    far: "5.0+ m (sky, distant environment)"

  grounding:
    description: "Anchor UI to real or virtual surfaces"
    types:
      - "World-anchored: Fixed to virtual surface or object"
      - "Body-anchored: Follows user body (wrist, chest)"
      - "Head-anchored: Follows head rotation (use sparingly)"
    preference: "World-anchored for content, body-anchored for tools"

  typography:
    description: "Text readability in 3D space"
    font_size: "Minimum 0.5 degrees visual angle"
    contrast: "High contrast against background (7:1 minimum)"
    background: "Opaque or semi-transparent panel behind text"
    line_length: "30-40 characters per line (shorter than 2D)"
    line_height: "1.5-2.0 (more than 2D for readability)"
    font_weight: "Medium or bold (thin fonts hard to read in 3D)"
    anti_aliasing: "Essential for readability"

  color:
    description: "Color considerations for 3D/AR/VR"
    contrast: "Higher contrast needed than 2D (lighting variation)"
    saturation: "Slightly more saturated than 2D (compensate for display)"
    brightness: "Brighter than 2D (compensate for display limitations)"
    background: "Avoid pure black (causes eye strain in VR)"

  panels:
    description: "UI panels in 3D space"
    shape: "Curved panels feel more natural (subtle curve, 5-10 degrees)"
    material: "Slightly translucent or opaque, not fully transparent"
    border: "Subtle border or shadow for depth perception"
    corner_radius: "8-16px (softer than 2D, feels more physical)"

  cursors:
    description: "Pointer/cursor in 3D space"
    types:
      - "Laser: Line from controller to target (raycast)"
      - "Dot: Small sphere at intersection point"
      - "Hand: Virtual hand representation"
      - "Reticle: Crosshair or circle at gaze point"
    states:
      - "Idle: Neutral"
      - "Hover: Highlight, color change"
      - "Active: Pressing, grabbing"
      - "Loading: Animation"
      - "Disabled: Grayed out"
```

### 4.2 Spatial Layout Patterns

```yaml
spatial_layout_patterns:
  cockpit:
    description: "UI arranged around user like vehicle cockpit"
    layout: "Instruments and controls at comfortable angles and distances"
    use: "Flight simulators, driving games, control rooms"

  dashboard:
    description: "Information panels arranged in front of user"
    layout: "Main panel center, secondary panels left/right"
    distance: "1.5-2.0 meters"
    use: "Data visualization, monitoring, productivity"

  wrist_ui:
    description: "UI attached to virtual wrist"
    layout: "Menu, status, quick actions on wrist"
    distance: "0.3-0.5 meters (natural wrist distance)"
    activation: "Rotate wrist toward face, or button press"
    use: "Quick access tools, status, notifications"

  belt_ui:
    description: "UI attached to virtual waist/belt"
    layout: "Tools, inventory, quick slots"
    distance: "0.8-1.0 meters"
    activation: "Look down, or hand gesture"
    use: "Tools, inventory, crafting"

  shoulder_ui:
    description: "UI attached to virtual shoulder"
    layout: "Notifications, status indicators"
    distance: "0.5-0.8 meters"
    activation: "Glance to side"
    use: "Notifications, status, social"

  floating_panels:
    description: "Free-floating UI panels in space"
    layout: "Panels positioned around user as needed"
    distance: "1.0-2.0 meters"
    manipulation: "Grab to move, resize, rotate"
    use: "Multi-window productivity, creative tools"

  world_anchored:
    description: "UI attached to specific virtual objects or locations"
    layout: "Labels, info panels, controls on objects"
    distance: "Object-dependent"
    use: "Object information, controls, annotations"

  radial_menu:
    description: "Circular menu around controller or gaze point"
    layout: "Items arranged in circle"
    activation: "Button press or gesture"
    selection: "Point to item, release to select"
    use: "Quick tool selection, context menus"

  volumetric_ui:
    description: "UI that occupies 3D volume"
    layout: "3D charts, models, spatial data"
    interaction: "Walk around, manipulate in 3D"
    use: "Data visualization, 3D modeling, scientific visualization"
```

---

## 5. TECHNICAL IMPLEMENTATION

### 5.1 WebXR API

```javascript
// WebXR Session Setup
async function initXR() {
  // Check if WebXR is supported
  if (!navigator.xr) {
    console.log('WebXR not supported');
    return;
  }

  // Check for AR support
  const isARSupported = await navigator.xr.isSessionSupported('immersive-ar');
  // Check for VR support
  const isVRSupported = await navigator.xr.isSessionSupported('immersive-vr');

  // Request AR session
  const session = await navigator.xr.requestSession('immersive-ar', {
    requiredFeatures: ['hit-test', 'dom-overlay'],
    optionalFeatures: ['light-estimation', 'anchors'],
    domOverlay: { root: document.getElementById('overlay') }
  });

  // Or request VR session
  const vrSession = await navigator.xr.requestSession('immersive-vr', {
    requiredFeatures: ['local-floor'],
    optionalFeatures: ['hand-tracking', 'layers']
  });

  // Create WebGL context
  const canvas = document.createElement('canvas');
  const gl = canvas.getContext('webgl2', { xrCompatible: true });

  // Create XRWebGLLayer
  const xrLayer = new XRWebGLLayer(session, gl);
  session.updateRenderState({ baseLayer: xrLayer });

  // Reference space
  const referenceSpace = await session.requestReferenceSpace('local-floor');

  // Hit test source (for AR)
  const hitTestSource = await session.requestHitTestSource({
    space: referenceSpace
  });

  // Animation loop
  session.requestAnimationFrame(onXRFrame);

  function onXRFrame(time, frame) {
    session.requestAnimationFrame(onXRFrame);

    const pose = frame.getViewerPose(referenceSpace);
    if (!pose) return;

    // Get hit test results (AR)
    const hitTestResults = frame.getHitTestResults(hitTestSource);
    if (hitTestResults.length > 0) {
      const hitPose = hitTestResults[0].getPose(referenceSpace);
      // Place object at hitPose.transform
    }

    // Render each view
    for (const view of pose.views) {
      const viewport = xrLayer.getViewport(view);
      gl.viewport(viewport.x, viewport.y, viewport.width, viewport.height);

      // Render scene with view.transform
      renderScene(view.transform);
    }
  }
}

// Hand Tracking (if supported)
async function initHandTracking(session) {
  if (session.inputSources) {
    for (const inputSource of session.inputSources) {
      if (inputSource.hand) {
        const hand = inputSource.hand;
        // Get joint poses
        const frame = ...; // from animation frame
        const referenceSpace = ...;

        for (const joint of hand.values()) {
          const jointPose = frame.getJointPose(joint, referenceSpace);
          if (jointPose) {
            // jointPose.transform.position
            // jointPose.transform.orientation
            // jointPose.radius
          }
        }
      }
    }
  }
}
```

### 5.2 Three.js for WebXR

```javascript
// Three.js WebXR Setup
import * as THREE from 'three';
import { VRButton } from 'three/examples/jsm/webxr/VRButton.js';
import { ARButton } from 'three/examples/jsm/webxr/ARButton.js';
import { XRControllerModelFactory } from 'three/examples/jsm/webxr/XRControllerModelFactory.js';

// Scene setup
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.xr.enabled = true;
document.body.appendChild(renderer.domElement);

// VR Button
const vrButton = VRButton.createButton(renderer);
document.body.appendChild(vrButton);

// AR Button
const arButton = ARButton.createButton(renderer, {
  requiredFeatures: ['hit-test'],
  optionalFeatures: ['dom-overlay'],
  domOverlay: { root: document.body }
});
document.body.appendChild(arButton);

// Lighting
const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
directionalLight.position.set(5, 10, 7);
directionalLight.castShadow = true;
scene.add(directionalLight);

// Environment
const pmremGenerator = new THREE.PMREMGenerator(renderer);
const envMap = pmremGenerator.fromScene(new THREE.Scene()).texture;
scene.environment = envMap;

// Material (PBR)
const material = new THREE.MeshStandardMaterial({
  color: 0xff6b35,
  roughness: 0.3,
  metalness: 0.1,
  envMap: envMap,
  envMapIntensity: 0.5
});

// Object
const geometry = new THREE.BoxGeometry(1, 1, 1);
const mesh = new THREE.Mesh(geometry, material);
mesh.position.set(0, 1, -2);
mesh.castShadow = true;
mesh.receiveShadow = true;
scene.add(mesh);

// Controllers
const controllerModelFactory = new XRControllerModelFactory();

const controller1 = renderer.xr.getController(0);
scene.add(controller1);

const controllerGrip1 = renderer.xr.getControllerGrip(0);
controllerGrip1.add(controllerModelFactory.createControllerModel(controllerGrip1));
scene.add(controllerGrip1);

const controller2 = renderer.xr.getController(1);
scene.add(controller2);

const controllerGrip2 = renderer.xr.getControllerGrip(1);
controllerGrip2.add(controllerModelFactory.createControllerModel(controllerGrip2));
scene.add(controllerGrip2);

// Raycaster for interaction
const raycaster = new THREE.Raycaster();
const tempMatrix = new THREE.Matrix4();

controller1.addEventListener('selectstart', onSelectStart);
controller1.addEventListener('selectend', onSelectEnd);

function onSelectStart(event) {
  const controller = event.target;
  controller.userData.isSelecting = true;

  // Raycast from controller
  tempMatrix.identity().extractRotation(controller.matrixWorld);
  raycaster.ray.origin.setFromMatrixPosition(controller.matrixWorld);
  raycaster.ray.direction.set(0, 0, -1).applyMatrix4(tempMatrix);

  const intersects = raycaster.intersectObjects(scene.children);
  if (intersects.length > 0) {
    const object = intersects[0].object;
    object.material.emissive.setHex(0xff0000);
    controller.userData.selected = object;
  }
}

function onSelectEnd(event) {
  const controller = event.target;
  controller.userData.isSelecting = false;

  if (controller.userData.selected) {
    controller.userData.selected.material.emissive.setHex(0x000000);
    controller.userData.selected = null;
  }
}

// Animation loop
renderer.setAnimationLoop(() => {
  renderer.render(scene, camera);
});

// Reticle for AR placement
const reticleGeometry = new THREE.RingGeometry(0.15, 0.2, 32);
reticleGeometry.rotateX(-Math.PI / 2);
const reticleMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
const reticle = new THREE.Mesh(reticleGeometry, reticleMaterial);
reticle.visible = false;
scene.add(reticle);

// AR Hit Test
let hitTestSource = null;
let hitTestSourceRequested = false;

renderer.xr.addEventListener('sessionstart', async () => {
  const session = renderer.xr.getSession();

  if (!hitTestSourceRequested) {
    const viewerSpace = await session.requestReferenceSpace('viewer');
    hitTestSource = await session.requestHitTestSource({ space: viewerSpace });
    hitTestSourceRequested = true;
  }
});

renderer.xr.addEventListener('sessionend', () => {
  hitTestSource = null;
  hitTestSourceRequested = false;
});

// Update reticle in animation loop
function updateReticle(frame, referenceSpace) {
  if (hitTestSource) {
    const hitTestResults = frame.getHitTestResults(hitTestSource);

    if (hitTestResults.length > 0) {
      const hit = hitTestResults[0];
      const pose = hit.getPose(referenceSpace);

      reticle.visible = true;
      reticle.matrix.fromArray(pose.transform.matrix);
    } else {
      reticle.visible = false;
    }
  }
}
```

### 5.3 Performance Optimization for XR

```yaml
xr_performance_optimization:
  frame_rate:
    requirement: "90fps for VR, 60fps for AR (mobile)"
    techniques:
      - "Reduce polygon count (LOD system)"
      - "Use simple shaders for distant objects"
      - "Frustum culling (don't render outside view)"
      - "Occlusion culling (don't render behind objects)"
      - "Instancing for repeated objects"
      - "Texture atlasing to reduce draw calls"

  latency:
    requirement: "Motion-to-photon < 20ms for VR"
    techniques:
      - "Asynchronous reprojection/timewarp"
      - "Predictive tracking (predict head position)"
      - "Reduce rendering pipeline stages"
      - "GPU priority for XR rendering"
      - "Foveated rendering (high res in center, low in periphery)"

  foveated_rendering:
    description: "Render high resolution only where user is looking"
    technique: "Use eye tracking to determine gaze direction"
    resolution:
      fovea: "100% resolution (center 10 degrees)"
      parafovea: "50% resolution (next 20 degrees)"
      periphery: "25% resolution (outer area)"
    benefit: "2-3x performance improvement"

  level_of_detail:
    description: "Use simpler models for distant objects"
    distances:
      close: "0-2m: Full detail"
      medium: "2-10m: Medium detail (50% polygons)"
      far: "10-50m: Low detail (25% polygons)"
      very_far: "50m+: Billboard or impostor"

  texture_optimization:
    description: "Optimize textures for XR"
    techniques:
      - "Use compressed textures (ETC2, ASTC, BC7)"
      - "Texture sizes: 512x512 close, 256x256 medium, 128x128 far"
      - "Mipmapping for all textures"
      - "Texture atlasing to reduce bind calls"
      - "Avoid transparent textures when possible"

  shadow_optimization:
    description: "Optimize shadows for performance"
    techniques:
      - "Use shadow maps, not ray-traced shadows"
      - "Shadow map resolution: 1024x1024 or 2048x2048"
      - "Limit shadow-casting lights to 1-2"
      - "Use contact shadows for close objects"
      - "Bake static shadows into lightmaps"

  audio_optimization:
    description: "Optimize spatial audio"
    techniques:
      - "Limit simultaneous sounds to 16-32"
      - "Use audio occlusion (sounds behind walls are muffled)"
      - "Stream long audio, don't load into memory"
      - "Use compressed audio formats (Ogg Vorbis, Opus)"
      - "HRTF (Head-Related Transfer Function) for 3D positioning"
```

---

*Document Version: 1.0.0*
*Last Updated: 2026-06-07*
*Classification: 3D, AR & VR Design Guide*
